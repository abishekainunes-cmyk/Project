@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0" >nul 2>&1
set "PORT_MIN=8765"
set "PORT_MAX=8795"
set "FOUND_PORT="

if exist "SERVER_PORT.txt" set /p SAVED_PORT=<"SERVER_PORT.txt"
if defined SAVED_PORT (
    for /f "usebackq delims=" %%Q in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $p=[int]'!SAVED_PORT!'; $w=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p+'/api/local-health') -TimeoutSec 2; $r=ConvertFrom-Json -InputObject $w.Content; if($r.ok -and $r.app -eq 'PriceMaster'){Write-Output $p} } catch {}"`) do set "FOUND_PORT=%%Q"
)

if not defined FOUND_PORT (
    for /f "usebackq delims=" %%Q in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($p in %PORT_MIN%..%PORT_MAX%){ try { $w=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p+'/api/local-health') -TimeoutSec 1; $r=ConvertFrom-Json -InputObject $w.Content; if($r.ok -and $r.app -eq 'PriceMaster'){Write-Output $p; break} } catch {} }"`) do set "FOUND_PORT=%%Q"
)

if not defined FOUND_PORT (
    echo PriceMaster server is not running.
    if exist "SERVER_PORT.txt" del /q "SERVER_PORT.txt" >nul 2>&1
    pause
    popd
    endlocal
    exit /b 0
)

set "PID_TO_STOP="
for /f "tokens=5" %%P in ('netstat -ano -p tcp ^| findstr /C:":!FOUND_PORT! " ^| findstr "LISTENING"') do set "PID_TO_STOP=%%P"
if not defined PID_TO_STOP (
    echo PriceMaster responded on port !FOUND_PORT!, but its process ID could not be found.
    pause
    popd
    endlocal
    exit /b 1
)

echo Stopping verified PriceMaster server on port !FOUND_PORT! - PID !PID_TO_STOP!...
taskkill /PID !PID_TO_STOP! /F >nul 2>&1
if errorlevel 1 (
    echo Could not stop the server. Try Run as administrator.
) else (
    echo PriceMaster server stopped.
    if exist "SERVER_PORT.txt" del /q "SERVER_PORT.txt" >nul 2>&1
)
echo.
pause
popd
endlocal
