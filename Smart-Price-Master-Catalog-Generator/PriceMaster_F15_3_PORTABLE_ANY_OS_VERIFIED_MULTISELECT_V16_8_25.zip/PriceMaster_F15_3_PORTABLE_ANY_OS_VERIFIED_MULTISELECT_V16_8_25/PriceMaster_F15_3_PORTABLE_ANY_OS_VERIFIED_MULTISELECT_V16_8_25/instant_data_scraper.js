/* Instant Data Scraper CSV bridge. No extension internals or credentials used. */
function parseIdsCSV(text){
  text=String(text).replace(/^\uFEFF/,'');
  if(text.length>5*1024*1024)throw Error('CSV is too large. Export at most 5 MB at a time.');
  const rows=[];let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(c==='"'){
      if(quoted&&text[i+1]==='"'){cell+='"';i++;}
      else if(quoted||!cell)quoted=!quoted;
      else cell+=c;
    }else if(!quoted&&(c===','||c==='\n'||c==='\r')){
      row.push(cell);cell='';
      if(c!==','){
        if(c==='\r'&&text[i+1]==='\n')i++;
        if(row.some(v=>v.trim()))rows.push(row);row=[];
        if(rows.length>5001)throw Error('Export at most 5,000 rows at a time.');
      }
    }else cell+=c;
    if(row.length>200)throw Error('CSV has too many columns.');
  }
  if(quoted)throw Error('CSV has an unfinished quoted field. Please export again.');
  row.push(cell);if(row.some(v=>v.trim()))rows.push(row);
  if(rows.length>5001)throw Error('Export at most 5,000 rows at a time.');
  if(rows.length<2)throw Error('CSV needs column headers and at least one product row.');
  if(rows[0].length>200)throw Error('CSV has too many columns.');
  return rows;
}
(function(){
  const fields=[['product_name','Product name',/^(product|product name|name|title)$/i],['supplier','Company / supplier',/^(company|company name|supplier|seller)$/i],['purchase_price','Price',/^(price|purchase price|amount)$/i],['product_link','IndiaMART product URL',/^(url|link|product link|product url)$/i],['image_link','Image URL',/^(image|image url|image link|photo)$/i],['model','Model',/^model$/i],['contact','Phone / contact',/^(phone|contact|mobile)$/i],['category','Category',/^category$/i],['specs','Description',/^(description|specs|specifications)$/i]];
  let csv=[],fileName='';
  const dialog=document.createElement('dialog');dialog.id='idsPanel';
  dialog.style.cssText='max-width:760px;width:90%;max-height:85vh;overflow:auto;border:1px solid #bcd2f4;border-radius:14px;padding:24px;color:#172033';
  dialog.innerHTML=`<h2>Instant Data Scraper · IndiaMART</h2>
    <p>Open IndiaMART in Chrome, run the extension on the results page, review the captured rows and export CSV. Import that CSV below. This does not run the extension automatically or bypass a blocked page.</p>
    <p><a href="https://chromewebstore.google.com/detail/instant-data-scraper/ofaokhiedipichpaobibbnahnkdoiiah" target="_blank" rel="noopener">Install Instant Data Scraper</a> · <button id="idsOpen" type="button">Open IndiaMART search</button></p>
    <label>Import IndiaMART CSV (up to 5 MB / 5,000 rows) <input id="idsFile" type="file" accept=".csv,text/csv"></label>
    <p>Check each column mapping and preview before importing. Unmapped fields remain empty. Imported rows stay in this tab until another search or reload; keep your CSV to import again.</p>
    <div id="idsMap" style="display:grid;grid-template-columns:1fr 1fr;gap:10px"></div>
    <div id="idsPreview" style="overflow:auto;margin:16px 0"></div>
    <p id="idsMessage" role="status"></p>
    <button id="idsImport" type="button" disabled>Show imported results · 25 at a time</button> <button id="idsClose" type="button">Close</button>`;
  document.body.appendChild(dialog);
  const el=id=>document.getElementById(id);
  const mapped=row=>Object.fromEntries(fields.map(([key])=>{const n=el('ids_'+key).value;return [key,n===''?'':String(row[Number(n)]||'').trim()];}));
  function preview(){
    const picks=fields.map(([k])=>el('ids_'+k).value).filter(v=>v!=='');
    const valid=el('ids_product_name').value!==''&&new Set(picks).size===picks.length;
    el('idsImport').disabled=!valid;
    el('idsMessage').textContent=valid?`${csv.length-1} source rows ready. Verify the preview below.`:'Select a Product name column. Use each source column only once.';
    el('idsPreview').innerHTML='<table><thead><tr><th>Product</th><th>Company</th><th>Price</th></tr></thead><tbody>'+csv.slice(1,4).map(row=>{const p=mapped(row);return '<tr>'+['product_name','supplier','purchase_price'].map(k=>'<td style="padding:6px;border:1px solid #ddd">'+esc(p[k])+'</td>').join('')+'</tr>';}).join('')+'</tbody></table>';
  }
  el('idsOpen').onclick=()=>window.open(indiaMartSearchUrlFor(el('search').value),'_blank','noopener');
  el('idsClose').onclick=()=>dialog.close();
  el('idsFile').onchange=async e=>{
    el('idsImport').disabled=true;csv=[];el('idsMap').replaceChildren();el('idsPreview').replaceChildren();
    try{
      const file=e.target.files[0];if(!file)return;
      if(file.size>5*1024*1024)throw Error('Choose a CSV smaller than 5 MB.');
      csv=parseIdsCSV(await file.text());fileName=file.name;
      for(const [key,label,pattern] of fields){
        const wrap=document.createElement('label');wrap.textContent=label+' ';
        const select=document.createElement('select');select.id='ids_'+key;select.style.maxWidth='100%';
        select.add(new Option('Not included',''));
        csv[0].forEach((h,i)=>select.add(new Option(`${i+1}: ${h.slice(0,100)}`,String(i))));
        const match=csv[0].findIndex(h=>pattern.test(h.trim()));if(match>=0)select.value=String(match);
        select.onchange=preview;wrap.append(select);el('idsMap').append(wrap);
      }
      preview();
    }catch(e){el('idsMessage').textContent=e.message;}
  };
  el('idsImport').onclick=()=>{
    try{
      const rows=csv.slice(1).map(mapped).filter(p=>p.product_name).map(p=>{
        for(const key of ['product_link','image_link']){try{const u=new URL(p[key]);if(!['https:','http:'].includes(u.protocol))throw Error();if(key==='product_link'&&!(u.hostname==='indiamart.com'||u.hostname.endsWith('.indiamart.com')))throw Error();p[key]=u.href;}catch(_){p[key]='';}}
        return {...p,source_type:'indiamart',source_sheet:'IndiaMART · Instant Data Scraper CSV',import_file:fileName};
      });
      if(!rows.length)throw Error('No product names found. Check the column mapping.');
      const clean=mergeUniqueProductRows([],rows);
      clearTimeout(searchTimer);++priceSearchSeq;
      if(typingPriceAbortController)typingPriceAbortController.abort();
      document.querySelectorAll('.pm-result-source-btn').forEach(b=>b.classList.toggle('active',b.id==='indiaMartDirectBtn'));
      typingPreviewMode=true;excelNamesOnly=false;priceLoadingMore=false;priceHasMore=false;priceNextOffset=0;sheetPriceTotal=0;
      visualMatchRows=[];visualMatchInfo=null;indiaMartRows=clean;indiaMartInfo={source:'Instant Data Scraper CSV'};
      products=clean;priceQuery=el('search').value.trim();priceTotal=clean.length;
      renderPrices(products,priceTotal);savePriceViewSnapshot();
      setIndiaMartStatus(`Imported ${clean.length} IndiaMART CSV results`);
      el('searchInfo').textContent=`Instant Data Scraper: ${clean.length} imported results · ${rows.length-clean.length} duplicates removed · SHOW MORE adds 25`;
      dialog.close();
    }catch(e){el('idsMessage').textContent=e.message;}
  };
})();
