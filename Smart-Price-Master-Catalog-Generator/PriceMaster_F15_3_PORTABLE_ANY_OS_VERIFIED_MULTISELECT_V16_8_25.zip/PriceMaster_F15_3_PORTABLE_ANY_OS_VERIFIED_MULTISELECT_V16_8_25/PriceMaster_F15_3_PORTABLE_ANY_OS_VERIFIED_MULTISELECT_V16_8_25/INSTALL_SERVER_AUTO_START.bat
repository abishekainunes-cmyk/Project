@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
set "ROOT=%CD%"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "AUTO=%STARTUP%\PriceMaster_Server_AutoStart.cmd"

echo.
echo ============================================================
echo   INSTALL PRICEMASTER SERVER AUTO-START
 echo ============================================================
echo.

if not exist "%STARTUP%" mkdir "%STARTUP%" >nul 2>&1

> "%AUTO%" echo @echo off
>> "%AUTO%" echo set "PRICEMASTER_OPEN_BROWSER=0"
>> "%AUTO%" echo start "" /min "%ROOT%\START_PRICEMASTER.bat"

if not exist "%AUTO%" (
    echo [ERROR] Could not create auto-start entry.
    pause
    popd
    endlocal
    exit /b 1
)

echo [OK] Installed auto-start for this Windows user.
echo PriceMaster will start automatically after you sign in to Windows.
echo The server PC must remain powered on and signed in for clients to use it.
echo.
echo Auto-start file:
echo %AUTO%
echo.
pause
popd
endlocal
