#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 START_ANY_OS.py
elif command -v python >/dev/null 2>&1; then
  exec python START_ANY_OS.py
else
  echo "Python 3.9+ was not found. Install python3 using your Linux package manager, then run this file again."
  exit 2
fi
