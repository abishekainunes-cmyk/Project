@echo off
setlocal EnableExtensions
title NUNES - Verify Cloud Backend
color 0A

pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Cannot open project folder.
  pause
  exit /b 1
)

set "URL=https://script.google.com/macros/s/AKfycbyuuVKcPpaBPS7VirAhrATDQURcsTQ4Vyrr0p0TPoGqi0MSmC6t2EcH5aUsyEIX_bFvYg/exec"

echo.
echo ============================================================
echo   NUNES CLOUD BACKEND VERIFY
echo ============================================================
echo.
echo Testing:
echo %URL%?action=status
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$u='%URL%?action=status'; try {$r=Invoke-WebRequest -UseBasicParsing -Uri $u -MaximumRedirection 10 -TimeoutSec 60; Write-Host ('HTTP ' + $r.StatusCode); Write-Host $r.Content; if($r.StatusCode -ne 200){exit 1}} catch {Write-Host ('[ERROR] ' + $_.Exception.Message); exit 1}"

echo.
if errorlevel 1 (
  echo RESULT: FAILED
) else (
  echo RESULT: CLOUD BACKEND REACHABLE
)

echo.
pause
popd
endlocal
