@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NUNES - UPDATE GOOGLE APPS SCRIPT WEB APP URL

echo ============================================================
echo  NUNES GMAIL - SAFE DEPLOYMENT URL UPDATER V6.5
echo ============================================================
echo.
echo Open Google Apps Script ^> Deploy ^> Manage deployments.
echo Copy the Web app URL ending in /exec and paste it below.
echo.
set /p "NEWURL=Paste NEW Web App /exec URL: "

if not defined NEWURL (
  echo.
  echo ERROR: No URL was entered.
  pause
  exit /b 2
)

where py >nul 2>nul
if %errorlevel%==0 (
  py update_deployment_url.py "%NEWURL%"
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python update_deployment_url.py "%NEWURL%"
  ) else (
    echo ERROR: Python was not found.
    pause
    exit /b 5
  )
)

set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo ============================================================
  echo  FIX COMPLETE - CLOSE OLD APP AND START AGAIN
  echo ============================================================
) else (
  echo ============================================================
  echo  URL WAS NOT CONFIRMED AS V6.5 - SEE MESSAGE ABOVE
  echo ============================================================
)
echo.
pause
exit /b %RC%
