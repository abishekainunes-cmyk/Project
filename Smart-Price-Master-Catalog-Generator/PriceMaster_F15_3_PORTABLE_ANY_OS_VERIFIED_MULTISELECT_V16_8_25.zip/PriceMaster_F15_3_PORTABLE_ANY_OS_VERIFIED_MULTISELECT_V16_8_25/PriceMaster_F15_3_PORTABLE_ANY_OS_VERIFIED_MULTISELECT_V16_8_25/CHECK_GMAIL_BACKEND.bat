@echo off
setlocal
title NUNES Gmail Backend Check
cd /d "%~dp0"
echo.
echo ============================================================
echo  NUNES GMAIL BACKEND CHECK - V6.5
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=Get-Content -Raw '.\\server.py'; $m=[regex]::Match($s,'APPS_SCRIPT_URL\\s*=\\s*\"([^\"]+)\"'); if(-not $m.Success){Write-Host 'Could not read APPS_SCRIPT_URL from server.py' -ForegroundColor Red; exit 2}; $u=$m.Groups[1].Value+'?action=status'; Write-Host ('Checking: '+$u) -ForegroundColor Cyan; try{$r=Invoke-RestMethod -Uri $u -Method Get -TimeoutSec 60; $r | ConvertTo-Json -Depth 8; if($r.backendBuild -eq 'V6.5_GMAIL_AUTH_2026-08-31'){Write-Host ''; Write-Host 'READY: Gmail backend V6.5 is deployed.' -ForegroundColor Green; exit 0}else{Write-Host ''; Write-Host ('NOT READY: current backend = '+$r.backendBuild) -ForegroundColor Yellow; Write-Host 'Deploy Code.gs from this folder as a NEW VERSION of the existing Apps Script Web App.' -ForegroundColor Yellow; exit 3}}catch{Write-Host $_.Exception.Message -ForegroundColor Red; exit 4}"
echo.
pause
