\
@echo off
setlocal
pushd "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (py CHECK_SEARCH_APIS.py & goto :done)
where python >nul 2>&1
if not errorlevel 1 (python CHECK_SEARCH_APIS.py & goto :done)
echo Python not found.
:done
echo.
pause
popd
endlocal
