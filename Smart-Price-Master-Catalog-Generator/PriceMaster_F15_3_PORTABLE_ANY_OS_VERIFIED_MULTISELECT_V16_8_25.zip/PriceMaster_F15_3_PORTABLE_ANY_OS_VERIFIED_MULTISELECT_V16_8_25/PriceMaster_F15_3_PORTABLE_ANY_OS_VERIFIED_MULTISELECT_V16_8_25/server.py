import json
import gzip
import base64
import atexit
import hashlib
import hmac
import csv
import io
import re
import html as html_lib
import tempfile
import uuid
import os
import sys
import threading
import webbrowser
import time
import random
import subprocess
import shutil
import ctypes
import socket
import ipaddress
import sqlite3
import unicodedata
import http.cookiejar
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote, urlencode, urljoin, unquote
from urllib.request import Request, urlopen, build_opener, HTTPCookieProcessor
from urllib.error import HTTPError, URLError

import quotation_hub
import pricemaster_intelligence as pm_intel

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_BUILD = "F15_3_PORTABLE_ANY_OS_VERIFIED_MULTISELECT_V16_8_25"

# V16.8.20: never depend on write permission beside the ZIP/server file.
# PriceMaster is often started directly from a NAS/UNC share, where the program
# folder can be read-only for normal staff accounts. Persistent runtime caches
# now live under LOCALAPPDATA (or a temp fallback), while the program itself can
# stay on the NAS. PRICEMASTER_CACHE_DIR can override this location.
def _runtime_cache_dir():
    """Return a persistent writable per-user cache on Windows, macOS or Linux."""
    override = os.environ.get("PRICEMASTER_CACHE_DIR", "").strip()
    if override:
        target = Path(os.path.expanduser(override))
    elif os.name == "nt":
        local = os.environ.get("LOCALAPPDATA", "").strip()
        target = (Path(local) if local else (Path.home() / "AppData" / "Local")) / "NunesPriceMaster" / "cache"
    elif sys.platform == "darwin":
        target = Path.home() / "Library" / "Caches" / "NunesPriceMaster" / "cache"
    else:
        xdg = os.environ.get("XDG_CACHE_HOME", "").strip()
        target = (Path(os.path.expanduser(xdg)) if xdg else (Path.home() / ".cache")) / "NunesPriceMaster" / "cache"
    try:
        target.mkdir(parents=True, exist_ok=True)
        probe = target / ".write_test"
        probe.write_text("ok", encoding="utf-8")
        try:
            probe.unlink()
        except Exception:
            pass
        return target
    except Exception:
        fallback = Path(tempfile.gettempdir()) / "NunesPriceMaster" / "cache"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

RUNTIME_CACHE_DIR = _runtime_cache_dir()
PACKAGE_CACHE_DIR = Path(BASE_DIR) / "cache"
PRICE_BRAIN_DB = pm_intel.configure(RUNTIME_CACHE_DIR)
print(f"[CACHE] Runtime cache: {RUNTIME_CACHE_DIR}")
print(f"[BRAIN] Shared office intelligence: {PRICE_BRAIN_DB}")

# V16.5 optional paid search accelerators. Environment variables take precedence;
# SEARCH_API_KEYS.env beside server.py is the easy one-PC setup. Missing/invalid
# services never stop PriceMaster: existing Sheet / IndiaMART / Bing fallbacks stay.
SEARCH_API_KEYS_FILE = os.path.join(BASE_DIR, "SEARCH_API_KEYS.env")

def _load_optional_search_api_env():
    try:
        if not os.path.exists(SEARCH_API_KEYS_FILE):
            return
        with open(SEARCH_API_KEYS_FILE, "r", encoding="utf-8-sig") as handle:
            for raw in handle:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                name, value = line.split("=", 1)
                name = name.strip()
                value = value.strip().strip('"').strip("'")
                if name and value and not os.environ.get(name):
                    os.environ[name] = value
    except Exception as exc:
        print("[SEARCH API] Could not read SEARCH_API_KEYS.env:", exc)

_load_optional_search_api_env()
SERPER_API_KEY = os.environ.get("SERPER_API_KEY", "").strip()
EXA_API_KEY = os.environ.get("EXA_API_KEY", "").strip()
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "").strip()
FIRECRAWL_API_KEY = os.environ.get("FIRECRAWL_API_KEY", "").strip()
SEARCH_API_TIMEOUT = max(2.0, min(12.0, float(os.environ.get("SEARCH_API_TIMEOUT", "5.5") or "5.5")))

SEARCH_MODE_PROFILES = {
    "minimum": {
        "label": "Minimum",
        "target_links": 180,
        "paid_provider_cap": 1,
        "detail_fetch": 4,
        "direct_pages": 6,
        "start_offsets": 5,
        "related_pages": 1,
        "paid_images": False,
    },
    "standard": {
        "label": "Standard",
        "target_links": 1400,
        "paid_provider_cap": 2,
        "detail_fetch": 14,
        "direct_pages": 20,
        "start_offsets": 14,
        "related_pages": 6,
        "paid_images": True,
    },
    "deep": {
        "label": "Deep",
        "target_links": 4000,
        "paid_provider_cap": 4,
        "detail_fetch": 24,
        "direct_pages": 40,
        "start_offsets": 30,
        "related_pages": 12,
        "paid_images": True,
    },
}

def _normalize_search_mode(value):
    mode = str(value or "standard").strip().lower()
    return mode if mode in SEARCH_MODE_PROFILES else "standard"

def _search_mode_profile(value):
    return SEARCH_MODE_PROFILES[_normalize_search_mode(value)]


def _pdf_snapshot_tokens(value):
    return [t for t in re.sub(r"[^a-z0-9]+", " ", _clean_text(value).lower()).split() if t]


INDIAMART_PDF_SNAPSHOT_FILE = os.path.join(BASE_DIR, "indiamart_pdf_snapshots.json")
_indiamart_pdf_snapshot_lock = threading.RLock()
_indiamart_pdf_snapshot_cache = {"mtime": None, "data": None}


def _load_indiamart_pdf_snapshots():
    """Load bundled IndiaMART PDF snapshots without any third-party PDF runtime.

    The PDF is parsed once while this release is built and stored as normalized
    JSON rows. This makes the captured offers available on every client PC even
    when IndiaMART's live page blocks urllib/browser automation.
    """
    try:
        mtime = os.path.getmtime(INDIAMART_PDF_SNAPSHOT_FILE)
    except Exception:
        return []
    with _indiamart_pdf_snapshot_lock:
        if _indiamart_pdf_snapshot_cache.get("mtime") == mtime:
            data = _indiamart_pdf_snapshot_cache.get("data")
        else:
            try:
                with open(INDIAMART_PDF_SNAPSHOT_FILE, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
            except Exception as exc:
                print("[INDIAMART PDF] Could not load snapshot:", exc, flush=True)
                data = {}
            _indiamart_pdf_snapshot_cache["mtime"] = mtime
            _indiamart_pdf_snapshot_cache["data"] = data
    snapshots = data.get("snapshots", []) if isinstance(data, dict) else []
    return snapshots if isinstance(snapshots, list) else []


def _indiamart_pdf_snapshot_rows(query, limit=None):
    """Return captured IndiaMART rows matching a search.

    Broad category queries such as "digital multimeter", "multimeter" or "dmm"
    return the complete captured list. Specific product/model queries return only
    rows containing all search tokens.
    """
    qtokens = _pdf_snapshot_tokens(query)
    if not qtokens:
        return [], []
    requested = max(1, min(int(limit or INDIAMART_MAX_RESULTS), INDIAMART_MAX_RESULTS))
    output, used_titles = [], []
    qset = set(qtokens)
    for snapshot in _load_indiamart_pdf_snapshots():
        if not isinstance(snapshot, dict):
            continue
        aliases = snapshot.get("search_terms") or []
        alias_token_sets = [set(_pdf_snapshot_tokens(alias)) for alias in aliases if _pdf_snapshot_tokens(alias)]
        broad_match = any(qset.issubset(tokens) for tokens in alias_token_sets)
        matched_this_snapshot = False
        for raw in snapshot.get("products") or []:
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            text = " ".join(str(row.get(k) or "") for k in ("product_name", "model", "supplier", "specs", "category"))
            text_tokens = set(_pdf_snapshot_tokens(text))
            if not broad_match and not qset.issubset(text_tokens):
                continue
            row["source_type"] = "indiamart"
            row["pdf_snapshot"] = True
            row["search_text"] = _product_search_text(row)
            output.append(row)
            matched_this_snapshot = True
            if len(output) >= requested:
                break
        if matched_this_snapshot:
            used_titles.append(_clean_text(snapshot.get("title") or "IndiaMART PDF Snapshot"))
        if len(output) >= requested:
            break
    return output[:requested], list(dict.fromkeys(used_titles))
HOST = os.environ.get("PRICEMASTER_HOST", "0.0.0.0").strip() or "0.0.0.0"
PORT = int(os.environ.get("PRICEMASTER_PORT", "8765") or "8765")
SERVER_PORT_FILE = os.path.join(BASE_DIR, "SERVER_PORT.txt")
LOCAL_BROWSER_HOST = "127.0.0.1"
TAILSCALE_NETWORK = ipaddress.ip_network("100.64.0.0/10")


WEBSITE_CATEGORY_JSON = os.path.join(BASE_DIR, "website_categories.json")
CATEGORY_QR_DIR = os.path.join(BASE_DIR, "category_qr")

def _load_website_categories():
    try:
        with open(WEBSITE_CATEGORY_JSON, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        if not isinstance(rows, list):
            return [], {}
        safe = []
        by_id = {}
        for item in rows:
            if not isinstance(item, dict):
                continue
            cid = re.sub(r"[^a-z0-9-]+", "", str(item.get("id", "")).lower())
            url = str(item.get("url", "")).strip()
            name = str(item.get("name", "")).strip()
            if not cid or not name or not url.startswith("https://www.nunesinstrumentation.com/"):
                continue
            row = dict(item)
            row["id"] = cid
            row["name"] = name
            row["url"] = url
            row["qrFile"] = os.path.join("category_qr", cid + ".png").replace("\\", "/")
            safe.append(row)
            by_id[cid] = row
        return safe, by_id
    except Exception as exc:
        print("[WEBSITE CATEGORIES] Could not load category list:", exc)
        return [], {}

WEBSITE_CATEGORIES, WEBSITE_CATEGORY_BY_ID = _load_website_categories()

# YOUR GOOGLE APPS SCRIPT WEB APP
APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyuuVKcPpaBPS7VirAhrATDQURcsTQ4Vyrr0p0TPoGqi0MSmC6t2EcH5aUsyEIX_bFvYg/exec"

# Cloud Drive roots used by the Apps Script backend.
DRIVE_ROOTS = [
    {"name": "Mini Catalog", "id": "1C4Bh6hfXC731IXcDMHPSk4szFSaKLkpo"},
    {"name": "Overall Categories Catalog", "id": "1uILUsmav_9nKmt7Zk1nAyIyltgL3gJXY"},
    {"name": "Detailed Catalog", "id": "1zqiE59vCUXmSZec0149KdKj0vuJPBdiP"}
]


OVERALL_CATEGORY_DRIVE_URL = "https://drive.google.com/drive/folders/1uILUsmav_9nKmt7Zk1nAyIyltgL3gJXY?usp=drive_link"
OVERALL_CATEGORY_SHEET_ID = "1-XmDUFk7nz_4BK_EV9L8eKH4xR1sFPPeLoGzfAhi0W8"
OVERALL_CATEGORY_CACHE_SECONDS = 600
_overall_category_lock = threading.RLock()
_overall_category_build_lock = threading.Lock()
_overall_category_cache = {"categories": [], "loaded_at": 0.0, "source": "", "warning": ""}


def _load_overall_category_sheet():
    """Return unique category names from the supplied category Google Sheet.

    This intentionally reads only names. The existing NUNES catalog/search
    architecture and Drive APIs are left unchanged.
    """
    urls = [
        f"https://docs.google.com/spreadsheets/d/{OVERALL_CATEGORY_SHEET_ID}/export?format=csv&gid=0",
        f"https://docs.google.com/spreadsheets/d/{OVERALL_CATEGORY_SHEET_ID}/gviz/tq?tqx=out%3Acsv&gid=0",
    ]
    last_error = ""
    for url in urls:
        try:
            req = Request(url, headers={
                "User-Agent": "Mozilla/5.0",
                "Accept-Language": "en-US,en;q=0.9",
            })
            with urlopen(req, timeout=30) as response:
                final_url = response.geturl().lower()
                body = response.read().decode("utf-8", errors="replace")
            if "accounts.google.com" in final_url or "request access" in body[:5000].lower():
                raise RuntimeError("Category Sheet requires Google access")
            rows = list(csv.reader(io.StringIO(body)))
            if not rows:
                continue

            header_row = None
            category_col = None
            aliases = {"category", "categories", "category name", "catalog category", "product category"}
            for r_idx, row in enumerate(rows[:25]):
                for c_idx, cell in enumerate(row):
                    if _norm_header(cell) in aliases:
                        header_row, category_col = r_idx, c_idx
                        break
                if category_col is not None:
                    break

            names = []
            seen = set()
            if category_col is not None:
                data_rows = rows[header_row + 1:]
                values = [row[category_col] if category_col < len(row) else "" for row in data_rows]
            else:
                # Safe fallback for a simple single-column category sheet.
                nonempty_counts = []
                width = max((len(r) for r in rows), default=0)
                for c in range(width):
                    count = sum(1 for r in rows if c < len(r) and _clean_text(r[c]))
                    nonempty_counts.append((count, c))
                best_col = max(nonempty_counts, default=(0, 0))[1]
                values = [r[best_col] if best_col < len(r) else "" for r in rows]

            for value in values:
                name = _clean_text(value)
                key = name.lower()
                if not name or key in aliases or key in seen:
                    continue
                seen.add(key)
                names.append(name)
            if names:
                return names
        except Exception as exc:
            last_error = str(exc)
    raise RuntimeError(last_error or "No categories found in category Sheet")



def _overall_category_payload(names, drive_categories=None):
    """Build Overall Category metadata from the category Sheet + Drive only.

    Overall Categories no longer displays or calculates price availability, so the
    very large price register is intentionally not scanned here. This keeps the
    existing category and Drive sources unchanged while making this stage load
    substantially faster. Compatibility keys are retained for older UI code.
    """
    drive_categories = drive_categories or []

    def norm(value):
        text = _clean_text(value).lower()
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    generic = {
        "equipment", "equipments", "instrument", "instruments", "machine", "machines",
        "apparatus", "system", "systems", "testing", "test", "tester", "catalog", "catalogue"
    }

    drive_rows = []
    for item in drive_categories:
        if not isinstance(item, dict) or item.get("type") == "ROOT":
            continue
        root = str(item.get("rootName") or item.get("driveSource") or "")
        if root and root != "Overall Categories Catalog":
            continue
        name = _clean_text(item.get("name") or "")
        path = _clean_text(item.get("path") or item.get("name") or "")
        drive_rows.append({"name": name, "path": path, "key": norm(name + " " + path)})

    output = []
    for name in names:
        clean_name = _clean_text(name)
        nkey = norm(clean_name)
        ntokens = [t for t in nkey.split() if len(t) > 2 and t not in generic]
        token_probe = ntokens[:3]

        catalog_match = None
        for d in drive_rows:
            dkey = d["key"]
            if nkey and (nkey in dkey or dkey.endswith(nkey)):
                catalog_match = d
                break
            if token_probe and all(tok in dkey for tok in token_probe):
                catalog_match = d
                break

        output.append({
            "name": clean_name,
            "path": (catalog_match or {}).get("path") or clean_name,
            "priceAvailable": False,
            "catalogAvailable": bool(catalog_match),
            "productCount": 0,
            "productNames": [],
            "folderUrl": OVERALL_CATEGORY_DRIVE_URL,
        })

    return output


def _build_overall_category_response():
    """Load Sheet + Drive category metadata in parallel and cache the result."""
    sheet_names = []
    sheet_error = ""
    drive_result = {}

    def load_sheet():
        return _load_overall_category_sheet()

    def load_drive():
        try:
            return cloud_json({"action": "categories"})
        except Exception:
            return {}

    with ThreadPoolExecutor(max_workers=2) as pool:
        sheet_future = pool.submit(load_sheet)
        drive_future = pool.submit(load_drive)
        try:
            sheet_names = sheet_future.result()
        except Exception as exc:
            sheet_error = str(exc)
        try:
            drive_result = drive_future.result() or {}
        except Exception:
            drive_result = {}

    drive_categories = drive_result.get("categories", []) if isinstance(drive_result, dict) and drive_result.get("ok") else []

    source = "sheet"
    names = sheet_names
    if not names:
        source = "drive-fallback"
        names = []
        seen = set()
        for item in drive_categories:
            root = str(item.get("rootName") or item.get("driveSource") or "")
            if root != "Overall Categories Catalog" or item.get("type") == "ROOT":
                continue
            name = _clean_text(item.get("name") or item.get("path") or "")
            key = name.lower()
            if name and key not in seen:
                seen.add(key)
                names.append(name)

    categories = _overall_category_payload(names, drive_categories)
    result = {
        "ok": True,
        "source": source,
        "driveUrl": OVERALL_CATEGORY_DRIVE_URL,
        "categories": categories,
    }
    if sheet_error:
        result["warning"] = sheet_error

    with _overall_category_lock:
        _overall_category_cache["categories"] = categories
        _overall_category_cache["loaded_at"] = time.time()
        _overall_category_cache["source"] = source
        _overall_category_cache["warning"] = sheet_error
    return result


def get_overall_category_response(force=False):
    def cached_response():
        now = time.time()
        with _overall_category_lock:
            cached = list(_overall_category_cache.get("categories") or [])
            age = now - float(_overall_category_cache.get("loaded_at") or 0)
            if cached and not force and age < OVERALL_CATEGORY_CACHE_SECONDS:
                result = {
                    "ok": True,
                    "source": _overall_category_cache.get("source") or "cache",
                    "driveUrl": OVERALL_CATEGORY_DRIVE_URL,
                    "categories": cached,
                    "cached": True,
                }
                warning = _overall_category_cache.get("warning") or ""
                if warning:
                    result["warning"] = warning
                return result
        return None

    ready = cached_response()
    if ready is not None:
        return ready

    # Prevent the browser prefetch and background warm-up from building the
    # same large payload twice at the same time.
    with _overall_category_build_lock:
        ready = cached_response()
        if ready is not None:
            return ready
        return _build_overall_category_response()


def start_overall_category_worker():
    """Warm the Overall Categories cache immediately in the background."""
    def worker():
        try:
            get_overall_category_response(force=False)
        except Exception:
            pass
    threading.Thread(target=worker, name="overall-category-warmup", daemon=True).start()


# Product/price source merged from Instrument Register V10.8.
# The NUNES local HTTP server remains the single runtime/server.
PRICE_SHEET_URL = "https://docs.google.com/spreadsheets/d/1tsbWMnpY2kXx3B220oyOgvyWbdsFHyhA8rVBB_dqXHU/edit?usp=sharing"
PRICE_SHEET_ID = "1tsbWMnpY2kXx3B220oyOgvyWbdsFHyhA8rVBB_dqXHU"
# The price register is very large.  Keep the already-loaded/local cache hot and
# refresh the live Google Sheet less aggressively so normal searches never fight
# a full workbook download every minute.
PRICE_REFRESH_SECONDS = 300
_price_lock = threading.RLock()
_price_search_lock = threading.RLock()
_price_search_cache = OrderedDict()
PRICE_SEARCH_CACHE_MAX = 64

# F15.0: one shared response cache lives on the main server, so repeated searches
# from different office PCs reuse the same Drive + local-price result instead of
# asking the cloud/backend to do identical work again. It is deliberately short
# lived so current product/pricing data still refreshes naturally.
_central_search_cache_lock = threading.RLock()
_central_search_cache = OrderedDict()
CENTRAL_SEARCH_CACHE_SECONDS = 300
CENTRAL_SEARCH_CACHE_MAX = 120

def _central_cache_get(key):
    now = time.time()
    with _central_search_cache_lock:
        cached = _central_search_cache.get(key)
        if not cached:
            return None
        saved_at, payload = cached
        if now - saved_at > CENTRAL_SEARCH_CACHE_SECONDS:
            _central_search_cache.pop(key, None)
            return None
        _central_search_cache.move_to_end(key)
        try:
            return json.loads(json.dumps(payload, ensure_ascii=False))
        except Exception:
            return payload

def _central_cache_put(key, payload):
    with _central_search_cache_lock:
        _central_search_cache[key] = (time.time(), payload)
        _central_search_cache.move_to_end(key)
        while len(_central_search_cache) > CENTRAL_SEARCH_CACHE_MAX:
            _central_search_cache.popitem(last=False)

def _central_cache_stats():
    now = time.time()
    with _central_search_cache_lock:
        alive = sum(1 for ts, _ in _central_search_cache.values() if now - ts <= CENTRAL_SEARCH_CACHE_SECONDS)
        return {"entries": alive, "maxEntries": CENTRAL_SEARCH_CACHE_MAX, "ttlSeconds": CENTRAL_SEARCH_CACHE_SECONDS}

# Office-wide live-search concurrency is intentionally lower than request-thread
# concurrency. Different PCs can still use cached/Sheet results immediately, while
# only two expensive IndiaMART discovery jobs run at once. Duplicate searches are
# already collapsed by single-flight before this gate is used.
_office_search_gate = threading.BoundedSemaphore(2)
_office_search_state_lock = threading.RLock()
_office_search_active = {}
_office_search_queued = 0

def _office_search_enter(query, mode):
    global _office_search_queued
    token = uuid.uuid4().hex
    with _office_search_state_lock:
        _office_search_queued += 1
    _office_search_gate.acquire()
    with _office_search_state_lock:
        _office_search_queued = max(0, _office_search_queued - 1)
        _office_search_active[token] = {"query": _clean_text(query), "mode": _normalize_search_mode(mode), "startedAt": time.time()}
    return token

def _office_search_leave(token):
    with _office_search_state_lock:
        _office_search_active.pop(token, None)
    try:
        _office_search_gate.release()
    except Exception:
        pass

def _office_search_stats():
    with _office_search_state_lock:
        return {"active": len(_office_search_active), "queued": int(_office_search_queued), "jobs": list(_office_search_active.values())[:12]}

# IndiaMART live supplier/price search is additive: the existing Google Sheet
# remains the primary price register, and IndiaMART rows are merged only when
# the user searches for a product/model. Results are cached briefly to avoid
# repeated live requests for the same query.
INDIAMART_SEARCH_URL = "https://dir.indiamart.com/search.mp?ss={query}"
INDIAMART_MOBILE_SEARCH_URL = "https://m.indiamart.com/search.mp?ss={query}"
INDIAMART_CACHE_SECONDS = 3600
# Do not let one transient empty response poison the same search for 15 minutes.
# Successful lists still keep the normal hot-cache TTL; empty misses are retried
# quickly enough to recover when IndiaMART/search discovery starts responding again.
INDIAMART_EMPTY_CACHE_SECONDS = 5
# F14.8: keep the current UI's 160-row request working, but prevent one API
# call from allocating/serializing thousands of IndiaMART rows.
INDIAMART_MAX_RESULTS = 500
INDIAMART_PAGE_SIZE_DEFAULT = 50
INDIAMART_PAGE_SIZE_MAX = 160
INDIAMART_DISCOVERY_MAX_LINKS = 500
INDIAMART_DETAIL_CACHE_SECONDS = 3600
# V16.8.10: block-resilient request pacing. This intentionally does NOT bypass
# IndiaMART verification/CAPTCHA or access controls. It reduces self-triggered
# blocking, honours temporary rate limits, retries only transient failures, and
# falls back to the existing discovery sources/caches when IndiaMART asks us to
# wait.
INDIAMART_MIN_REQUEST_GAP = 0.055
INDIAMART_TRANSIENT_RETRIES = 1
INDIAMART_VERIFY_COOLDOWN_SECONDS = 90
INDIAMART_STALE_CACHE_SECONDS = 24 * 60 * 60
_indiamart_lock = threading.RLock()
_indiamart_cache = OrderedDict()
_indiamart_detail_cache = OrderedDict()
_indiamart_singleflight_lock = threading.RLock()
_indiamart_singleflight = {}
_indiamart_request_gate = threading.Lock()
# Global cap across free public IndiaMART/index fetches so multiple tabs/PCs do
# not multiply the local thread pools into a request burst.
INDIAMART_PUBLIC_MAX_CONCURRENCY = 4
_indiamart_public_gate = threading.BoundedSemaphore(INDIAMART_PUBLIC_MAX_CONCURRENCY)
_indiamart_next_request_at = 0.0
_indiamart_blocked_until = 0.0
INDIAMART_CACHE_MAX = 40
INDIAMART_DETAIL_CACHE_MAX = 500

# F14.5: successful IndiaMART searches are now durable, not RAM-only.
# The store is placed in the writable runtime cache so it survives browser/server
# restarts even when PriceMaster itself runs from a read-only NAS/ZIP folder.
INDIAMART_PERSIST_FILE = RUNTIME_CACHE_DIR / "indiamart_results.json"  # legacy F14.5-F14.7 read fallback
INDIAMART_PERSIST_DB = RUNTIME_CACHE_DIR / "indiamart_results.sqlite3"
INDIAMART_PERSIST_MAX_SEARCHES = 60
_indiamart_persist_lock = threading.RLock()

def _indiamart_persist_key(query, mode="standard", free_only=True):
    clean_query = _clean_text(query).casefold()
    clean_mode = _normalize_search_mode(mode)
    return ("free|" if free_only else "auto|") + clean_mode + "|" + clean_query

def _empty_indiamart_persist_store():
    return {"version": 1, "updatedAt": 0.0, "entries": {}}

def _read_indiamart_persist_store_unlocked():
    try:
        if not INDIAMART_PERSIST_FILE.exists():
            return _empty_indiamart_persist_store()
        with INDIAMART_PERSIST_FILE.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return _empty_indiamart_persist_store()
        entries = data.get("entries")
        if not isinstance(entries, dict):
            entries = {}
        data["entries"] = entries
        data["version"] = 1
        return data
    except Exception as exc:
        print("[INDIAMART SAVE] Could not read persistent store:", exc, flush=True)
        return _empty_indiamart_persist_store()

def _write_indiamart_persist_store_unlocked(data):
    INDIAMART_PERSIST_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = INDIAMART_PERSIST_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8", newline="") as handle:
        json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except Exception:
            pass
    os.replace(str(tmp), str(INDIAMART_PERSIST_FILE))


def _ensure_indiamart_sqlite_unlocked():
    """Open/create the built-in SQLite snapshot store (no extra package required)."""
    INDIAMART_PERSIST_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(INDIAMART_PERSIST_DB), timeout=12)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS indiamart_searches (
            persist_key TEXT PRIMARY KEY,
            query TEXT NOT NULL,
            mode TEXT NOT NULL,
            free_only INTEGER NOT NULL,
            saved_at REAL NOT NULL,
            origin TEXT,
            result_count INTEGER NOT NULL,
            content_hash TEXT NOT NULL,
            payload_json TEXT NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_indiamart_saved_at ON indiamart_searches(saved_at DESC)")
    conn.commit()
    return conn


def _indiamart_snapshot_hash(rows):
    compact = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        compact.append({
            "product_name": _clean_text(row.get("product_name")),
            "model": _clean_text(row.get("model")),
            "supplier": _clean_text(row.get("supplier")),
            "purchase_price": _clean_text(row.get("purchase_price")),
            "product_link": _clean_text(row.get("product_link")),
            "image_link": _clean_text(row.get("image_link")),
        })
    raw = json.dumps(compact, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _load_indiamart_sqlite_entry_unlocked(key):
    conn = _ensure_indiamart_sqlite_unlocked()
    try:
        row = conn.execute("SELECT payload_json FROM indiamart_searches WHERE persist_key=?", (key,)).fetchone()
        if not row:
            return None
        data = json.loads(row[0])
        return data if isinstance(data, dict) else None
    finally:
        conn.close()


def _write_indiamart_sqlite_entry_unlocked(key, entry, content_hash):
    payload_json = json.dumps(entry, ensure_ascii=False, separators=(",", ":"))
    conn = _ensure_indiamart_sqlite_unlocked()
    try:
        old = conn.execute("SELECT content_hash FROM indiamart_searches WHERE persist_key=?", (key,)).fetchone()
        if old and old[0] == content_hash:
            return False
        conn.execute("""
            INSERT INTO indiamart_searches
                (persist_key, query, mode, free_only, saved_at, origin, result_count, content_hash, payload_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(persist_key) DO UPDATE SET
                query=excluded.query,
                mode=excluded.mode,
                free_only=excluded.free_only,
                saved_at=excluded.saved_at,
                origin=excluded.origin,
                result_count=excluded.result_count,
                content_hash=excluded.content_hash,
                payload_json=excluded.payload_json
        """, (
            key, entry.get("query") or "", entry.get("mode") or "standard",
            1 if entry.get("freeOnly") else 0, float(entry.get("savedAt") or time.time()),
            entry.get("origin") or "", int(entry.get("count") or 0), content_hash, payload_json,
        ))
        conn.execute("""
            DELETE FROM indiamart_searches
            WHERE persist_key NOT IN (
                SELECT persist_key FROM indiamart_searches ORDER BY saved_at DESC LIMIT ?
            )
        """, (INDIAMART_PERSIST_MAX_SEARCHES,))
        conn.commit()
        return True
    finally:
        conn.close()


def _persist_indiamart_results(query, rows, info=None, mode="standard", free_only=True, origin="server-get"):
    """Save a successful IndiaMART snapshot to SQLite with duplicate-write suppression."""
    clean_query = _clean_text(query)
    clean_mode = _normalize_search_mode(mode)
    if not clean_query or not isinstance(rows, list):
        return {"ok": False, "saved": False, "error": "Missing IndiaMART query/results"}
    clean_rows = []
    for raw in rows[:INDIAMART_MAX_RESULTS]:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        if not _clean_text(row.get("product_name")):
            continue
        row["source_type"] = "indiamart"
        row["source_sheet"] = row.get("source_sheet") or "IndiaMART Persistent Snapshot"
        clean_rows.append(row)
    clean_rows = _dedupe_indiamart_products(clean_rows)[:INDIAMART_MAX_RESULTS]
    if not clean_rows:
        return {"ok": False, "saved": False, "error": "No valid IndiaMART rows to save"}

    now = time.time()
    key = _indiamart_persist_key(clean_query, clean_mode, free_only)
    safe_info = dict(info or {}) if isinstance(info, dict) else {}
    safe_info.pop("products", None)
    safe_info["persisted"] = True
    safe_info["persistedAt"] = now
    safe_info["persistedOrigin"] = origin
    safe_info["persistentFile"] = str(INDIAMART_PERSIST_DB)
    entry = {
        "query": clean_query,
        "mode": clean_mode,
        "freeOnly": bool(free_only),
        "savedAt": now,
        "origin": origin,
        "count": len(clean_rows),
        "products": clean_rows,
        "info": safe_info,
    }
    content_hash = _indiamart_snapshot_hash(clean_rows)
    with _indiamart_persist_lock:
        changed = _write_indiamart_sqlite_entry_unlocked(key, entry, content_hash)
    print("[INDIAMART SAVE] query=%r mode=%s rows=%d origin=%s changed=%s db=%s" % (
        clean_query, clean_mode, len(clean_rows), origin, changed, INDIAMART_PERSIST_DB
    ), flush=True)
    return {
        "ok": True, "saved": True, "changed": bool(changed), "count": len(clean_rows), "query": clean_query,
        "mode": clean_mode, "freeOnly": bool(free_only), "savedAt": now,
        "persistentFile": str(INDIAMART_PERSIST_DB),
    }

def _load_persisted_indiamart_results(query, mode="standard", free_only=True):
    clean_query = _clean_text(query)
    if not clean_query:
        return [], {}
    keys = [_indiamart_persist_key(clean_query, mode, free_only)]
    corrected = _correct_obvious_query_typos(clean_query) or clean_query
    if corrected.casefold() != clean_query.casefold():
        keys.append(_indiamart_persist_key(corrected, mode, free_only))
    entry = None
    with _indiamart_persist_lock:
        for key in keys:
            try:
                candidate = _load_indiamart_sqlite_entry_unlocked(key)
            except Exception as exc:
                print("[INDIAMART SQLITE] read failed:", exc, flush=True)
                candidate = None
            if isinstance(candidate, dict):
                entry = candidate
                break
        if entry is None:
            legacy = _read_indiamart_persist_store_unlocked()
            entries = legacy.get("entries") or {}
            entry = next((entries.get(k) for k in keys if isinstance(entries.get(k), dict)), None)
    if not entry:
        return [], {}
    rows = [dict(r) for r in (entry.get("products") or []) if isinstance(r, dict)]
    saved_at = float(entry.get("savedAt") or 0)
    age_hours = max(0.0, time.time() - saved_at) / 3600.0 if saved_at else 0.0
    info = dict(entry.get("info") or {})
    info.update({
        "ok": bool(rows), "persisted": True, "persistedFallback": True,
        "persistedAt": saved_at, "persistedOrigin": entry.get("origin") or "disk",
        "persistentFile": str(INDIAMART_PERSIST_DB), "count": len(rows),
        "dataStatus": "stale" if age_hours >= (INDIAMART_STALE_CACHE_SECONDS / 3600.0) else "saved",
        "snapshotAgeHours": round(age_hours, 2), "snapshotSavedAt": saved_at,
    })
    return rows, info

def _load_persisted_indiamart_results_any_mode(query, preferred_mode="standard", free_only=True):
    """Load newest durable result for this exact/corrected query across modes."""
    clean_query = _clean_text(query)
    if not clean_query:
        return [], {}
    modes = []
    for candidate in (_normalize_search_mode(preferred_mode), "standard", "minimum", "deep"):
        if candidate not in modes:
            modes.append(candidate)
    corrected = _correct_obvious_query_typos(clean_query) or clean_query
    query_forms = [clean_query]
    if corrected.casefold() != clean_query.casefold():
        query_forms.append(corrected)
    best = None
    with _indiamart_persist_lock:
        for q in query_forms:
            for candidate_mode in modes:
                key = _indiamart_persist_key(q, candidate_mode, free_only)
                try:
                    entry = _load_indiamart_sqlite_entry_unlocked(key)
                except Exception:
                    entry = None
                if isinstance(entry, dict) and entry.get("products"):
                    if best is None or float(entry.get("savedAt") or 0) > float(best.get("savedAt") or 0):
                        best = entry
        if best is None:
            legacy = _read_indiamart_persist_store_unlocked()
            entries = legacy.get("entries") or {}
            for q in query_forms:
                for candidate_mode in modes:
                    entry = entries.get(_indiamart_persist_key(q, candidate_mode, free_only))
                    if not isinstance(entry, dict) or not entry.get("products"):
                        continue
                    if best is None or float(entry.get("savedAt") or 0) > float(best.get("savedAt") or 0):
                        best = entry
    if not best:
        return [], {}
    rows = [dict(r) for r in (best.get("products") or []) if isinstance(r, dict)]
    saved_at = float(best.get("savedAt") or 0)
    age_hours = max(0.0, time.time() - saved_at) / 3600.0 if saved_at else 0.0
    info = dict(best.get("info") or {})
    info.update({
        "ok": bool(rows), "persisted": True, "persistedFallback": True,
        "persistedAt": saved_at, "persistedOrigin": best.get("origin") or "disk",
        "persistentFile": str(INDIAMART_PERSIST_DB), "persistedSearchMode": best.get("mode") or preferred_mode,
        "count": len(rows),
        "dataStatus": "stale" if age_hours >= (INDIAMART_STALE_CACHE_SECONDS / 3600.0) else "saved",
        "snapshotAgeHours": round(age_hours, 2), "snapshotSavedAt": saved_at,
    })
    return rows, info

def _indiamart_persisted_search_count():
    try:
        with _indiamart_persist_lock:
            conn = _ensure_indiamart_sqlite_unlocked()
            try:
                count = int(conn.execute("SELECT COUNT(*) FROM indiamart_searches").fetchone()[0])
            finally:
                conn.close()
            if count:
                return count
            legacy = _read_indiamart_persist_store_unlocked()
            return len(legacy.get("entries") or {})
    except Exception:
        return 0


_price_async_lock = threading.RLock()
_price_async_thread = None
_price_cache = {
    "products": [],
    "loaded_at": 0.0,
    "loading": False,
    "error": "",
    "sheets": [],
}

# V16.7: lightweight in-memory keyword index. It is rebuilt in the background
# whenever the Sheet/cache is replaced, so 100k+ row searches do not need to
# scan every row for ordinary multi-word queries. Search still falls back to
# the original full scan if the index is not ready.
_price_keyword_lock = threading.RLock()
_price_keyword_index = {}
_price_keyword_index_loaded_at = 0.0
_price_keyword_index_building = False


def _clear_price_search_cache():
    with _price_search_lock:
        _price_search_cache.clear()


def _remember_price_search(query, loaded_at, rows):
    key = (_clean_text(query).lower(), float(loaded_at or 0))
    with _price_search_lock:
        _price_search_cache[key] = rows
        _price_search_cache.move_to_end(key)
        while len(_price_search_cache) > PRICE_SEARCH_CACHE_MAX:
            _price_search_cache.popitem(last=False)


def _cached_price_search(query, loaded_at):
    key = (_clean_text(query).lower(), float(loaded_at or 0))
    with _price_search_lock:
        rows = _price_search_cache.get(key)
        if rows is not None:
            _price_search_cache.move_to_end(key)
        return rows


def _persist_price_cache(products, sheets):
    """Persist the live price index so the next app launch can start instantly."""
    if not products:
        return
    try:
        cache_dir = RUNTIME_CACHE_DIR
        cache_dir.mkdir(parents=True, exist_ok=True)
        target = cache_dir / f"source_{PRICE_SHEET_ID}.json"
        tmp = target.with_suffix(target.suffix + ".tmp")
        payload = {"products": products, "sheets": sheets, "saved_at": time.time()}
        tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, target)
        print(f"[PRICE INDEX] Saved fast-start cache: {len(products)} products -> {target}")
    except Exception as exc:
        print(f"[PRICE INDEX] Fast-start cache save skipped: {exc}")


def _v108_cache_candidates():
    """Known cache locations used by Instrument Register V10.8.

    The full register can be very large, so reuse the already-synced local
    cache instead of forcing a fresh Google Sheet read on every NUNES build.
    """
    name = f"source_{PRICE_SHEET_ID}.json"
    paths = []
    local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
    if local_appdata:
        paths.append(Path(local_appdata) / "NunesInstrumentRegister" / "app_cache" / name)
    paths.extend([
        RUNTIME_CACHE_DIR / name,
        Path(BASE_DIR) / "cache" / name,
        Path(BASE_DIR).parent / "Instrument_Register_V10_8_FAST_VERSION_SAFE" / "cache" / name,
        Path(BASE_DIR) / "Instrument_Register_V10_8_FAST_VERSION_SAFE" / "cache" / name,
    ])
    unique=[]
    seen=set()
    for path in paths:
        key=str(path).lower()
        if key not in seen:
            seen.add(key); unique.append(path)
    return unique


def _product_from_v108_cache(row):
    if not isinstance(row, dict):
        return None
    name=_clean_text(row.get("product_name"))
    if not name:
        return None
    p={field:_clean_text(row.get(field)) for field in PRICE_ALIASES}
    p["product_name"]=name
    remote=_clean_text(row.get("image_remote"))
    direct=_clean_text(row.get("image_link") or row.get("image_url"))
    if remote:
        p["image_link"]=_normalize_image_link(remote)
    elif direct and not direct.startswith("/api/"):
        p["image_link"]=_normalize_image_link(direct)
    p["source_sheet"]=_clean_text(row.get("source_sheet"))
    p["source_row"]=row.get("source_row") or ""
    p["source_type"]=_clean_text(row.get("source_type")) or "google_sheet"
    p["search_text"]=_product_search_text(p)
    return p


def _load_v108_full_cache():
    """Load the largest valid V10.8 cache found on this PC."""
    best=[]
    best_path=None
    for path in _v108_cache_candidates():
        try:
            if not path.is_file():
                continue
            payload=json.loads(path.read_text(encoding="utf-8"))
            raw=payload.get("products") if isinstance(payload,dict) else None
            if not isinstance(raw,list) or not raw:
                continue
            rows=[]
            append=rows.append
            for item in raw:
                p=_product_from_v108_cache(item)
                if p:
                    append(p)
            if len(rows)>len(best):
                best=rows; best_path=path
        except Exception as exc:
            print(f"[PRICE INDEX] Cache read skipped {path}: {exc}")
    if best:
        # Excel/Drive price register must preserve every real source row.  Do not
        # collapse repeated product/model/supplier offers here: users explicitly
        # need the full price history/list.  IndiaMART has its own dedupe below.
        sheets=sorted({_clean_text(x.get("source_sheet")) for x in best if _clean_text(x.get("source_sheet"))})
        print(f"[PRICE INDEX] Reused V10.8 cache: {len(best)} source rows from {best_path}")
        return best, sheets, str(best_path)
    return [], [], ""

PRICE_ALIASES = {
    "product_name": ["product name", "product", "item name", "instrument name", "equipment name", "product description", "name"],
    "model": ["model", "model no", "model no.", "model number", "model id", "part no", "part no.", "part number", "catalogue no", "catalog no", "code"],
    "specs": ["specification", "specifications", "spec", "technical specification", "technical specifications", "details", "product details", "description/specification"],
    "purchase_price": ["purchase price", "unit price", "offer price", "selling price", "price", "rate", "cost", "amount", "quoted price"],
    "price_date": ["price date", "purchase price date", "price updated date", "last price date"],
    "supplier": ["supplier name", "supplier", "vendor", "vendor name", "manufacturer", "company", "brand"],
    "contact": ["supplier contect details", "supplier contact details", "supplier contact", "contact", "contact no", "contact no.", "phone", "mobile", "whatsapp", "email"],
    "category": ["category", "product category", "type", "group"],
    "product_link": ["product link", "indiamart link", "indiamart url", "website", "url", "link", "catalogue link", "datasheet link", "product url"],
    "image_link": ["image link", "image url", "picture link", "picture url", "photo link", "photo url", "product image", "product photo", "product picture", "picture", "photo", "pic", "thumbnail", "image address", "image path", "image"],
    "marketing_person": ["marketing person", "marketing owner", "person"],
    "purchase_owner": ["purchase owner", "buyer", "purchase person"],
}
PRICE_ALL_HEADERS = {a for values in PRICE_ALIASES.values() for a in values}


def _clean_text(value):
    if value is None:
        return ""
    text = str(value).strip()
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip()


PRICE_SEARCH_FIELDS = ("product_name", "model", "specs", "supplier", "category")


def _product_search_text(product):
    return " ".join(_clean_text(product.get(k)) for k in PRICE_SEARCH_FIELDS).lower()


# Conservative industrial-instrument aliases used only to widen matching. The
# exact query always ranks first; these aliases do not replace the user's words.
# Safe typo repairs are intentionally narrow: only obvious spelling mistakes that
# otherwise make all free IndiaMART discovery sources miss the intended product.
# Model numbers and arbitrary product words are never fuzzy-rewritten.
SEARCH_TYPO_CORRECTIONS = {
    "mositure": "moisture",
    "moisutre": "moisture",
    "multimter": "multimeter",
    "multimetr": "multimeter",
}

def _correct_obvious_query_typos(value):
    text = _clean_text(value)
    if not text:
        return ""
    words = re.findall(r"[a-z0-9]+", text.lower())
    if not words:
        return text
    fixed = [SEARCH_TYPO_CORRECTIONS.get(word, word) for word in words]
    if fixed == words:
        return text
    return " ".join(fixed)


SEARCH_WORD_ALIASES = {
    "pipe": ("tube", "tubing"),
    "tube": ("pipe", "tubing"),
    "cutting": ("cutter", "cut"),
    "cutter": ("cutting", "cut"),
    "machine": ("equipment", "apparatus"),
    "equipment": ("machine", "apparatus"),
    "apparatus": ("equipment", "machine"),
    "instrument": ("meter", "tester", "equipment"),
    "meter": ("gauge", "tester", "instrument"),
    "gauge": ("meter", "indicator"),
    "tester": ("testing", "test", "meter"),
    "testing": ("tester", "test"),
    "analyzer": ("analyser", "meter"),
    "analyser": ("analyzer", "meter"),
    "monitor": ("detector", "meter"),
    "detector": ("monitor", "sensor"),
    "sensor": ("probe", "transmitter"),
    "transmitter": ("sensor",),
    "gas": ("gases",),
    "gases": ("gas",),
    "leak": ("leakage", "leaker"),
    "leakage": ("leak", "leaker"),
    "leaker": ("leak", "leakage"),
    "detecto": ("detector",),
    "detectors": ("detector", "monitor", "sensor"),
    "meters": ("meter", "gauge", "tester"),
    "testers": ("tester", "meter", "testing"),
    "sensors": ("sensor", "probe", "transmitter"),
    "monitors": ("monitor", "detector", "meter"),
    "temperature": ("temp",),
    "motorised": ("motorized", "electric"),
    "motorized": ("motorised", "electric"),
    "stainless": ("ss",),
}

SEARCH_QUERY_MODIFIERS = {
    "stainless", "steel", "digital", "analog", "analogue", "automatic", "manual",
    "portable", "industrial", "laboratory", "lab", "precision", "heavy", "duty",
    "high", "low", "mini", "micro", "electronic", "electric",
}

SEARCH_QUERY_GENERIC = {
    "product", "products", "instrument", "instruments", "equipment", "device", "system"
}

# Used only for fallback discovery/category URLs when the typed phrase is short
# or incomplete, e.g. "gas leak" -> "gas leak detector". Exact search still
# runs first and ranking keeps better matches at the top.
SEARCH_COMPLETION_NOUNS = (
    "detector", "meter", "tester", "analyzer", "analyser", "sensor", "monitor", "gauge", "equipment"
)


def _query_words(value):
    return [x for x in re.findall(r"[a-z0-9]+", _clean_text(value).lower()) if len(x) > 1]


def _model_match_tier(query, product):
    """Return (tier, label, confidence) without excluding normal product matches.

    Tier 3 is an exact model, tier 2 is the same model/series, tier 1 is an exact
    product phrase, and tier 0 is a normal relevance match. This only changes
    ranking/metadata; it does not remove the existing broader workflow.
    """
    q = _clean_text(query).lower()
    model = _clean_text((product or {}).get("model")).lower()
    name = _clean_text((product or {}).get("product_name")).lower()
    if not q:
        return 0, "general", 0
    q_compact = re.sub(r"[^a-z0-9]+", "", q)
    m_compact = re.sub(r"[^a-z0-9]+", "", model)
    query_tokens = _query_words(q)
    model_tokens = [t for t in query_tokens if any(ch.isdigit() for ch in t)]
    if model and q == model:
        return 3, "exact_model", 100
    if q_compact and m_compact and q_compact == m_compact:
        return 3, "exact_model", 100
    if model_tokens and model:
        normalized_model_tokens = set(_query_words(model))
        exact_tokens = all(t in normalized_model_tokens for t in model_tokens)
        contained = all(re.sub(r"[^a-z0-9]+", "", t) in m_compact for t in model_tokens)
        # Brand + exact model searches such as "Fluke 87V" should be in the
        # Exact Model group even when the model column contains only "87V".
        non_model_tokens = [t for t in query_tokens if t not in model_tokens and t not in SEARCH_QUERY_GENERIC and t not in SEARCH_QUERY_MODIFIERS]
        name_tokens = set(_query_words(name))
        brand_context = (not non_model_tokens) or all(t in name_tokens for t in non_model_tokens)
        model_compact_from_query = "".join(re.sub(r"[^a-z0-9]+", "", t) for t in model_tokens)
        if (exact_tokens or contained) and brand_context and (m_compact == model_compact_from_query or exact_tokens):
            return 3, "exact_model", 98
        if exact_tokens or contained:
            return 2, "same_model_series", 92
    if q == name or (q and q in name):
        return 1, "exact_product", 82
    return 0, "general", 65


def _query_word_groups(value):
    """Return one alias group per user word; original spelling is always first."""
    groups = []
    for token in _query_words(value):
        variants = [token]
        for alias in SEARCH_WORD_ALIASES.get(token, ()):
            alias = _clean_text(alias).lower()
            if alias and alias not in variants:
                variants.append(alias)
        groups.append(tuple(variants))
    return groups


def _search_query_variants(value, mode="standard"):
    """Generate a deterministic exact -> corrected -> relaxed keyword ladder.

    The UI often receives copied model descriptions or partially typed words.  The
    exact phrase is always searched first, then safe spelling/prefix repairs and
    shorter product phrases are tried. This is generic rather than product-specific.
    """
    original = _clean_text(value)
    corrected = _correct_obvious_query_typos(original)
    # Build the widening ladder from the corrected spelling, while retaining the
    # user's exact text as variant #1 so model/product text is never silently lost.
    words = _query_words(corrected or original)
    if not words:
        return []
    mode = _normalize_search_mode(mode)
    cap = 4 if mode == "minimum" else (10 if mode == "standard" else 20)
    variants = []
    seen = set()

    def add(parts):
        text = _clean_text(" ".join(parts) if isinstance(parts, (list, tuple)) else parts)
        key = text.casefold()
        if text and key not in seen:
            seen.add(key)
            variants.append(text)

    add(original)
    if corrected and corrected.casefold() != original.casefold():
        add(corrected)

    # Repair a partially typed final product noun (e.g. detecto -> detector) and
    # a few common plural/wording forms using the existing controlled dictionary.
    vocab = set(SEARCH_COMPLETION_NOUNS)
    vocab.update(SEARCH_WORD_ALIASES.keys())
    for aliases in SEARCH_WORD_ALIASES.values():
        vocab.update(str(x).lower() for x in aliases)
    repaired = list(words)
    changed = False
    for i, token in enumerate(repaired):
        if token in SEARCH_WORD_ALIASES and len(SEARCH_WORD_ALIASES[token]) == 1:
            candidate = SEARCH_WORD_ALIASES[token][0]
            if token in {"detecto"}:
                repaired[i] = candidate; changed = True; continue
        if len(token) >= 4 and token not in vocab:
            matches = sorted(x for x in vocab if x.startswith(token) and len(x) <= len(token) + 4)
            if len(matches) == 1:
                repaired[i] = matches[0]
                changed = True
    if changed:
        add(repaired)

    # Remove descriptive/material words but preserve the actual product/action.
    core = [w for w in repaired if w not in SEARCH_QUERY_MODIFIERS]
    if len(core) >= 2:
        add(core)

    # Common machine/cutter wording used by supplier listings.
    if "cutting" in repaired and "machine" in repaired:
        replaced = list(repaired)
        try:
            ci = replaced.index("cutting")
            mi = replaced.index("machine", ci + 1)
            if mi == ci + 1:
                replaced[ci:mi + 1] = ["cutter"]
                add(replaced)
                reduced = [w for w in replaced if w not in SEARCH_QUERY_MODIFIERS]
                if len(reduced) >= 2:
                    add(reduced)
        except ValueError:
            pass

    # Useful tail/core phrases. These make long copied descriptions and noisy
    # searches reach the shorter phrase suppliers actually use on IndiaMART.
    if len(core) >= 3:
        add(core[-3:])
        add(core[-2:])
        add(core[:2])
        if core[0] != core[-1]:
            add([core[0], core[-1]])
    elif len(core) == 2:
        add(core)
    if len(repaired) >= 4:
        add(repaired[-3:])
    if len(repaired) >= 5:
        add(repaired[-4:])

    # Controlled one-word synonyms, prioritized before weaker completions.
    alias_cap = 2 if mode == "minimum" else (8 if mode == "standard" else 20)
    alias_added = 0
    base_words = list(core or repaired)
    for i, word in enumerate(base_words):
        for alias in SEARCH_WORD_ALIASES.get(word, ()):
            synonym = list(base_words)
            synonym[i] = alias
            before = len(variants)
            add(synonym)
            if len(variants) > before:
                alias_added += 1
            if alias_added >= alias_cap:
                break
        if alias_added >= alias_cap:
            break

    # Short/incomplete searches get controlled product noun completions.
    useful_words = [w for w in (core or repaired) if w not in SEARCH_QUERY_GENERIC]
    has_product_noun = any(w in SEARCH_COMPLETION_NOUNS for w in useful_words)
    if mode != "minimum" and useful_words and (len(useful_words) <= 3 or not has_product_noun):
        noun_cap = 3 if mode == "standard" else 7
        added_nouns = 0
        prefix = useful_words[:]
        if len(prefix) > 3:
            prefix = prefix[-2:]
        for noun in SEARCH_COMPLETION_NOUNS:
            before = len(variants)
            if noun not in prefix:
                add(prefix + [noun])
            if len(variants) > before:
                added_nouns += 1
            if added_nouns >= noun_cap:
                break

    return variants[:cap]


def _norm_header(value):
    text = _clean_text(value).lower()
    text = re.sub(r"[_\-]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" .:")


def _logical_price_key(product):
    """Unicode-safe logical offer key used only where duplicate hiding is requested."""
    def norm(value):
        text = unicodedata.normalize("NFKC", _clean_text(value)).casefold()
        # Keep Unicode letters, combining marks and numbers (Hindi/Tamil/Arabic/
        # CJK etc.) while turning punctuation into spaces.
        text = ''.join(ch if unicodedata.category(ch)[:1] in {'L', 'M', 'N'} else ' ' for ch in text)
        return re.sub(r"\s+", " ", text).strip()

    name = norm(product.get("product_name"))
    model = norm(product.get("model"))
    supplier = norm(product.get("supplier"))
    # With model/supplier information, those fields identify a logical offer.
    # When both are absent, include price/category so similarly-named variants
    # are not over-collapsed.
    if model or supplier:
        return (name, model, supplier)
    return (name, norm(product.get("purchase_price")), norm(product.get("category")))


def _price_row_quality(product):
    score = 0
    for field, weight in (
        ("purchase_price", 8), ("image_link", 7), ("product_link", 6),
        ("supplier", 5), ("contact", 4), ("price_date", 4),
        ("model", 3), ("specs", 2), ("category", 1),
    ):
        if _clean_text(product.get(field)):
            score += weight
    try:
        score += min(int(product.get("source_row") or 0), 1000000) / 10000000.0
    except Exception:
        pass
    return score


def _merge_duplicate_price_rows(a, b):
    # Prefer the richer/later-looking row, then fill any missing fields from
    # its duplicate. Different suppliers are never merged because they have
    # different logical keys.
    preferred, other = (b, a) if _price_row_quality(b) >= _price_row_quality(a) else (a, b)
    merged = dict(preferred)
    for field in PRICE_ALIASES:
        if not _clean_text(merged.get(field)) and _clean_text(other.get(field)):
            merged[field] = other.get(field)
    for field in ("source_sheet", "source_row", "source_type", "search_text"):
        if not merged.get(field) and other.get(field):
            merged[field] = other.get(field)
    merged["duplicate_count"] = int(a.get("duplicate_count") or 1) + int(b.get("duplicate_count") or 1)
    merged["search_text"] = _product_search_text(merged)
    return merged


def _dedupe_display_products(products):
    """Hide logical duplicates while retaining distinct supplier offers."""
    output = []
    index = {}
    for raw in products or []:
        if not isinstance(raw, dict) or not _clean_text(raw.get("product_name")):
            continue
        item = dict(raw)
        item.setdefault("duplicate_count", 1)
        key = _logical_price_key(item)
        if not key[0]:
            continue
        pos = index.get(key)
        if pos is None:
            index[key] = len(output)
            output.append(item)
        else:
            output[pos] = _merge_duplicate_price_rows(output[pos], item)
    return output



# Lightweight English normalization for visible price-list text.  Translation is
# attempted only when a field contains non-Latin letters, cached in memory, and
# failure-safe: source text remains untouched if the public translation endpoint
# is unavailable.  This avoids slowing the normal all-English register.
_translation_lock = threading.RLock()
_translation_cache = OrderedDict()
TRANSLATION_CACHE_MAX = 4000
TRANSLATION_TIMEOUT = 2.8


def _needs_english_translation(value):
    text = _clean_text(value)
    if not text:
        return False
    saw_letter = False
    for ch in text:
        if not ch.isalpha():
            continue
        saw_letter = True
        name = unicodedata.name(ch, '')
        if 'LATIN' not in name:
            return True
    return False if saw_letter else False


def _translate_text_to_english(value):
    text = _clean_text(value)
    if not text or not _needs_english_translation(text):
        return text
    key = text
    with _translation_lock:
        cached = _translation_cache.get(key)
        if cached is not None:
            _translation_cache.move_to_end(key)
            return cached
    translated = text
    try:
        url = (
            'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q='
            + quote(text)
        )
        req = Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36',
            'Accept-Language': 'en-IN,en;q=0.9',
        })
        with urlopen(req, timeout=TRANSLATION_TIMEOUT) as response:
            payload = json.loads(response.read(512 * 1024).decode('utf-8', errors='replace') or '[]')
        pieces = payload[0] if isinstance(payload, list) and payload else []
        candidate = ''.join(str(part[0]) for part in pieces if isinstance(part, list) and part and part[0])
        candidate = _clean_text(candidate)
        if candidate:
            translated = candidate
    except Exception:
        translated = text
    with _translation_lock:
        _translation_cache[key] = translated
        _translation_cache.move_to_end(key)
        while len(_translation_cache) > TRANSLATION_CACHE_MAX:
            _translation_cache.popitem(last=False)
    return translated


def _translate_rows_to_english(rows):
    rows = [dict(r) for r in (rows or [])]
    jobs = []
    fields = ('product_name', 'supplier', 'category', 'location', 'supplier_location', 'specs')
    for idx, row in enumerate(rows):
        for field in fields:
            value = _clean_text(row.get(field))
            if value and _needs_english_translation(value):
                jobs.append((idx, field, value))
    if not jobs:
        return rows, 0
    unique = list(dict.fromkeys(value for _, _, value in jobs))
    translated_map = {}
    # Limit worker fan-out; requests are short and only run for genuinely
    # non-English strings.  Cached strings return instantly.
    with ThreadPoolExecutor(max_workers=min(8, len(unique))) as pool:
        futures = {value: pool.submit(_translate_text_to_english, value) for value in unique}
        for value, future in futures.items():
            try:
                translated_map[value] = future.result()
            except Exception:
                translated_map[value] = value
    changed = 0
    for idx, field, value in jobs:
        translated = translated_map.get(value, value)
        if translated and translated != value:
            rows[idx][field] = translated
            changed += 1
    for row in rows:
        row['search_text'] = _product_search_text(row)
    return rows, changed


def _canonical_indiamart_url(value):
    raw = value
    value = _indiamart_abs_url(value, value) if value else ''
    # Verified IndiaMART-managed seller storefronts can live on the seller's own
    # domain. Keep their URL stable for dedupe after the managed-site fallback.
    if not value and raw:
        try:
            value = _generic_http_url(raw, raw)
        except Exception:
            value = ''
    if not value:
        return ''
    try:
        parsed = urlparse(value)
        host = (parsed.hostname or '').lower()
        path = re.sub(r'/+', '/', parsed.path or '/').rstrip('/').lower()
        return host + path
    except Exception:
        return value.split('#', 1)[0].split('?', 1)[0].strip().lower()


def _normalise_indiamart_company(value):
    """Normalize only formatting differences so the same company compares equal."""
    text = unicodedata.normalize("NFKC", _clean_text(value)).casefold()
    text = text.replace('&', ' and ')
    text = ''.join(ch if unicodedata.category(ch)[:1] in {'L', 'M', 'N'} else ' ' for ch in text)
    return re.sub(r"\s+", " ", text).strip()


def _normalise_indiamart_price_key(value):
    """Return a stable numeric IndiaMART price key (₹7,000 == Rs 7000 == INR 7000)."""
    text = unicodedata.normalize("NFKC", _clean_text(value)).casefold().replace(',', '')
    m = re.search(r'(?<![a-z0-9])(-?\d+(?:\.\d+)?)', text)
    if not m:
        return ''
    try:
        number = float(m.group(1))
        if number.is_integer():
            return str(int(number))
        return ('%.6f' % number).rstrip('0').rstrip('.')
    except Exception:
        return m.group(1)


def _indiamart_offer_dedupe_key(item):
    """User rule: duplicate means same IndiaMART company AND same numeric price.

    If either company or price is unavailable, keep distinct listings and only
    collapse an exact repeated product URL. This avoids hiding legitimate offers.
    """
    supplier = _normalise_indiamart_company(item.get('supplier'))
    price = _normalise_indiamart_price_key(item.get('purchase_price'))
    if supplier and price:
        return ('supplier_price', supplier, price)
    link_key = _canonical_indiamart_url(item.get('product_link'))
    if link_key:
        return ('url', link_key)
    # No company+price and no stable URL: keep the row. This intentionally avoids
    # logical-name collapsing because the requested duplicate rule is ONLY same
    # company + same numeric price (plus exact repeated URL for the same listing).
    return ('keep_distinct', id(item))


def _dedupe_indiamart_products(rows):
    """Remove IndiaMART duplicates using same-company + same-price as the rule."""
    output = []
    index = {}
    for raw in rows or []:
        if not isinstance(raw, dict) or not _clean_text(raw.get('product_name')):
            continue
        item = dict(raw)
        key = _indiamart_offer_dedupe_key(item)
        pos = index.get(key)
        if pos is None:
            index[key] = len(output)
            output.append(item)
        else:
            output[pos] = _merge_duplicate_price_rows(output[pos], item)
    return output

def _html_to_text(fragment):
    text = re.sub(r"<script\b[^>]*>.*?</script>", " ", fragment or "", flags=re.I | re.S)
    text = re.sub(r"<style\b[^>]*>.*?</style>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html_lib.unescape(text)
    return _clean_text(text)


def _indiamart_abs_url(value, base="https://dir.indiamart.com/"):
    value = html_lib.unescape(_clean_text(value))
    if not value:
        return ""
    if value.startswith("//"):
        value = "https:" + value
    value = urljoin(base, value)
    try:
        parsed = urlparse(value)
        host = (parsed.hostname or "").lower()
        if host == "indiamart.com" or host.endswith(".indiamart.com"):
            return value
    except Exception:
        pass
    return ""


def _first_regex(text, patterns):
    for pattern in patterns:
        m = re.search(pattern, text or "", flags=re.I | re.S)
        if m:
            return _clean_text(html_lib.unescape(m.group(1)))
    return ""


def _indiamart_price(value):
    value = _clean_text(html_lib.unescape(value))
    if not value:
        return ""
    # Normalize common IndiaMART price formats while preventing the next sentence
    # or company name from being swallowed after the unit text.
    unit = r"(?:piece|pcs?|unit|nos?|number|set|pack|pair|box|roll|bottle|meter|metre|kg|kilogram|gram|g|litre|liter|l|ml|ton|feet|foot|sq\.?\s*ft|sqft|square\s+feet|month|day|hour)"
    m = re.search(r"(?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?(?:\s*(?:/|per)\s*" + unit + r")?", value, flags=re.I)
    if m:
        return _clean_text(m.group(0)).replace("Rs.", "₹").replace("Rs ", "₹ ")
    if re.fullmatch(r"[\d,]+(?:\.\d+)?", value):
        return "₹ " + value
    return value[:120]


def _indiamart_item_from_ld(obj, source_url):
    if not isinstance(obj, dict):
        return None
    item = obj.get("item") if isinstance(obj.get("item"), dict) else obj
    typ = item.get("@type")
    types = [str(x).lower() for x in typ] if isinstance(typ, list) else [str(typ or "").lower()]
    if not any(t in ("product", "offer") or "product" in t for t in types):
        return None
    name = _clean_text(item.get("name") or item.get("headline"))
    if not name:
        return None
    offers = item.get("offers")
    if isinstance(offers, list):
        offer = next((x for x in offers if isinstance(x, dict)), {})
    elif isinstance(offers, dict):
        offer = offers
    else:
        offer = item if "offer" in " ".join(types) else {}
    seller = offer.get("seller") if isinstance(offer.get("seller"), dict) else item.get("seller") if isinstance(item.get("seller"), dict) else {}
    brand = item.get("brand")
    if isinstance(brand, dict):
        brand = brand.get("name")
    image = item.get("image")
    if isinstance(image, list):
        image = image[0] if image else ""
    if isinstance(image, dict):
        image = image.get("url") or image.get("contentUrl") or ""
    link = _indiamart_abs_url(item.get("url") or offer.get("url") or source_url, source_url)
    price = offer.get("price") or offer.get("lowPrice") or item.get("price") or ""
    currency = _clean_text(offer.get("priceCurrency") or "")
    if price and currency and currency.upper() == "INR" and not re.search(r"₹|Rs|INR", str(price), re.I):
        price = "₹ " + str(price)
    return {
        "product_name": name,
        "model": _clean_text(item.get("model") or item.get("sku") or item.get("mpn")),
        "specs": _clean_text(item.get("description")),
        "purchase_price": _indiamart_price(str(price)),
        "price_date": "Live IndiaMART",
        "supplier": _clean_text(seller.get("name") or brand or ""),
        "contact": "",
        "category": "IndiaMART",
        "product_link": link,
        "image_link": _normalize_image_link(str(image or "")),
        "source_sheet": "IndiaMART Live",
        "source_row": link or name,
        "source_type": "indiamart",
    }


def _walk_indiamart_ld(obj, source_url, output):
    if isinstance(obj, dict):
        item = _indiamart_item_from_ld(obj, source_url)
        if item:
            output.append(item)
        for value in obj.values():
            if isinstance(value, (dict, list)):
                _walk_indiamart_ld(value, source_url, output)
    elif isinstance(obj, list):
        for value in obj:
            _walk_indiamart_ld(value, source_url, output)



def _generic_obj_value(obj, names):
    if not isinstance(obj, dict):
        return ""
    lower = {str(k).casefold(): v for k, v in obj.items()}
    for name in names:
        if name.casefold() not in lower:
            continue
        value = lower[name.casefold()]
        if isinstance(value, (str, int, float)):
            return _clean_text(value)
        if isinstance(value, dict):
            for nested in ("name", "value", "text", "url", "src", "displayValue", "display"):
                if nested in value and isinstance(value[nested], (str, int, float)):
                    return _clean_text(value[nested])
        if isinstance(value, list):
            for part in value[:4]:
                if isinstance(part, (str, int, float)) and _clean_text(part):
                    return _clean_text(part)
                if isinstance(part, dict):
                    nested = _generic_obj_value(part, ("name", "value", "text", "url", "src"))
                    if nested:
                        return nested
    return ""


def _indiamart_item_from_generic_obj(obj, source_url):
    """Read one product-like object from IndiaMART application JSON / NEXT_DATA.

    IndiaMART has changed its search-card markup several times.  The visible
    result list is often serialized in application/json even when there is no
    ordinary product <a> tag, so this deliberately keys off semantic fields
    rather than CSS classes.
    """
    if not isinstance(obj, dict) or len(obj) < 2:
        return None
    name = _generic_obj_value(obj, (
        "productName", "product_name", "prodName", "prdname", "productTitle",
        "itemName", "item_name", "pname", "title",
    ))
    link_raw = _generic_obj_value(obj, (
        "productUrl", "product_url", "prodUrl", "productLink", "product_link",
        "productURL", "landingUrl", "landing_url", "titleUrl", "desktopTitleUrl",
        "mobileTitleUrl", "url", "href",
    ))
    additional = obj.get("additionalFields") or obj.get("additional_fields")
    if not link_raw and isinstance(additional, dict):
        link_raw = _generic_obj_value(additional, (
            "titleUrl", "desktopTitleUrl", "mobileTitleUrl", "productUrl", "url"
        ))
    link = _indiamart_abs_url(link_raw, source_url) if link_raw else ""
    productish_link = bool(link and _indiamart_link_is_productish(link))

    supplier = _generic_obj_value(obj, (
        "companyName", "company_name", "compName", "supplierName", "supplier_name",
        "sellerName", "seller_name", "company", "seller",
    ))
    if not supplier:
        for nested_key in ("seller", "supplier", "company", "business", "vendor"):
            nested = obj.get(nested_key)
            if isinstance(nested, dict):
                supplier = _generic_obj_value(nested, ("name", "companyName", "company_name", "title"))
                if supplier:
                    break

    price_raw = _generic_obj_value(obj, (
        "displayPrice", "priceDisplay", "price_display", "priceText", "price_text",
        "priceRaw", "price_raw", "priceNumeric", "price_numeric", "productPrice",
        "fprice", "minPrice", "price", "rate",
    ))
    if not price_raw:
        offers = obj.get("offers") or obj.get("offer")
        if isinstance(offers, list):
            offers = next((x for x in offers if isinstance(x, dict)), {})
        if isinstance(offers, dict):
            price_raw = _generic_obj_value(offers, ("price", "lowPrice", "displayPrice", "priceText"))
    price = _indiamart_price(price_raw)

    # A generic "title" can refer to navigation/UI. Require at least one strong
    # product signal so menus and filters are never emitted as price rows.
    if not name or len(name) > 240 or not (productish_link or supplier or price):
        return None
    if name.casefold() in {"contact supplier", "get best price", "call now", "view more", "read more", "related categories"}:
        return None

    location = _generic_obj_value(obj, (
        "city", "location", "cityName", "sellerCity", "supplierCity", "sellerLocation",
        "supplierLocation", "area", "state",
    ))
    if not location:
        company_details = obj.get("companyDetails") or obj.get("company_details")
        if isinstance(company_details, dict):
            city = _generic_obj_value(company_details, ("city", "district", "state"))
            state = _generic_obj_value(company_details, ("state",))
            location = _clean_text((city + (", " + state if state and state.casefold() not in city.casefold() else "")))
    model = _generic_obj_value(obj, ("model", "modelNo", "modelNumber", "model_name", "sku", "mpn"))
    image = _generic_obj_value(obj, (
        "imageUrl", "image_url", "largeImageUrl", "large_image_url", "imageSrc",
        "image", "images", "imgUrl", "img", "thumbnail", "photo",
    ))
    if not image and isinstance(additional, dict):
        image = _generic_obj_value(additional, (
            "largeImage", "zoomedImage", "mainImage", "photo1000", "imageUrl", "image"
        ))
    if image.startswith("//"):
        image = "https:" + image
    elif image.startswith("/"):
        image = urljoin(source_url, image)
    description = _generic_obj_value(obj, (
        "description", "productDescription", "product_description", "specification",
        "specifications", "shortDescription", "short_description",
    ))
    contact = _normalise_indiamart_phone(_generic_obj_value(obj, (
        "mobile", "mobileNo", "phone", "phoneNo", "contactNo", "contact_number",
    )))
    return {
        "product_name": _clean_indiamart_title(name),
        "model": model,
        "specs": description[:1200],
        "purchase_price": price,
        "price_date": "Live IndiaMART",
        "supplier": supplier,
        "contact": contact,
        "location": location,
        "supplier_location": location,
        "category": ("IndiaMART · " + location) if location else "IndiaMART",
        "product_link": link if productish_link else "",
        "image_link": _normalize_image_link(image),
        "source_sheet": "IndiaMART Live",
        "source_row": link or (supplier + "|" + name + "|" + price),
        "source_type": "indiamart",
    }


def _walk_indiamart_generic_json(obj, source_url, output, budget=None):
    # A page can contain a very large hydration tree.  Bound the traversal while
    # still allowing thousands of product cards to be inspected cheaply.
    if budget is None:
        budget = [0, 160000]
    if budget[0] >= budget[1]:
        return
    budget[0] += 1
    if isinstance(obj, dict):
        item = _indiamart_item_from_generic_obj(obj, source_url)
        if item:
            output.append(item)
        for value in obj.values():
            if isinstance(value, (dict, list)):
                _walk_indiamart_generic_json(value, source_url, output, budget)
    elif isinstance(obj, list):
        for value in obj:
            if budget[0] >= budget[1]:
                break
            if isinstance(value, (dict, list)):
                _walk_indiamart_generic_json(value, source_url, output, budget)


def _indiamart_categoryish_url(value, base_url="https://dir.indiamart.com/"):
    url = _indiamart_abs_url(value, base_url)
    if not url:
        return ""
    try:
        p = urlparse(url)
        host = (p.hostname or "").lower()
        path = (p.path or "/").lower()
        if host.startswith("m."):
            return ""
        if "/impcat/" in path and path.endswith(".html"):
            return url
        # IndiaMART also has city/category landing pages on dir.indiamart.com.
        if host.startswith("dir.") and path.endswith(".html") and not any(
            token in path for token in ("/search.", "/proddetail/", "/product/", "/products/")
        ):
            return url
    except Exception:
        return ""
    return ""


def _extract_indiamart_related_urls(page, source_url, query="", limit=12):
    """Collect related IndiaMART category pages exposed by the fetched search page.

    This is the safe way to broaden a result like "PH Meter": IndiaMART itself
    exposes related lists such as pH Testers, Digital pH Meter, pH Analyzer,
    Pocket Tester and Benchtop pH Meter.  We follow those public category links
    instead of inventing unrelated products.
    """
    limit = max(0, min(int(limit or 0), 24))
    if not limit:
        return []
    query_tokens = {x for x in _query_words(query) if x not in SEARCH_QUERY_GENERIC}
    candidates = []
    seen = set()
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', page or "", flags=re.I | re.S):
        url = _indiamart_categoryish_url(m.group(1), source_url)
        if not url:
            continue
        key = _canonical_indiamart_url(url)
        if not key or key in seen:
            continue
        text = _html_to_text(m.group(2))
        hay = (text + " " + (urlparse(url).path or "")).casefold()
        overlap = sum(1 for token in query_tokens if token.casefold() in hay)
        # Prefer links that IndiaMART labels as related to the user's exact search.
        # If there are no useful tokens (rare), keep only explicit impcat links.
        if query_tokens and overlap <= 0:
            continue
        seen.add(key)
        candidates.append((overlap, len(text or ""), url))
    # Some hydration payloads contain the category URLs without visible anchors.
    expanded = html_lib.unescape(page or "").replace("\\/", "/")
    for raw in re.findall(r'https?://(?:dir\.)?indiamart\.com/(?:impcat/)?[^\s"\'<>]+\.html', expanded, flags=re.I):
        url = _indiamart_categoryish_url(raw, source_url)
        if not url:
            continue
        key = _canonical_indiamart_url(url)
        if not key or key in seen:
            continue
        hay = (urlparse(url).path or "").casefold()
        overlap = sum(1 for token in query_tokens if token.casefold() in hay)
        if query_tokens and overlap <= 0:
            continue
        seen.add(key)
        candidates.append((overlap, 0, url))
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [url for _, _, url in candidates[:limit]]


def _indiamart_seed_category_urls(query, mode="standard", limit=10):
    """Build public IndiaMART category candidates for *any* typed product.

    V16.8.13 proved this recovery path with ``ph meter``.  V16.8.14 makes the
    same logic generic: exact words, modifier-stripped words, controlled aliases,
    and conservative singular/plural noun forms are all tried.  Every URL is
    still derived from the user's own query; no unrelated catalog is crawled.
    """
    mode = _normalize_search_mode(mode)
    hard_cap = 10 if mode == "minimum" else (24 if mode == "standard" else 48)
    limit = max(0, min(int(limit or 0), hard_cap))
    if not limit:
        return []

    variants = _search_query_variants(query, mode) or [_clean_text(query)]
    original_words = _query_words(query)
    core_words = [w for w in original_words if w not in SEARCH_QUERY_MODIFIERS]
    generic_words = [w for w in core_words if w not in SEARCH_QUERY_GENERIC]
    out, seen = [], set()

    def noun_forms(word):
        word = re.sub(r'[^a-z0-9]+', '', str(word or '').lower())
        if not word:
            return []
        forms = [word]
        # Keep mass/invariant nouns stable; avoiding nonsense URL candidates also
        # saves requests and keeps the wide search fast.
        if word in {'equipment', 'apparatus', 'testing'}:
            return forms
        # Conservative English singular/plural transformations.  These are only
        # URL candidates; failed/nonexistent category pages are simply ignored.
        if len(word) > 3 and word.endswith('ies'):
            forms.append(word[:-3] + 'y')
        elif len(word) > 3 and word.endswith('es') and word[-3:-2] in {'s','x','z'}:
            forms.append(word[:-2])
        elif len(word) > 3 and word.endswith('s') and not word.endswith('ss'):
            forms.append(word[:-1])
        else:
            if word.endswith('y') and len(word) > 2 and word[-2] not in 'aeiou':
                forms.append(word[:-1] + 'ies')
            elif word.endswith(('ch', 'sh', 'x', 'z', 's')):
                forms.append(word + 'es')
            else:
                forms.append(word + 's')
        return list(dict.fromkeys(forms))

    def add_words(words):
        words = [re.sub(r'[^a-z0-9]+', '', w.lower()) for w in (words or [])]
        words = [w for w in words if w]
        if not words:
            return
        slug = '-'.join(words[:9]).strip('-')
        if not slug:
            return
        url = 'https://dir.indiamart.com/impcat/' + slug + '.html'
        key = url.lower()
        if key not in seen:
            seen.add(key)
            out.append(url)

    # Exact and modifier-stripped forms first so the most likely category pages
    # are fetched before weaker aliases.
    bases = []
    for words in (original_words, core_words, generic_words):
        if words and words not in bases:
            bases.append(words)
    for variant in variants:
        words = _query_words(variant)
        if words and words not in bases:
            bases.append(words)
        stripped = [w for w in words if w not in SEARCH_QUERY_MODIFIERS]
        if stripped and stripped not in bases:
            bases.append(stripped)

    for words in bases:
        add_words(words)
        if words:
            for noun in noun_forms(words[-1]):
                add_words(words[:-1] + [noun])
            # IndiaMART category naming sometimes uses one of the controlled noun
            # aliases (meter/tester/gauge, machine/equipment, etc.).
            for alias in SEARCH_WORD_ALIASES.get(words[-1], ()):
                add_words(words[:-1] + [alias])
                for noun in noun_forms(alias):
                    add_words(words[:-1] + [noun])
        # Short user searches may be descriptive but not complete product names.
        # Try only a small controlled set of common IndiaMART instrument nouns.
        if mode != "minimum" and 1 <= len(words) <= 3 and not any(w in SEARCH_COMPLETION_NOUNS for w in words):
            noun_cap = 2 if mode == "standard" else 6
            for noun in SEARCH_COMPLETION_NOUNS[:noun_cap]:
                add_words(words + [noun])
        if len(out) >= limit:
            break

    return out[:limit]

def _indiamart_result_count_hint(page):
    text = _html_to_text((page or "")[:400000])
    m = re.search(r'([\d,]+\+?)\s+products?\s+available', text, flags=re.I)
    return m.group(1) if m else ""

def _parse_indiamart_html(page, source_url):
    results = []
    # Strategy 1: schema.org JSON-LD (most stable when available).
    for script in re.findall(r"<script\b[^>]*type=[\"']application/ld\+json[\"'][^>]*>(.*?)</script>", page or "", flags=re.I | re.S):
        try:
            payload = json.loads(html_lib.unescape(script).strip())
            _walk_indiamart_ld(payload, source_url, results)
            _walk_indiamart_generic_json(payload, source_url, results)
        except Exception:
            continue

    # Strategy 1B: Next.js / hydration application JSON. Current IndiaMART search
    # pages can serialize the full visible listing feed here even when the DOM
    # initially contains only a handful of ordinary product anchors.
    for script in re.findall(r"<script\b[^>]*type=[\"']application/json[\"'][^>]*>(.*?)</script>", page or "", flags=re.I | re.S):
        raw = html_lib.unescape(script).strip()
        if not raw or raw[:1] not in "[{":
            continue
        try:
            payload = json.loads(raw)
            _walk_indiamart_generic_json(payload, source_url, results)
        except Exception:
            continue

    # Strategy 2: product-card links plus nearby card metadata. This is tolerant
    # of IndiaMART class-name changes because it keys off the actual product URL.
    anchors = list(re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", page or "", flags=re.I | re.S))
    product_matches = []
    image_starts = [m.start() for m in re.finditer(r'<img\b', page or '', flags=re.I)]
    for candidate in anchors:
        candidate_url = _indiamart_abs_url(candidate.group(1), source_url)
        low_candidate = (candidate_url or "").lower()
        if candidate_url and ("/proddetail/" in low_candidate or "/product/" in low_candidate or "product-detail" in low_candidate):
            product_matches.append(candidate)
    for product_pos, match in enumerate(product_matches):
        href = _indiamart_abs_url(match.group(1), source_url)
        if not href:
            continue
        anchor_text = _html_to_text(match.group(2))
        # Keep each product card isolated. The old +/- 3.5-5 KB window could
        # accidentally pull the supplier/price from the next IndiaMART card.
        nearby_images = [pos for pos in image_starts if pos < match.start() and match.start() - pos <= 2200]
        start = max(nearby_images) if nearby_images else max(0, match.start() - 700)
        next_start = product_matches[product_pos + 1].start() if product_pos + 1 < len(product_matches) else len(page)
        end = min(len(page), next_start, match.end() + 5200)
        region = page[start:end]
        product_name = _first_regex(region, [
            r'[\"\'](?:productName|product_name|prodName|prdname|productTitle|title)[\"\']\s*[:=]\s*[\"\']([^\"\']{2,180})',
        ]) or anchor_text
        if not product_name or len(product_name) > 220 or product_name.lower() in {"view more", "get best price", "contact supplier", "read more"}:
            continue
        supplier = _first_regex(region, [
            r'[\"\'](?:companyName|company_name|compName|supplierName|sellerName|seller_name)[\"\']\s*[:=]\s*[\"\']([^\"\']{2,160})',
            r'(?:Company|Supplier|Seller)\s*[:\-]\s*</?[^>]*>?\s*([^<]{2,120})',
        ])
        supplier_page = ""
        if not supplier:
            supplier, supplier_page = _indiamart_supplier_from_card_region(region, source_url)
        price_raw = _first_regex(region, [
            r'[\"\'](?:displayPrice|price|fprice|minPrice|productPrice)[\"\']\s*[:=]\s*[\"\']([^\"\']{1,80})[\"\']',
            r'[\"\'](?:displayPrice|price|fprice|minPrice|productPrice)[\"\']\s*[:=]\s*((?:₹|Rs\.?|INR)?\s*[\d,]+(?:\.\d+)?)',
            r'((?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?(?:\s*(?:/|per)\s*[A-Za-z .-]{1,30})?)',
        ])
        contact = _first_regex(region, [
            r'[\"\'](?:mobile|mobileNo|phone|phoneNo|contactNo|contact_number)[\"\']\s*[:=]\s*[\"\']([^\"\']{5,60})',
        ])
        location = _first_regex(region, [
            r'[\"\'](?:city|location|cityName)[\"\']\s*[:=]\s*[\"\']([^\"\']{2,100})',
        ])
        region_text = _html_to_text(region)
        if not location:
            location = _indiamart_card_location(region_text, supplier)
        model = _first_regex(region, [
            r'[\"\'](?:model|modelNo|modelNumber|sku|mpn)[\"\']\s*[:=]\s*[\"\']([^\"\']{1,100})',
        ])
        if not model:
            model = _indiamart_model_from_title(product_name)
        trust_specs = _indiamart_card_trust_specs(region_text)
        image = _first_regex(region, [
            r'<img\b[^>]*(?:data-src|data-original|src)=[\"\']([^\"\']+)[\"\'][^>]*>',
            r'[\"\'](?:image|imageUrl|image_url|imgUrl|img)[\"\']\s*[:=]\s*[\"\']([^\"\']+)',
        ])
        if image.startswith("//"):
            image = "https:" + image
        if image and image.startswith("/"):
            image = urljoin(source_url, image)
        results.append({
            "product_name": product_name,
            "model": model,
            "specs": trust_specs,
            "purchase_price": _indiamart_price(price_raw),
            "price_date": "Live IndiaMART",
            "supplier": supplier,
            "contact": contact,
            "category": ("IndiaMART · " + location) if location else "IndiaMART",
            "product_link": href,
            "supplier_page": supplier_page,
            "supplier_location": location,
            "image_link": _normalize_image_link(image),
            "source_sheet": "IndiaMART Directory / Live",
            "source_row": href,
            "source_type": "indiamart",
        })

    # Strategy 3: modern IndiaMART search pages can keep additional product cards
    # inside escaped JavaScript/JSON instead of ordinary <a> tags. Scan those
    # payloads too so every listing exposed by the fetched result page is kept.
    expanded_page = html_lib.unescape(page or '').replace('\\/', '/').replace('\\u0026', '&')
    expanded_page = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), expanded_page)
    raw_url_matches = []
    raw_url_matches.extend(re.finditer(
        r'https?://(?:[A-Za-z0-9-]+\.)*indiamart\.com/[^\s"\'<>\\]+',
        expanded_page, flags=re.I))
    raw_url_matches.extend(re.finditer(
        r'["\'](/(?:proddetail|product|products)/[^"\']+)["\']',
        expanded_page, flags=re.I))
    for match in raw_url_matches:
        raw_value = match.group(1) if match.lastindex else match.group(0)
        href = _indiamart_abs_url(raw_value, source_url)
        if not href or not _indiamart_link_is_productish(href):
            continue
        # Prefer the nearest JSON object around this URL. It prevents values from
        # neighboring cards being paired with the wrong product when many cards
        # are serialized into one large JavaScript array.
        obj_start = expanded_page.rfind('{', max(0, match.start() - 2800), match.start())
        obj_end = expanded_page.find('}', match.end(), min(len(expanded_page), match.end() + 2800))
        if obj_start >= 0 and obj_end > match.end():
            region = expanded_page[obj_start:obj_end + 1]
        else:
            start = max(0, match.start() - 1200)
            end = min(len(expanded_page), match.end() + 1600)
            region = expanded_page[start:end]
        product_name = _first_regex(region, [
            r'["\'](?:productName|product_name|prodName|prdname|productTitle|itemName|item_name|pname)["\']\s*[:=]\s*["\']([^"\']{2,180})',
        ])
        if not product_name:
            try:
                slug = (urlparse(href).path.rsplit('/', 1)[-1] or '').rsplit('.', 1)[0]
                slug = re.sub(r'[-_]?\d{5,}$', '', slug)
                product_name = _clean_text(re.sub(r'[-_]+', ' ', slug))
                if product_name:
                    product_name = product_name[:1].upper() + product_name[1:]
            except Exception:
                product_name = ''
        if not product_name or len(product_name) > 220:
            continue
        supplier = _first_regex(region, [
            r'["\'](?:companyName|company_name|compName|supplierName|sellerName|seller_name|company)["\']\s*[:=]\s*["\']([^"\']{2,160})',
        ])
        price_raw = _first_regex(region, [
            r'["\'](?:displayPrice|price|fprice|minPrice|productPrice|priceText)["\']\s*[:=]\s*["\']([^"\']{1,80})["\']',
            r'["\'](?:displayPrice|price|fprice|minPrice|productPrice|priceText)["\']\s*[:=]\s*((?:₹|Rs\.?|INR)?\s*[\d,]+(?:\.\d+)?)',
            r'((?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?(?:\s*(?:/|per)\s*[A-Za-z .-]{1,30})?)',
        ])
        location = _first_regex(region, [
            r'["\'](?:city|location|cityName|sellerCity)["\']\s*[:=]\s*["\']([^"\']{2,100})',
        ])
        model = _first_regex(region, [
            r'["\'](?:model|modelNo|modelNumber|sku|mpn)["\']\s*[:=]\s*["\']([^"\']{1,100})',
        ])
        image = _first_regex(region, [
            r'["\'](?:image|imageUrl|image_url|imgUrl|img|imageSrc)["\']\s*[:=]\s*["\']([^"\']+)',
        ])
        if image.startswith('//'):
            image = 'https:' + image
        elif image.startswith('/'):
            image = urljoin(source_url, image)
        results.append({
            'product_name': product_name,
            'model': model,
            'specs': '',
            'purchase_price': _indiamart_price(price_raw),
            'price_date': 'Live IndiaMART',
            'supplier': supplier,
            'contact': '',
            'category': ('IndiaMART · ' + location) if location else 'IndiaMART',
            'product_link': href,
            'image_link': _normalize_image_link(image),
            'source_sheet': 'IndiaMART Live',
            'source_row': href,
            'source_type': 'indiamart',
        })

    # Merge exact repeated product URLs first. IndiaMART hydration/DOM can expose
    # the same offer twice with one copy missing seller/image fields. This is not
    # the business dedupe rule; it is simply the identical product URL.
    exact = OrderedDict()
    no_link = []
    for item in results:
        key = _canonical_indiamart_url(item.get("product_link")) if item.get("product_link") else ""
        if not key:
            no_link.append(item)
            continue
        if key in exact:
            exact[key] = _indiamart_merge_item(exact[key], item)
        else:
            exact[key] = dict(item)
    # Final offer-level dedupe still follows the UI rule: same company + same price.
    clean = _dedupe_indiamart_products(list(exact.values()) + no_link)
    for item in clean:
        item["search_text"] = _product_search_text(item)
    return clean



def _meta_content(page, names):
    """Return a decoded meta/link value without depending on CSS class names."""
    for name in names:
        q = re.escape(name)
        patterns = (
            rf'<meta\b[^>]*(?:property|name|itemprop)=["\']{q}["\'][^>]*content=["\']([^"\']+)',
            rf'<meta\b[^>]*content=["\']([^"\']+)["\'][^>]*(?:property|name|itemprop)=["\']{q}["\']',
        )
        value = _first_regex(page, patterns)
        if value:
            return value
    return ""


def _normalise_indiamart_phone(value):
    value = _clean_text(html_lib.unescape(str(value or "")))
    if not value:
        return ""
    value = re.sub(r'[^0-9+()\-\s]', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip(' -')
    # Prefer a recognisable Indian mobile/STD number contained in the field.
    m = re.search(r'(?:\+?91[\s-]?)?[6-9]\d{9}\b', value)
    if m:
        return m.group(0).strip()
    m = re.search(r'(?:\+?91[\s-]?)?0?\d{2,5}[\s-]?\d{5,8}\b', value)
    return m.group(0).strip() if m else value[:60]


def _clean_indiamart_title(value):
    value = _html_to_text(value)
    value = re.sub(r'\s*[|\-]\s*IndiaMART\s*$', '', value, flags=re.I).strip()
    return value[:220]


def _indiamart_page_record(page, source_url, hint_title="", hint_snippet=""):
    """Extract one exact product-page record, including the page's own image."""
    parsed_rows = _parse_indiamart_html(page, source_url)
    base = parsed_rows[0] if parsed_rows else {}

    title = _meta_content(page, ("og:title", "twitter:title"))
    if not title:
        title = _first_regex(page, (
            r'<h1\b[^>]*>(.*?)</h1>',
            r'<title\b[^>]*>(.*?)</title>',
        ))
    name = _clean_indiamart_title(base.get("product_name") or title or hint_title)
    if not name:
        return None

    # Exact IndiaMART product image: prefer page metadata / structured image over
    # a generic image-search fallback.  imimg.com is IndiaMART's product CDN.
    image = _normalize_image_link(base.get("image_link") or "")
    if not image:
        image = _normalize_image_link(_meta_content(page, ("og:image", "twitter:image", "twitter:image:src")))
    if not image:
        image = _first_regex(page, (
            r'["\'](?:image|imageUrl|image_url|imgUrl|originalImage)["\']\s*[:=]\s*["\'](https?:\\?/\\?/[^"\']+)',
            r'(https?:\\?/\\?/5\.imimg\.com/[^"\'<>\\ ]+)',
        ))
        image = image.replace('\\/', '/') if image else ''
        image = _normalize_image_link(image)

    supplier = _clean_text(base.get("supplier") or "")
    if not supplier:
        supplier = _first_regex(page, (
            r'["\'](?:companyName|company_name|compName|supplierName|sellerName|seller_name)["\']\s*[:=]\s*["\']([^"\']{2,180})',
            r'["\']seller["\']\s*:\s*\{.*?["\']name["\']\s*:\s*["\']([^"\']{2,180})',
            r'<(?:div|span|a)\b[^>]*(?:company|seller|supplier)[^>]*>([^<]{2,160})</',
        ))

    contact = _normalise_indiamart_phone(base.get("contact") or "")
    if not contact:
        raw_phone = _first_regex(page, (
            r'href=["\']tel:([^"\']+)',
            r'["\'](?:mobile|mobileNo|mobile_no|phone|phoneNo|telephone|contactNo|contact_number)["\']\s*[:=]\s*["\']([^"\']{5,80})',
        ))
        contact = _normalise_indiamart_phone(raw_phone)

    location = _first_regex(page, (
        r'["\']addressLocality["\']\s*:\s*["\']([^"\']{2,100})',
        r'["\'](?:cityName|city|location)["\']\s*[:=]\s*["\']([^"\']{2,100})',
    ))
    region = _first_regex(page, (r'["\']addressRegion["\']\s*:\s*["\']([^"\']{2,100})',))
    if region and region.lower() not in location.lower():
        location = _clean_text((location + ", " + region).strip(', '))

    price = _indiamart_price(base.get("purchase_price") or "")
    if not price:
        price = _indiamart_price(_meta_content(page, ("product:price:amount", "og:price:amount")))
    if not price:
        price = _indiamart_price(_first_regex(page, (
            r'["\'](?:displayPrice|fprice|minPrice|productPrice|price)["\']\s*[:=]\s*["\']?([^"\',}<]{1,80})',
            r'((?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?(?:\s*(?:/|per)\s*[A-Za-z .-]{1,30})?)',
        )))

    model = _clean_text(base.get("model") or _first_regex(page, (
        r'["\'](?:model|modelNo|modelNumber|sku|mpn)["\']\s*[:=]\s*["\']([^"\']{1,120})',
    )))
    description = _clean_text(base.get("specs") or _meta_content(page, ("description", "og:description")) or hint_snippet)

    return {
        "product_name": name,
        "model": model,
        "specs": description[:1600],
        "purchase_price": price,
        "price_date": "Live IndiaMART",
        "supplier": supplier,
        "contact": contact,
        "location": location,
        "supplier_location": location,
        "category": ("IndiaMART · " + location) if location else "IndiaMART",
        "product_link": _indiamart_abs_url(source_url, source_url),
        "image_link": image,
        "image_source": "IndiaMART exact product page" if image else "",
        "contact_status": "available" if contact else "view_on_indiamart",
        "source_sheet": "IndiaMART Live",
        "source_row": source_url,
        "source_type": "indiamart",
    }


def _indiamart_merge_item(primary, extra):
    primary = dict(primary or {})
    extra = dict(extra or {})
    # Never replace a populated exact field with an empty discovery field.
    for field in ("product_name", "model", "specs", "purchase_price", "supplier", "contact", "location", "supplier_location", "category", "product_link", "image_link", "image_source", "contact_status"):
        if not _clean_text(primary.get(field)) and _clean_text(extra.get(field)):
            primary[field] = extra.get(field)
    primary.setdefault("price_date", "Live IndiaMART")
    primary.setdefault("source_sheet", "IndiaMART Live")
    primary.setdefault("source_type", "indiamart")
    primary["search_text"] = _product_search_text(primary)
    return primary



def _api_post_json(url, payload, headers=None, timeout=SEARCH_API_TIMEOUT, max_bytes=5 * 1024 * 1024):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request_headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "PriceMaster/16.5",
    }
    request_headers.update(headers or {})
    req = Request(url, data=body, headers=request_headers, method="POST")
    try:
        with urlopen(req, timeout=timeout) as response:
            raw = response.read(max_bytes)
            return json.loads(raw.decode("utf-8", errors="replace") or "{}")
    except HTTPError as exc:
        detail = ""
        try:
            detail = exc.read(1200).decode("utf-8", errors="replace")
        except Exception:
            pass
        raise RuntimeError(f"HTTP {exc.code}: {detail[:450] or exc.reason}")


def _api_search_result_tuple(url, title="", snippet=""):
    url = _clean_text(url)
    if not url or not _indiamart_link_is_productish(url):
        return None
    return (url, _clean_indiamart_title(title), _html_to_text(snippet)[:1400])


def _serper_indiamart_links(query, limit=25, mode="standard"):
    if not SERPER_API_KEY:
        return []
    data = _api_post_json(
        "https://google.serper.dev/search",
        {"q": f"{query} site:indiamart.com", "gl": "in", "hl": "en", "num": max(10, min(100, int(limit or 25)))},
        {"X-API-KEY": SERPER_API_KEY},
    )
    out = []
    for item in data.get("organic") or []:
        row = _api_search_result_tuple(item.get("link"), item.get("title"), item.get("snippet"))
        if row:
            out.append(row)
    return out[:limit]


def _exa_indiamart_links(query, limit=25, mode="standard"):
    if not EXA_API_KEY:
        return []
    mode = _normalize_search_mode(mode)
    search_type = "instant" if mode == "minimum" else ("fast" if mode == "standard" else "deep-lite")
    payload = {
        "query": query,
        "type": search_type,
        "numResults": max(5, min(100, int(limit or 25))),
        "includeDomains": ["indiamart.com"],
        "moderation": True,
    }
    # Do not request full page contents here. PriceMaster only needs ranked URLs;
    # exact product detail pages are fetched separately and cached.
    data = _api_post_json("https://api.exa.ai/search", payload, {"x-api-key": EXA_API_KEY})
    out = []
    for item in data.get("results") or []:
        snippet = item.get("text") or item.get("summary") or ""
        row = _api_search_result_tuple(item.get("url"), item.get("title"), snippet)
        if row:
            out.append(row)
    return out[:limit]


def _tavily_indiamart_links(query, limit=20, mode="standard"):
    if not TAVILY_API_KEY:
        return []
    mode = _normalize_search_mode(mode)
    depth = "ultra-fast" if mode == "minimum" else ("basic" if mode == "standard" else "advanced")
    data = _api_post_json(
        "https://api.tavily.com/search",
        {
            "query": query,
            "search_depth": depth,
            "max_results": max(5, min(20, int(limit or 20))),
            "topic": "general",
            "include_answer": False,
            "include_raw_content": False,
            "include_images": False,
            "include_domains": ["indiamart.com"],
            "country": "india",
            "include_usage": True,
        },
        {"Authorization": "Bearer " + TAVILY_API_KEY},
    )
    out = []
    for item in data.get("results") or []:
        row = _api_search_result_tuple(item.get("url"), item.get("title"), item.get("content"))
        if row:
            out.append(row)
    return out[:limit]


def _firecrawl_indiamart_links(query, limit=10, mode="deep"):
    if not FIRECRAWL_API_KEY:
        return []
    data = _api_post_json(
        "https://api.firecrawl.dev/v2/search",
        {
            "query": query,
            "limit": max(5, min(20, int(limit or 10))),
            "sources": ["web"],
            "includeDomains": ["indiamart.com"],
            "country": "IN",
            "safe": True,
            "timeout": int(SEARCH_API_TIMEOUT * 1000),
            "highlights": True,
        },
        {"Authorization": "Bearer " + FIRECRAWL_API_KEY},
    )
    data_section = data.get("data") or {}
    web_rows = data_section.get("web") if isinstance(data_section, dict) else []
    if not isinstance(web_rows, list):
        web_rows = []
    out = []
    for item in web_rows:
        snippet = item.get("description") or item.get("markdown") or item.get("highlights") or ""
        if isinstance(snippet, list):
            snippet = " ".join(str(x) for x in snippet[:4])
        row = _api_search_result_tuple(item.get("url"), item.get("title"), snippet)
        if row:
            out.append(row)
    return out[:limit]



# V16.8.22 Supplier Contact Intelligence
# Searches the wider public web (not only IndiaMART), then extracts public
# business phone/email details from supplier pages. This is intentionally
# read-only: PriceMaster never sends a WhatsApp or email automatically.
_SUPPLIER_CONTACT_CACHE = {}
_SUPPLIER_CONTACT_LOCK = threading.Lock()
_SUPPLIER_CONTACT_TTL = 6 * 60 * 60


def _generic_search_result_tuple(url, title="", snippet=""):
    url = _generic_http_url(url, url)
    if not url:
        return None
    try:
        host = (urlparse(url).hostname or '').lower()
    except Exception:
        return None
    blocked = ('google.', 'bing.com', 'duckduckgo.', 'youtube.com', 'facebook.com',
               'instagram.com', 'linkedin.com', 'x.com', 'twitter.com', 'pinterest.')
    if any(x in host for x in blocked):
        return None
    return (url, _clean_text(title)[:300], _html_to_text(snippet)[:1800])


def _serper_supplier_links(query, limit=30, mode="standard"):
    if not SERPER_API_KEY: return []
    q = f'{query} supplier dealer distributor India contact phone email'
    data = _api_post_json('https://google.serper.dev/search',
        {'q': q, 'gl':'in','hl':'en','num':max(10,min(100,int(limit or 30)))},
        {'X-API-KEY': SERPER_API_KEY})
    out=[]
    for item in data.get('organic') or []:
        row=_generic_search_result_tuple(item.get('link'),item.get('title'),item.get('snippet'))
        if row: out.append(row)
    return out[:limit]


def _exa_supplier_links(query, limit=30, mode="standard"):
    if not EXA_API_KEY: return []
    mode=_normalize_search_mode(mode)
    typ='instant' if mode=='minimum' else ('fast' if mode=='standard' else 'deep-lite')
    data=_api_post_json('https://api.exa.ai/search',{
        'query':f'{query} India supplier dealer distributor contact','type':typ,
        'numResults':max(5,min(100,int(limit or 30))),'moderation':True}, {'x-api-key':EXA_API_KEY})
    out=[]
    for item in data.get('results') or []:
        row=_generic_search_result_tuple(item.get('url'),item.get('title'),item.get('text') or item.get('summary') or '')
        if row: out.append(row)
    return out[:limit]


def _tavily_supplier_links(query, limit=20, mode="standard"):
    if not TAVILY_API_KEY: return []
    mode=_normalize_search_mode(mode); depth='ultra-fast' if mode=='minimum' else ('basic' if mode=='standard' else 'advanced')
    data=_api_post_json('https://api.tavily.com/search',{
        'query':f'{query} supplier dealer distributor India phone email','search_depth':depth,
        'max_results':max(5,min(20,int(limit or 20))),'topic':'general','include_answer':False,
        'include_raw_content':False,'include_images':False,'country':'india','include_usage':True},
        {'Authorization':'Bearer '+TAVILY_API_KEY})
    out=[]
    for item in data.get('results') or []:
        row=_generic_search_result_tuple(item.get('url'),item.get('title'),item.get('content'))
        if row: out.append(row)
    return out[:limit]


def _firecrawl_supplier_links(query, limit=15, mode="deep"):
    if not FIRECRAWL_API_KEY: return []
    data=_api_post_json('https://api.firecrawl.dev/v2/search',{
        'query':f'{query} supplier dealer distributor India contact','limit':max(5,min(20,int(limit or 15))),
        'sources':['web'],'country':'IN','safe':True,'timeout':int(SEARCH_API_TIMEOUT*1000),'highlights':True},
        {'Authorization':'Bearer '+FIRECRAWL_API_KEY})
    section=data.get('data') or {}; rows=section.get('web') if isinstance(section,dict) else []
    out=[]
    for item in rows or []:
        snippet=item.get('description') or item.get('markdown') or item.get('highlights') or ''
        if isinstance(snippet,list): snippet=' '.join(str(x) for x in snippet[:4])
        row=_generic_search_result_tuple(item.get('url'),item.get('title'),snippet)
        if row: out.append(row)
    return out[:limit]


def _extract_generic_web_candidates(page, base_url, query, limit=60):
    text=str(page or ''); out=[]; seen=set()
    def add(raw,title='',snippet=''):
        if len(out)>=limit: return
        url=_decode_external_search_url(raw,base_url)
        if not url: return
        try:
            host=(urlparse(url).hostname or '').lower(); path=(urlparse(url).path or '').lower()
        except Exception: return
        if not host or any(x in host for x in ('google.','bing.com','duckduckgo.','youtube.com','facebook.com','instagram.com','linkedin.com','pinterest.com')): return
        if path.endswith(('.jpg','.jpeg','.png','.gif','.webp','.svg','.zip','.exe','.pdf')): return
        key=url.split('#',1)[0].rstrip('/').lower()
        if key in seen: return
        hay=_clean_text(' '.join((title or '',snippet or '',url))).lower()
        qtokens=[x for x in re.sub(r'[^a-z0-9]+',' ',_clean_text(query).lower()).split() if len(x)>1]
        hits=sum(1 for x in qtokens if x in hay)
        # Keep relevant result pages; contact extraction/ranking performs the final validation.
        if qtokens and hits<max(1,min(2,len(qtokens))): return
        seen.add(key); out.append((url,_html_to_text(title)[:300],_html_to_text(snippet)[:1600]))
    for item in re.findall(r'<item\b[^>]*>(.*?)</item>',text,flags=re.I|re.S):
        title=_first_regex(item,(r'<title[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>',))
        link=_first_regex(item,(r'<link[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>',))
        desc=_first_regex(item,(r'<description[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>',))
        add(link,title,desc)
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',text,flags=re.I|re.S):
        region=text[max(0,m.start()-180):min(len(text),m.end()+650)]
        add(m.group(1),_html_to_text(m.group(2)),region)
        if len(out)>=limit: break
    return out


def _free_supplier_links(query, limit=30, mode="standard"):
    """No-key fallback using public web index pages already supported by PriceMaster."""
    query=_clean_text(query)
    if not query: return []
    q=quote(f'{query} supplier dealer distributor India contact phone email')
    targets=[
        ('https://www.bing.com/search?format=rss&count=50&q='+q),
        ('https://html.duckduckgo.com/html/?q='+q),
    ]
    out=[]
    for target in targets[:1 if _normalize_search_mode(mode)=='minimum' else 2]:
        try:
            final,page=_indiamart_search_engine_request(target, timeout=6.0)
            out.extend(_extract_generic_web_candidates(page, final, query, limit=max(limit,50)))
        except Exception:
            continue
        if len(out)>=limit: break
    # Windows fallback: use the locally installed Edge/Chrome renderer when a
    # search engine rejects plain HTTP requests. Kept only as a fallback so
    # normal searches stay fast and do not open a visible browser.
    if not out and _find_local_chromium_browser():
        try:
            target='https://www.bing.com/search?count=50&q='+q
            final,page=_browser_dump_dom(target, timeout=12)
            out.extend(_extract_generic_web_candidates(page, final, query, limit=max(limit,50)))
        except Exception:
            pass
    return _dedupe_discovered_links(out, limit)


def _supplier_provider_ladder():
    out=[('Public Web Index',_free_supplier_links)]
    if SERPER_API_KEY: out.append(('Serper',_serper_supplier_links))
    if EXA_API_KEY: out.append(('Exa',_exa_supplier_links))
    if TAVILY_API_KEY: out.append(('Tavily',_tavily_supplier_links))
    if FIRECRAWL_API_KEY: out.append(('Firecrawl',_firecrawl_supplier_links))
    return out


def _extract_public_business_contacts(text):
    raw=html_lib.unescape(str(text or ''))
    emails=[]; phones=[]
    for e in re.findall(r'(?i)(?<![\w.+-])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])', raw):
        e=e.strip(' .,:;<>[]()').lower()
        if any(x in e for x in ('example.com','sentry.io','wixpress.com','cloudflare.com')): continue
        if e not in emails: emails.append(e)
    # Indian mobile, toll-free and landline-like public business numbers.
    patterns=[
        r'(?<!\d)(?:\+?91[\s().-]*)?[6-9]\d(?:[\s().-]*\d){8}(?!\d)',
        r'(?<!\d)(?:\+?91[\s().-]*)?(?:0?\d{2,4}[\s().-]*)\d(?:[\s().-]*\d){5,7}(?!\d)',
        r'(?<!\d)1800[\s-]*\d{3}[\s-]*\d{3,4}(?!\d)'
    ]
    for pat in patterns:
        for m in re.findall(pat, raw):
            n=_clean_text(m).strip(' ,.;:')
            digits=re.sub(r'\D','',n)
            if len(digits)<10 or len(digits)>13: continue
            if n not in phones: phones.append(n)
    return phones[:4],emails[:4]


def _supplier_company_name(title, page, url):
    candidates=[]
    for pattern in (r'<meta[^>]+property=["\']og:site_name["\'][^>]+content=["\']([^"\']+)',
                    r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:site_name["\']',
                    r'<title[^>]*>(.*?)</title>'):
        m=re.search(pattern,page or '',flags=re.I|re.S)
        if m: candidates.append(_html_to_text(m.group(1)))
    candidates.append(_clean_text(title))
    for v in candidates:
        v=re.sub(r'\s*[|–—-]\s*(?:IndiaMART|TradeIndia|Justdial|India).*$', '', v, flags=re.I).strip()
        if 2<=len(v)<=140: return v
    try: return (urlparse(url).hostname or '').replace('www.','').split('.')[0].replace('-',' ').title()
    except Exception: return 'Supplier'


def _supplier_location(text):
    txt=_html_to_text(text or '')
    states='Gujarat|Maharashtra|Tamil Nadu|Karnataka|Telangana|Delhi|Rajasthan|Madhya Pradesh|Uttar Pradesh|West Bengal|Kerala|Punjab|Haryana|Bihar|Odisha|Andhra Pradesh|Chhattisgarh|Jharkhand|Uttarakhand|Goa'
    m=re.search(r'([A-Z][A-Za-z .]{2,35}),?\s+(' + states + r')\b',txt)
    return _clean_text(m.group(0)) if m else ''


def _supplier_match_score(query,title,snippet,page,url):
    qtokens=[t for t in re.sub(r'[^a-z0-9]+',' ',_clean_text(query).lower()).split() if len(t)>1 and t not in {'the','and','for','with'}]
    hay=re.sub(r'[^a-z0-9]+',' ',_clean_text(' '.join((title or '',snippet or '',_html_to_text((page or '')[:180000]),url or ''))).lower())
    hits=sum(1 for t in qtokens if t in hay); score=hits*10
    qnorm=' '.join(qtokens)
    if qnorm and qnorm in hay: score+=80
    if 'indiamart.com' in (url or '').lower(): score+=7
    if re.search(r'\b(supplier|dealer|distributor|manufacturer|stockist|reseller|channel partner)\b',hay): score+=8
    return score,hits,len(qtokens)


def _supplier_contact_record(query,url,title='',snippet='',fetch_page=True):
    page=''; final=url
    if fetch_page:
        try: final,page=_managed_site_request(url, timeout=4.8)
        except Exception: page=''
    combined=' '.join((snippet or '', page or ''))
    phones,emails=_extract_public_business_contacts(combined)
    score,hits,total=_supplier_match_score(query,title,snippet,page,final)
    # Search snippets may contain useful public contact info even if the site blocks fetching.
    if not (phones or emails) and score<20: return None
    supplier=_supplier_company_name(title,page,final)
    location=_supplier_location(combined)
    exact=bool(total and hits>=max(1,total-1))
    match=('⭐ Exact / strong product match' if exact else ('Related Indian supplier/dealer' if hits else 'Indian supplier contact'))
    return {
        'product_name':_clean_text(query),'model':'','specs':match,'purchase_price':'',
        'supplier':supplier,'contact':' / '.join(phones),'contact_email':' / '.join(emails),
        'supplier_location':location,'location':location,'category':'Supplier Contact',
        'price_date':'Live web contact','product_link':final,'source_sheet':'Supplier Contacts',
        'source_type':'supplier_contact','contact_status':'Public website/search contact',
        'match_note':match,'match_score':score,'search_snippet':_clean_text(snippet)[:900]
    }


def search_supplier_contacts(query, limit=20, mode='standard'):
    query=_clean_text(query); mode=_normalize_search_mode(mode); limit=max(1,min(40,int(limit or 20)))
    if not query: return [],{'ok':True,'searched':False,'methods':[]}
    cache_key=(query.lower(),mode,limit)
    with _SUPPLIER_CONTACT_LOCK:
        cached=_SUPPLIER_CONTACT_CACHE.get(cache_key)
        if cached and time.time()-cached[0]<_SUPPLIER_CONTACT_TTL: return cached[1],dict(cached[2],cached=True)
    providers=_supplier_provider_ladder(); discovered=[]; methods=[]; errors=[]
    cap=1 if mode=='minimum' else (2 if mode=='standard' else len(providers))
    target=max(30,limit*3)
    # Run configured providers concurrently for lower latency.
    chosen=providers[:cap]
    if chosen:
        with ThreadPoolExecutor(max_workers=len(chosen)) as pool:
            jobs={pool.submit(fn,query,target,mode):name for name,fn in chosen}
            for fut,name in jobs.items():
                try:
                    rows=fut.result(); discovered.extend(rows or []); methods.append(name)
                except Exception as exc: errors.append(name+': '+str(exc)[:180])
    # Add direct IndiaMART Google-style discovery too; it often finds niche Indian sellers.
    if len(discovered)<target and SERPER_API_KEY:
        try: discovered.extend(_serper_indiamart_links(query,min(25,target),mode)); methods.append('IndiaMART via Serper')
        except Exception: pass
    # Dedupe URLs/hosts while preserving multiple pages if they are different suppliers.
    uniq=[]; seen=set()
    for row in discovered:
        if not row: continue
        url,title,snip=row; key=(url.split('#',1)[0].rstrip('/').lower())
        if key in seen: continue
        seen.add(key); uniq.append((url,title,snip))
        if len(uniq)>=target: break
    candidates=[]
    fetch_cap=min(len(uniq), 12 if mode=='minimum' else (28 if mode=='standard' else 45))
    # Extract contacts in parallel. This is the expensive stage and is capped.
    with ThreadPoolExecutor(max_workers=min(8,max(1,fetch_cap))) as pool:
        jobs=[pool.submit(_supplier_contact_record,query,*row,True) for row in uniq[:fetch_cap]]
        for fut in as_completed(jobs):
            try:
                rec=fut.result()
                if rec: candidates.append(rec)
            except Exception: pass
    # Also use search-result snippets (fast fallback) for remaining URLs.
    for row in uniq[fetch_cap:]:
        rec=_supplier_contact_record(query,*row,False)
        if rec: candidates.append(rec)
    # Company + phone/email dedupe; strongest exact match first.
    best={}
    for r in candidates:
        ident=(re.sub(r'\W+','',_clean_text(r.get('supplier')).lower()),
               re.sub(r'\D','',_clean_text(r.get('contact')))[:10],
               _clean_text(r.get('contact_email')).lower().split('/')[0].strip())
        key=ident if any(ident) else (_clean_text(r.get('product_link')).lower(),)
        if key not in best or int(r.get('match_score') or 0)>int(best[key].get('match_score') or 0): best[key]=r
    rows=sorted(best.values(),key=lambda r:(-int(r.get('match_score') or 0),0 if r.get('contact') else 1,0 if r.get('contact_email') else 1,_clean_text(r.get('supplier')).lower()))[:limit]
    info={'ok':True,'searched':True,'query':query,'count':len(rows),'methods':methods,'errors':errors,
          'configuredProviders':_configured_search_api_names(),'source':'Supplier Contacts','searchMode':mode,'cached':False}
    with _SUPPLIER_CONTACT_LOCK: _SUPPLIER_CONTACT_CACHE[cache_key]=(time.time(),rows,info)
    return rows,info

def _configured_search_api_names():
    names = []
    if SERPER_API_KEY: names.append("Serper")
    if EXA_API_KEY: names.append("Exa")
    if TAVILY_API_KEY: names.append("Tavily")
    if FIRECRAWL_API_KEY: names.append("Firecrawl")
    return names


def _available_provider_ladder(mode="standard"):
    # Cheapest/fastest useful provider first. Minimum stops after one successful
    # provider. Standard permits two. Deep may continue through all four but stops
    # early once enough unique links have already been found.
    providers = []
    if SERPER_API_KEY: providers.append(("Serper", _serper_indiamart_links))
    if EXA_API_KEY: providers.append(("Exa", _exa_indiamart_links))
    if TAVILY_API_KEY: providers.append(("Tavily", _tavily_indiamart_links))
    if FIRECRAWL_API_KEY: providers.append(("Firecrawl", _firecrawl_indiamart_links))
    return providers


def _dedupe_discovered_links(rows, limit):
    out, seen = [], set()
    for row in rows or []:
        if not row:
            continue
        url, title, snippet = row
        key = str(url).split("#", 1)[0].lower()
        if not key or key in seen:
            continue
        seen.add(key)
        out.append((url, title, snippet))
        if len(out) >= limit:
            break
    return out

def _decode_search_result_url(href, base_url):
    href = html_lib.unescape(str(href or "")).replace('\\u0026', '&').replace('\\/', '/')
    if not href:
        return ""
    absolute = urljoin(base_url, href)
    try:
        parsed = urlparse(absolute)
        host = (parsed.hostname or '').lower()
        qs = parse_qs(parsed.query)
        if 'google.' in host and parsed.path == '/url':
            absolute = (qs.get('q') or qs.get('url') or [''])[0]
        elif 'duckduckgo.' in host and 'uddg' in qs:
            absolute = unquote(qs.get('uddg', [''])[0])
    except Exception:
        return ""
    return _indiamart_abs_url(absolute, base_url)


def _generic_http_url(value, base=""):
    """Normalize a public HTTP(S) URL without forcing indiamart.com.

    IndiaMART supplier storefronts can be hosted on the seller's own domain while
    still being generated/managed by IndiaMART. This helper is used only after a
    page has been verified as IndiaMART/InterMESH-managed.
    """
    value = html_lib.unescape(_clean_text(value))
    if not value:
        return ""
    value = (value.replace('\\u002F', '/').replace('\\u002f', '/')
                  .replace('\\u003A', ':').replace('\\u003a', ':')
                  .replace('\\u0026', '&').replace('\\/', '/'))
    if value.startswith('//'):
        value = 'https:' + value
    try:
        absolute = urljoin(base or value, value)
        parsed = urlparse(absolute)
        if parsed.scheme.lower() not in {'http', 'https'} or not parsed.hostname:
            return ""
        return absolute
    except Exception:
        return ""


def _decode_external_search_url(href, base_url):
    """Decode Google/DDG/Bing outbound links for managed-storefront discovery."""
    absolute = _generic_http_url(href, base_url)
    if not absolute:
        return ""
    try:
        parsed = urlparse(absolute)
        host = (parsed.hostname or '').lower()
        qs = parse_qs(parsed.query)
        if 'google.' in host and parsed.path == '/url':
            absolute = (qs.get('q') or qs.get('url') or [''])[0]
        elif 'duckduckgo.' in host and 'uddg' in qs:
            absolute = unquote((qs.get('uddg') or [''])[0])
        elif host.endswith('bing.com') and parsed.path.startswith('/ck/'):
            encoded = (qs.get('u') or [''])[0]
            if encoded.startswith('a1') and len(encoded) > 4:
                payload = encoded[2:]
                payload += '=' * (-len(payload) % 4)
                try:
                    absolute = base64.urlsafe_b64decode(payload.encode('ascii')).decode('utf-8', errors='replace')
                except Exception:
                    pass
            elif encoded.startswith(('http://', 'https://')):
                absolute = encoded
    except Exception:
        return ""
    return _generic_http_url(absolute, base_url)


def _web_index_candidate_score(url, title, snippet, query):
    q = re.sub(r'[^a-z0-9]+', ' ', _clean_text(query).lower()).strip()
    text = re.sub(r'[^a-z0-9]+', ' ', _clean_text(' '.join((title or '', snippet or '', url or ''))).lower()).strip()
    if not q or not text:
        return 0
    score = 0
    if q in text:
        score += 80
    tokens = [t for t in q.split() if len(t) > 1 and t not in {'the','and','for','with','india','indiamart'}]
    hits = sum(1 for t in tokens if t in text)
    score += hits * 12
    if tokens and hits == len(tokens):
        score += 20
    if re.search(r'(?:product|products|detector|meter|tester|analy[sz]er|instrument|equipment|sensor|monitor|gauge)', text):
        score += 6
    return score


def _extract_external_index_candidates(page, base_url, query, limit=120):
    """Extract likely seller pages from a normal web-index result page.

    Nothing is trusted at this stage. Every external page is fetched and must
    contain a strong IndiaMART/InterMESH storefront marker before it becomes a
    PriceMaster result.
    """
    page = str(page or '')
    found, seen = [], set()
    blocked_hosts = {
        'google.com','www.google.com','bing.com','www.bing.com','duckduckgo.com','html.duckduckgo.com',
        'youtube.com','www.youtube.com','facebook.com','www.facebook.com','instagram.com','www.instagram.com',
        'linkedin.com','www.linkedin.com','x.com','twitter.com','www.twitter.com','pinterest.com','www.pinterest.com',
        'justdial.com','www.justdial.com','flipkart.com','www.flipkart.com','amazon.in','www.amazon.in',
    }

    def add(raw_url, title='', snippet=''):
        if len(found) >= limit:
            return
        url = _decode_external_search_url(raw_url, base_url)
        if not url:
            return
        try:
            p = urlparse(url)
            host = (p.hostname or '').lower()
            path = (p.path or '/').lower()
        except Exception:
            return
        if host in blocked_hosts or host.endswith('.google.com') or host.endswith('.bing.com') or host.endswith('.duckduckgo.com'):
            return
        if path.endswith(('.jpg','.jpeg','.png','.gif','.webp','.svg','.zip','.exe','.msi','.mp4','.mp3','.pdf')):
            return
        key = host + re.sub(r'/+', '/', path).rstrip('/').lower()
        if not key or key in seen:
            return
        clean_title = _clean_indiamart_title(title) or _indiamart_title_from_url(url)
        clean_snippet = _html_to_text(snippet)[:1600]
        primary_score = _web_index_candidate_score(url, clean_title, '', query)
        full_score = _web_index_candidate_score(url, clean_title, clean_snippet, query)
        if primary_score < 12 or full_score < 18:
            return
        seen.add(key)
        found.append((url, clean_title, clean_snippet))

    for item in re.findall(r'<item\b[^>]*>(.*?)</item>', page, flags=re.I | re.S):
        link = _first_regex(item, (r'<link[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>',))
        title = _first_regex(item, (r'<title[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>',))
        desc = _first_regex(item, (r'<description[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>',))
        add(link, title, desc)
        if len(found) >= limit:
            return found

    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', page, flags=re.I | re.S):
        region = page[max(0, m.start()-250):min(len(page), m.end()+900)]
        add(m.group(1), _html_to_text(m.group(2)), region)
        if len(found) >= limit:
            return found
    return found


def _looks_like_indiamart_managed_page(page):
    """Strong marker check for seller-domain pages generated by IndiaMART."""
    low = html_lib.unescape(str(page or '')).lower()
    strong = (
        'developed and managed by indiamart',
        'developed and managed by indiamart intermesh',
        'developed and managed by indiamart intermesh limited',
        'developed and managed by indiamart intermesh ltd',
        'developed and managed by indiamart intermesh ltd.',
        'indiamart trustseal',
        'indiamart trust seal verified',
    )
    if any(marker in low for marker in strong):
        return True
    tail = low[-220000:]
    return ('copyright' in tail and 'indiamart intermesh' in tail and ('all rights reserved' in tail or 'terms of use' in tail))



def _assert_safe_public_remote_url(url):
    """Reject localhost/private/link-local/reserved targets before server-side fetches."""
    normalized = _generic_http_url(url, url)
    if not normalized:
        raise ValueError("Invalid remote URL")
    parsed = urlparse(normalized)
    host = (parsed.hostname or "").strip().lower().rstrip(".")
    if not host or host == "localhost" or host.endswith(".localhost") or host.endswith(".local"):
        raise ValueError("Local/private remote URLs are not allowed")
    try:
        addresses = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
            addresses = []
            for item in infos:
                raw = item[4][0].split("%", 1)[0]
                try:
                    addresses.append(ipaddress.ip_address(raw))
                except ValueError:
                    pass
        except Exception as exc:
            raise ValueError("Remote hostname could not be resolved") from exc
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ValueError("Local/private remote URLs are not allowed")
    return normalized


def _managed_site_request(url, timeout=10):
    url = _assert_safe_public_remote_url(url)
    req = Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-IN,en;q=0.9',
        'Cache-Control': 'no-cache',
    })
    with urlopen(req, timeout=max(3.5, float(timeout or 8))) as response:
        raw = response.read(3 * 1024 * 1024)
        final_url = response.geturl()
    _assert_safe_public_remote_url(final_url)
    body = raw.decode('utf-8', errors='replace')
    if len(body) < 120 or '<html' not in body[:8000].lower():
        raise RuntimeError('Seller storefront returned no readable HTML')
    return final_url, body


def _managed_storefront_record(page, source_url, hint_title='', hint_snippet=''):
    """Reuse the stable IndiaMART field parser on a verified seller storefront."""
    record = _indiamart_page_record(page, source_url, hint_title, hint_snippet)
    if not record:
        record = _search_hint_record(source_url, hint_title, hint_snippet)
    if not record:
        return None
    record = dict(record)
    record['product_link'] = _generic_http_url(source_url, source_url) or source_url
    record['source_row'] = record['product_link']
    record['source_sheet'] = 'IndiaMART Managed Storefront'
    record['source_type'] = 'indiamart'
    if not _clean_text(record.get('category')):
        record['category'] = 'IndiaMART'
    record['search_text'] = _product_search_text(record)
    return record


def _extract_managed_storefront_product_links(page, base_url, query, limit=120):
    """Collect same-store product/category links from a verified IndiaMART site."""
    found, seen = [], set()
    try:
        base_host = (urlparse(base_url).hostname or '').lower()
    except Exception:
        base_host = ''
    if not base_host:
        return found
    blocked = ('about','contact','profile','testimonial','infrastructure','photo','sitemap','corporate-video','registration','franchise','enquiry','terms','privacy')
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', str(page or ''), flags=re.I | re.S):
        url = _generic_http_url(m.group(1), base_url)
        if not url:
            continue
        try:
            p = urlparse(url)
            host = (p.hostname or '').lower()
            path = (p.path or '/').lower()
        except Exception:
            continue
        if host != base_host or path in {'','/'} or any(x in path for x in blocked):
            continue
        if path.endswith(('.jpg','.jpeg','.png','.gif','.webp','.pdf','.zip','.mp4')):
            continue
        title = _clean_indiamart_title(_html_to_text(m.group(2))) or _indiamart_title_from_url(url)
        region = str(page or '')[max(0, m.start()-250):min(len(str(page or '')), m.end()+700)]
        if _web_index_candidate_score(url, title, region, query) < 18:
            continue
        key = host + re.sub(r'/+', '/', path).rstrip('/')
        if key in seen:
            continue
        seen.add(key)
        found.append((url, title, _html_to_text(region)[:1200]))
        if len(found) >= limit:
            break
    return found


_browser_path_lock = threading.RLock()
_browser_path_cache = {"checked": False, "path": ""}
_browser_dump_lock = threading.Semaphore(3)


def _find_local_chromium_browser():
    """Return an installed Chromium-family browser on Windows, macOS or Linux."""
    with _browser_path_lock:
        if _browser_path_cache["checked"]:
            return _browser_path_cache["path"]
        candidates = []
        if os.name == "nt":
            for env_name, suffixes in (
                ("PROGRAMFILES(X86)", (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe")),
                ("PROGRAMFILES", (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe")),
                ("LOCALAPPDATA", (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe", r"BraveSoftware\Brave-Browser\Application\brave.exe")),
            ):
                base = os.environ.get(env_name, "")
                if base:
                    candidates.extend(os.path.join(base, suffix) for suffix in suffixes)
        elif sys.platform == "darwin":
            mac_apps = (
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
                "/Applications/Chromium.app/Contents/MacOS/Chromium",
                "~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                "~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                "~/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
                "~/Applications/Chromium.app/Contents/MacOS/Chromium",
            )
            candidates.extend(os.path.expanduser(p) for p in mac_apps)
        for exe_name in (
            "msedge.exe", "chrome.exe", "brave.exe",
            "microsoft-edge", "microsoft-edge-stable", "google-chrome", "google-chrome-stable",
            "brave-browser", "chromium", "chromium-browser",
        ):
            resolved = shutil.which(exe_name)
            if resolved:
                candidates.append(resolved)
        chosen = ""
        for candidate in candidates:
            if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                chosen = candidate
                break
        _browser_path_cache.update({"checked": True, "path": chosen})
        return chosen


def _browser_dump_dom(url, timeout=18):
    """Load one page in the locally installed browser and return rendered DOM."""
    browser = _find_local_chromium_browser()
    if not browser:
        raise RuntimeError("Chrome/Edge/Brave/Chromium browser fallback is unavailable")
    profile_dir = tempfile.mkdtemp(prefix="pm_im_browser_")
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    cmd = [
        browser,
        "--headless=new",
        "--disable-gpu",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-background-networking",
        "--disable-component-update",
        "--disable-extensions",
        "--disable-sync",
        "--disable-dev-shm-usage",
        "--blink-settings=imagesEnabled=false",
        "--window-size=1280,1100",
        "--virtual-time-budget=3200",
        "--user-data-dir=" + profile_dir,
        "--dump-dom",
        url,
    ]
    # Chromium refuses headless execution as root unless sandbox is disabled.
    # Windows desktop runs are unaffected; this keeps the fallback portable/testable.
    try:
        if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(2, "--no-sandbox")
    except Exception:
        pass
    try:
        with _browser_dump_lock:
            completed = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(6, float(timeout or 12)),
                creationflags=creationflags,
            )
        body = completed.stdout or ""
        if len(body) < 120 or "<html" not in body[:5000].lower():
            detail = _clean_text((completed.stderr or "")[-700:])
            raise RuntimeError(detail or "Browser returned no readable page")
        low = body[:40000].lower()
        verification_markers = (
            "verify you are human", "verify that you are human", "are you a robot",
            "security verification", "captcha challenge", "/captcha/", "cf-chl-captcha",
        )
        if any(marker in low for marker in verification_markers):
            raise RuntimeError("IndiaMART/search provider requested browser verification")
        return url, body
    finally:
        try:
            shutil.rmtree(profile_dir, ignore_errors=True)
        except Exception:
            pass


def _browser_indiamart_discovery(query, mode="standard", limit=INDIAMART_DISCOVERY_MAX_LINKS):
    """Last-resort browser-rendered discovery for zero-row IndiaMART searches."""
    query = _clean_text(query)
    mode = _normalize_search_mode(mode)
    if not query or not _find_local_chromium_browser():
        return [], [], [], []
    requested = max(1, min(int(limit or INDIAMART_DISCOVERY_MAX_LINKS), INDIAMART_DISCOVERY_MAX_LINKS))
    rows, links, errors, methods = [], [], [], []
    targets = []
    for variant in _indiamart_discovery_variants(query, mode)[:(2 if mode != 'deep' else 4)]:
        exact = quote(variant)
        targets.append(("IndiaMART browser", INDIAMART_SEARCH_URL.format(query=exact)))
        if mode == "deep":
            targets.append(("IndiaMART browser", INDIAMART_SEARCH_URL.format(query=exact) + "&start=20"))
    search_q = quote(query + " IndiaMART")
    targets.append(("Browser web index", "https://www.bing.com/search?count=50&q=" + search_q))
    if mode == "deep":
        targets.append(("Browser web index", "https://html.duckduckgo.com/html/?q=" + search_q))

    with ThreadPoolExecutor(max_workers=min(3, len(targets))) as pool:
        future_map = {pool.submit(_browser_dump_dom, url, 16 if mode != "deep" else 20): (name, url) for name, url in targets}
        for future in as_completed(future_map):
            name, original_url = future_map[future]
            try:
                final_url, body = future.result()
                if "indiamart.com" in (urlparse(final_url).hostname or "").lower():
                    parsed = _parse_indiamart_html(body, final_url)
                    if parsed:
                        rows.extend(parsed)
                    links.extend(_extract_indiamart_search_links(body, final_url, limit=requested))
                else:
                    links.extend(_extract_indiamart_search_links(body, final_url, limit=requested))
                methods.append(name)
            except Exception as exc:
                errors.append(f"{name}: {exc}")
    return rows, _dedupe_discovered_links(links, requested), errors, list(dict.fromkeys(methods))


def _indiamart_discovery_variants(query, mode="standard"):
    """Wider discovery phrases while keeping the exact typed phrase first."""
    mode = _normalize_search_mode(mode)
    base = _search_query_variants(query, mode) or [_clean_text(query)]
    out = []
    def add(value):
        value = _clean_text(value)
        if value and value.lower() not in {x.lower() for x in out}:
            out.append(value)
    for value in base:
        add(value)
    if mode != 'minimum':
        core = [w for w in _query_words(query) if w not in SEARCH_QUERY_GENERIC]
        if core and not any(w in SEARCH_COMPLETION_NOUNS for w in core):
            for noun in SEARCH_COMPLETION_NOUNS[:(2 if mode == 'standard' else 6)]:
                add(' '.join(core + [noun]))
        add(_clean_text(query) + ' price')
        add(_clean_text(query) + ' supplier')
        add(_clean_text(query) + ' manufacturer')
    if mode == 'deep':
        add(_clean_text(query) + ' dealer')
        add(_clean_text(query) + ' India')
    cap = 3 if mode == 'minimum' else (10 if mode == 'standard' else 18)
    return out[:cap]


def _discover_indiamart_managed_storefronts(query, mode="standard", limit=INDIAMART_DISCOVERY_MAX_LINKS):
    """Find IndiaMART-managed seller sites that are not hosted on indiamart.com."""
    query = _clean_text(query)
    mode = _normalize_search_mode(mode)
    if not query:
        return [], [], [], 0
    requested = max(1, min(int(limit or INDIAMART_DISCOVERY_MAX_LINKS), INDIAMART_DISCOVERY_MAX_LINKS))
    variant_cap = 1 if mode == 'minimum' else (3 if mode == 'standard' else 5)
    candidate_cap = 12 if mode == 'minimum' else (30 if mode == 'standard' else 56)
    detail_cap = 10 if mode == 'minimum' else (32 if mode == 'standard' else 64)
    variants = _indiamart_discovery_variants(query, mode)[:variant_cap]
    engines = []
    for variant in variants:
        q = quote('"' + variant + '" IndiaMART')
        engines.extend((
            'https://www.google.com/search?num=100&hl=en&q=' + q,
            'https://www.bing.com/search?count=50&q=' + q,
            'https://www.bing.com/search?format=rss&count=50&q=' + q,
            'https://html.duckduckgo.com/html/?q=' + q,
        ))
    engines = list(dict.fromkeys(engines))
    candidates, errors = [], []
    if engines:
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(engines))) as pool:
            futures = [pool.submit(_indiamart_search_engine_request, url, 4.2) for url in engines]
            for future in as_completed(futures):
                try:
                    final_url, page = future.result()
                    candidates.extend(_extract_external_index_candidates(page, final_url, query, limit=candidate_cap * 2))
                except Exception as exc:
                    errors.append('Managed index: ' + str(exc))
    candidates = _dedupe_discovered_links(candidates, candidate_cap)

    if not candidates and _find_local_chromium_browser():
        try:
            q = quote('"' + query + '" IndiaMART')
            final_url, page = _browser_dump_dom('https://www.bing.com/search?count=50&q=' + q, 16)
            candidates = _extract_external_index_candidates(page, final_url, query, limit=candidate_cap)
        except Exception as exc:
            errors.append('Managed browser index: ' + str(exc))

    verified_rows, child_links, verified_hosts = [], [], set()
    if candidates:
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(candidates))) as pool:
            job_map = {
                pool.submit(_managed_site_request, url, 6.2 if mode != 'deep' else 7.2): (url, title, snippet)
                for url, title, snippet in candidates
                if not _indiamart_link_is_productish(url)
            }
            for future in as_completed(job_map):
                url, title, snippet = job_map[future]
                try:
                    final_url, page = future.result()
                    if not _looks_like_indiamart_managed_page(page):
                        continue
                    host = (urlparse(final_url).hostname or '').lower()
                    if host:
                        verified_hosts.add(host)
                    record = _managed_storefront_record(page, final_url, title, snippet)
                    if record and _indiamart_relevance(record, query) > 0:
                        verified_rows.append(record)
                    child_links.extend(_extract_managed_storefront_product_links(
                        page, final_url, query, limit=min(140, requested)
                    ))
                except Exception as exc:
                    errors.append('Managed storefront: ' + str(exc))

    child_links = _dedupe_discovered_links(child_links, requested)
    enriched_urls = set()
    detail_jobs = child_links[:min(detail_cap, len(child_links), requested)]
    if detail_jobs:
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(detail_jobs))) as pool:
            job_map = {
                pool.submit(_managed_site_request, url, 5.8 if mode != 'deep' else 6.8): (url, title, snippet)
                for url, title, snippet in detail_jobs
            }
            for future in as_completed(job_map):
                url, title, snippet = job_map[future]
                try:
                    final_url, page = future.result()
                    if not _looks_like_indiamart_managed_page(page):
                        continue
                    rec = _managed_storefront_record(page, final_url, title, snippet)
                    if rec:
                        verified_rows.append(rec)
                        enriched_urls.add(_canonical_indiamart_url(url) or url.lower())
                except Exception:
                    pass
    for url, title, snippet in child_links:
        key = _canonical_indiamart_url(url) or url.lower()
        if key in enriched_urls:
            continue
        row = _search_hint_record(url, title, snippet)
        if row:
            row['source_sheet'] = 'IndiaMART Managed Storefront'
            row['source_type'] = 'indiamart'
            verified_rows.append(row)
        if len(verified_rows) >= requested:
            break

    methods = ['IndiaMART managed-storefront index'] if verified_rows else []
    if verified_hosts:
        methods.append('IndiaMART managed-storefront verification')
    return verified_rows[:requested], errors, methods, len(verified_hosts)


def _indiamart_search_engine_request(url, timeout=14):
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en-IN,en;q=0.9",
        "Cache-Control": "no-cache",
    })
    with _indiamart_public_gate:
        with urlopen(req, timeout=timeout) as response:
            return response.geturl(), response.read(3 * 1024 * 1024).decode('utf-8', errors='replace')


def _indiamart_link_is_directory_listing(url):
    """True for public IndiaMART directory/category pages that contain offer cards."""
    try:
        p = urlparse(str(url or ""))
        host = (p.hostname or "").lower()
        path = (p.path or "/").lower()
        if host != "dir.indiamart.com":
            return False
        if "/proddetail/" in path or "/product/" in path or "/products/" in path:
            return False
        if path.endswith(".html") and ("/impcat/" in path or path.count("/") >= 2):
            return True
        if path == "/search.mp":
            return True
    except Exception:
        return False
    return False


def _google_style_indiamart_queries(query, mode="standard"):
    """Queries shaped like a person typing '<product> indiamart' in Google."""
    mode = _normalize_search_mode(mode)
    query = _clean_text(query)
    if not query:
        return []
    out = []
    def add(value):
        value = _clean_text(value)
        if value and value.casefold() not in {x.casefold() for x in out}:
            out.append(value)
    add('"' + query + '" indiamart')
    add(query + ' indiamart')
    if mode != "minimum":
        add('"' + query + '" site:dir.indiamart.com')
        add(query + ' site:indiamart.com')
    if mode == "deep":
        add(query + ' indiamart price supplier')
        add(query + ' indiamart all india')
    return out[:2 if mode == "minimum" else (4 if mode == "standard" else 6)]


def _extract_indiamart_directory_links_from_index(page, base_url, limit=40):
    """Extract IndiaMART category/directory links from web-index HTML or RSS."""
    found, seen = [], set()
    text = str(page or "")
    def add(raw_url, title="", snippet=""):
        if len(found) >= limit:
            return
        url = _decode_search_result_url(raw_url, base_url)
        if not url:
            url = _indiamart_abs_url(html_lib.unescape(str(raw_url or "")), base_url)
        if not url or not _indiamart_link_is_directory_listing(url):
            return
        key = _canonical_indiamart_url(url) or url.split("#",1)[0].lower()
        if not key or key in seen:
            return
        seen.add(key)
        found.append((url, _clean_indiamart_title(title), _html_to_text(snippet)[:1200]))
    for item in re.findall(r'<item\b[^>]*>(.*?)</item>', text, flags=re.I|re.S):
        title = _first_regex(item, (r'<title\b[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>',))
        link = _first_regex(item, (r'<link\b[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</link>',))
        desc = _first_regex(item, (r'<description\b[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>',))
        add(link, title, desc)
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', text, flags=re.I|re.S):
        region = text[max(0,m.start()-250):min(len(text),m.end()+1000)]
        add(m.group(1), _html_to_text(m.group(2)), region)
        if len(found) >= limit:
            break
    if len(found) < limit:
        expanded = html_lib.unescape(text.replace('\\/','/').replace('\\u0026','&'))
        for raw in re.findall(r'https?://dir\.indiamart\.com/[^"\'<>\s]+', expanded, flags=re.I):
            add(raw, '', '')
            if len(found) >= limit:
                break
    return found


def _indiamart_supplier_from_card_region(region, source_url):
    candidates=[]
    generic={'contact supplier','call now','get best price','view more','read more','view details','indiamart','image','all india'}
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', region or '', flags=re.I|re.S):
        text=_html_to_text(m.group(2)).strip()
        if not text or text.casefold() in generic or len(text)>140:
            continue
        url=_indiamart_abs_url(m.group(1), source_url)
        if not url:
            continue
        try:
            pp=urlparse(url); host=(pp.hostname or '').lower(); path=(pp.path or '/').lower()
        except Exception:
            continue
        if not (host=='indiamart.com' or host.endswith('.indiamart.com')):
            continue
        if host.startswith(('dir.','m.')) or _indiamart_link_is_productish(url) or _indiamart_link_is_directory_listing(url):
            continue
        if any(token in path for token in ('/search.','/help','/terms','/privacy')):
            continue
        score=10
        if re.search(r'\b(?:instruments?|instrumentation|tools?|enterprises?|industries|solutions?|technologies|traders?|scientific|electrical|electronics?)\b', text, flags=re.I):
            score+=8
        candidates.append((score,text,url))
    if not candidates:
        return '', ''
    candidates.sort(key=lambda x:(x[0],len(x[1])), reverse=True)
    return candidates[0][1], candidates[0][2]


def _indiamart_card_location(text, supplier=""):
    text=_clean_text(text)
    supplier=_clean_text(supplier)
    if supplier:
        m=re.search(re.escape(supplier) + r'\s+([A-Z][A-Za-z .-]{2,48}?)\s*[·•]\s*(?:\d+\s*(?:yrs?|years?|months?))\b', text, flags=re.I)
        if m:
            return _clean_text(m.group(1)).strip(' -·•')
    for pat in (r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\s*[·•]\s*(?:\d+\s*(?:yrs?|years?|months?))\b', r'\b(?:Location|City)\s*[:\-]\s*([A-Z][A-Za-z .-]{2,48})\b'):
        matches=list(re.finditer(pat,text,flags=re.I))
        if matches:
            return _clean_text(matches[-1].group(1)).strip(' -·•')
    return ''


def _indiamart_card_trust_specs(text):
    text=_clean_text(text); parts=[]
    if re.search(r'\bVerified Exporter\b',text,flags=re.I): parts.append('Verified Exporter')
    yrs=re.search(r'\b(\d+\s*(?:yrs?|years?|months?))\b',text,flags=re.I)
    if yrs: parts.append(yrs.group(1))
    rating=re.search(r'\b([1-5](?:\.\d)?)\s*\((\d{1,7})\)',text)
    if rating: parts.append('Rating %s (%s)'%(rating.group(1),rating.group(2)))
    return '; '.join(parts)


def _indiamart_model_from_title(title):
    title=_clean_text(title)
    for pat in (r'\b(SF\d{6,12})\b', r'\bModel\s*(?:No\.?|Name/Number)?\s*[:\-]\s*([A-Za-z0-9][A-Za-z0-9+./_-]{1,40})'):
        m=re.search(pat,title,flags=re.I)
        if m: return _clean_text(m.group(1))
    return ''


def _indiamart_link_is_productish(url):
    try:
        p = urlparse(url)
        host = (p.hostname or '').lower()
        if not (host == 'indiamart.com' or host.endswith('.indiamart.com')):
            return False
        path = (p.path or '/').lower()
        if path in ('', '/') or '/search.' in path or host.startswith('dir.') or host.startswith('m.'):
            return False
        if any(x in path for x in ('/proddetail/', '/product/', '/products/', 'product-detail')):
            return True
        # IndiaMART seller microsites also expose product pages as .html paths.
        return path.endswith('.html') and not any(x in path for x in ('about', 'contact', 'profile', 'sitemap'))
    except Exception:
        return False


def _indiamart_title_from_url(url):
    """Best-effort display title for a discovered product/storefront URL."""
    try:
        p = urlparse(url or "")
        leaf = unquote((p.path or "").rstrip("/").rsplit("/", 1)[-1])
    except Exception:
        return ""
    leaf = re.sub(r"\.(?:html?|aspx?)$", "", leaf, flags=re.I)
    leaf = re.sub(r"[-_](?:\d{6,})(?:[-_].*)?$", "", leaf)
    leaf = re.sub(r"[-_]+", " ", leaf)
    leaf = re.sub(r"\s+", " ", leaf).strip(" -_")
    if not leaf or leaf.lower() in {"product", "products", "proddetail", "detail"}:
        return ""
    return leaf[:220].title()


def _search_hint_record(url, title, snippet):
    title = _clean_indiamart_title(title) or _indiamart_title_from_url(url)
    snippet = _html_to_text(snippet)
    if not title:
        return None
    supplier = _first_regex(snippet + ' ' + title, (
        r'(?:by|from)\s+([A-Z][A-Za-z0-9 &.,()\-]{2,100})(?:\s+(?:in|at)\s+|\s*[|\-]|$)',
    ))
    contact = _normalise_indiamart_phone(_first_regex(snippet, (
        r'((?:\+?91[\s-]?)?[6-9]\d{9})',
        r'(0\d{2,5}[\s-]?\d{5,8})',
    )))
    price = _indiamart_price(_first_regex(snippet + ' ' + title, (
        r'((?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?(?:\s*(?:/|per)\s*[A-Za-z .-]{1,30})?)',
    )))
    return {
        "product_name": title,
        "model": "",
        "specs": snippet[:900],
        "purchase_price": price,
        "price_date": "Live IndiaMART",
        "supplier": supplier,
        "contact": contact,
        "location": "",
        "supplier_location": "",
        "category": "IndiaMART",
        "product_link": url,
        "image_link": "",
        "contact_status": "available" if contact else "view_on_indiamart",
        "source_sheet": "IndiaMART Live",
        "source_row": url,
        "source_type": "indiamart",
    }


def _extract_indiamart_search_links(page, base_url, limit=INDIAMART_DISCOVERY_MAX_LINKS):
    found = []
    seen = set()
    anchors = list(re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', page or '', flags=re.I | re.S))
    for m in anchors:
        url = _decode_search_result_url(m.group(1), base_url)
        if not url or not _indiamart_link_is_productish(url):
            continue
        key = _canonical_indiamart_url(url) or url.split('#', 1)[0].lower()
        if key in seen:
            continue
        seen.add(key)
        title = _html_to_text(m.group(2))
        region = page[max(0, m.start()-250):min(len(page), m.end()+900)]
        snippet = _html_to_text(region)
        found.append((url, title, snippet))
        if len(found) >= limit:
            break
    # Search-engine HTML sometimes stores outbound links in JSON instead of anchors.
    if len(found) < limit:
        for raw in re.findall(r'https?:\\?/\\?/[^"\'<>\s]+', page or '', flags=re.I):
            raw = html_lib.unescape(raw.replace('\\/', '/'))
            url = _indiamart_abs_url(raw, base_url)
            if not url or not _indiamart_link_is_productish(url):
                continue
            key = _canonical_indiamart_url(url) or url.split('#', 1)[0].lower()
            if key in seen:
                continue
            seen.add(key)
            found.append((url, '', ''))
            if len(found) >= limit:
                break
    # Some engines keep the destination as plain/escaped text rather than a
    # clickable anchor.  Catch IndiaMART URLs with or without a scheme.
    if len(found) < limit:
        expanded = html_lib.unescape((page or '').replace('\\/', '/').replace('\\u0026', '&'))
        patterns = (
            r'https?://(?:[a-z0-9-]+\.)*indiamart\.com/[^"\'<>\s&]+',
            r'(?<![a-z0-9.-])(?:www\.)?(?:[a-z0-9-]+\.)?indiamart\.com/[^"\'<>\s&]+',
        )
        for pattern in patterns:
            for raw in re.findall(pattern, expanded, flags=re.I):
                raw = raw.rstrip(').,;]')
                if not raw.lower().startswith(('http://', 'https://')):
                    raw = 'https://' + raw
                url = _indiamart_abs_url(raw, base_url)
                if not url or not _indiamart_link_is_productish(url):
                    continue
                key = _canonical_indiamart_url(url) or url.split('#', 1)[0].lower()
                if key in seen:
                    continue
                seen.add(key)
                found.append((url, '', ''))
                if len(found) >= limit:
                    return found
    return found


def _extract_bing_rss_indiamart_links(page, base_url, limit=INDIAMART_DISCOVERY_MAX_LINKS):
    """Parse Bing's lightweight public RSS search output for IndiaMART product pages.

    This is a zero-key fallback for cases where IndiaMART's own search HTML is
    temporarily empty/thin.  It only uses URLs already present in the public
    search index; it does not bypass IndiaMART access controls.
    """
    found, seen = [], set()
    text = page or ''
    # RSS is simple enough to parse defensively without introducing another
    # dependency.  Keep the description because it often contains supplier/price.
    for item in re.findall(r'<item\b[^>]*>(.*?)</item>', text, flags=re.I | re.S):
        title = _html_to_text(_first_regex(item, (r'<title\b[^>]*>(.*?)</title>',)))
        link = _html_to_text(_first_regex(item, (r'<link\b[^>]*>(.*?)</link>',)))
        desc = _html_to_text(_first_regex(item, (r'<description\b[^>]*>(.*?)</description>',)))
        url = _indiamart_abs_url(html_lib.unescape(link), base_url)
        if not url or not _indiamart_link_is_productish(url):
            continue
        key = _canonical_indiamart_url(url) or url.split('#', 1)[0].lower()
        if key in seen:
            continue
        seen.add(key)
        found.append((url, title, desc))
        if len(found) >= limit:
            return found
    return found


def _discover_indiamart_links(query, limit=INDIAMART_DISCOVERY_MAX_LINKS, mode="standard", free_only=False):
    """Cost-aware IndiaMART discovery.

    The selected PriceMaster mode sets an API budget. Providers are tried in a
    cheap/fast ladder and the search stops early when enough unique IndiaMART
    links have already been found. The original Google/Bing/DDG HTML discovery is
    retained as a no-key / API-failure fallback.
    """
    query = _clean_text(query)
    mode = _normalize_search_mode(mode)
    if not query:
        return [], [], []
    profile = _search_mode_profile(mode)
    requested = max(1, min(int(limit or INDIAMART_DISCOVERY_MAX_LINKS), INDIAMART_DISCOVERY_MAX_LINKS))
    target = min(requested, int(profile["target_links"]))
    provider_cap = int(profile["paid_provider_cap"])
    gathered, errors, used = [], [], []
    successful_paid = 0

    # The IndiaMART toolbar uses free_only=True: never call Serper, Exa,
    # Tavily or Firecrawl even when keys happen to exist on the machine.
    # Direct IndiaMART HTML + public Google/Bing/DDG indexes remain keyless.
    if not free_only:
        for name, fn in _available_provider_ladder(mode):
            if successful_paid >= provider_cap or len(gathered) >= target:
                break
            try:
                rows = fn(query, min(requested, max(target, 10)), mode)
                used.append(name)
                if rows:
                    successful_paid += 1
                    gathered = _dedupe_discovered_links(gathered + rows, requested)
            except Exception as exc:
                errors.append(f"{name}: {exc}")

    # Existing HTML discovery only runs if paid discovery was unavailable/thin.
    # This preserves the old zero-key behavior without needlessly scraping three
    # search engines when a configured API already produced useful links.
    legacy_threshold = min(12 if mode == "minimum" else (30 if mode == "standard" else 60), requested)
    if len(gathered) < legacy_threshold:
        variants = _indiamart_discovery_variants(query, mode) or [query]
        variant_cap = 1 if mode == 'minimum' else (3 if mode == 'standard' else 5)
        engines = []
        # Keep the user's exact phrase first.  Deep mode adds a few controlled
        # aliases and two Bing RSS result windows; all are public search-index
        # discovery, so an IndiaMART 403/CAPTCHA is still respected.
        rss_jobs = []
        for variant in variants[:variant_cap]:
            site_query = variant + ' site:indiamart.com'
            q = quote(site_query)
            engines.extend([
                ('html', 'https://www.google.com/search?num=100&filter=0&hl=en&q=' + q),
                ('html', 'https://www.bing.com/search?count=50&q=' + q),
                ('html', 'https://html.duckduckgo.com/html/?q=' + q),
            ])
            # Bing RSS is much lighter than the normal result page and often
            # still exposes indexed IndiaMART product URLs when dynamic HTML is thin.
            rss_jobs.append(('rss', 'https://www.bing.com/search?format=rss&count=50&q=' + q))
            if mode == 'deep':
                rss_jobs.append(('rss', 'https://www.bing.com/search?format=rss&count=50&first=51&q=' + q))
        engines.extend(rss_jobs)
        legacy = []
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(engines))) as pool:
            futures = [(kind, pool.submit(_indiamart_search_engine_request, url, 5.5)) for kind, url in engines]
            for kind, future in futures:
                try:
                    final_url, page = future.result()
                    if kind == 'rss':
                        legacy.extend(_extract_bing_rss_indiamart_links(page, final_url, limit=requested))
                    else:
                        legacy.extend(_extract_indiamart_search_links(page, final_url, limit=requested))
                except Exception as exc:
                    errors.append(str(exc))
        if legacy:
            used.append("Public web index fallback")
        gathered = _dedupe_discovered_links(gathered + legacy, requested)

    return gathered[:requested], errors, used

def _indiamart_detail(url, hint_title="", hint_snippet="", timeout=16):
    url = _indiamart_abs_url(url, url)
    if not url or not _indiamart_link_is_productish(url):
        raise ValueError('Invalid IndiaMART product URL')
    key = url.split('#', 1)[0].lower()
    now = time.time()
    with _indiamart_lock:
        cached = _indiamart_detail_cache.get(key)
        if cached and now - cached[0] < INDIAMART_DETAIL_CACHE_SECONDS:
            _indiamart_detail_cache.move_to_end(key)
            return dict(cached[1])
    final_url, page = _indiamart_request(url, timeout=timeout)
    record = _indiamart_page_record(page, final_url, hint_title, hint_snippet)
    if not record:
        record = _search_hint_record(url, hint_title, hint_snippet)
    if not record:
        raise RuntimeError('IndiaMART product details were not readable')
    record['product_link'] = _indiamart_abs_url(final_url, final_url) or url
    record['search_text'] = _product_search_text(record)
    with _indiamart_lock:
        _indiamart_detail_cache[key] = (time.time(), dict(record))
        _indiamart_detail_cache.move_to_end(key)
        while len(_indiamart_detail_cache) > INDIAMART_DETAIL_CACHE_MAX:
            _indiamart_detail_cache.popitem(last=False)
    return record


def _indiamart_relevance(row, query):
    q = re.sub(r'[^a-z0-9]+', ' ', _clean_text(query).lower()).strip()
    text = re.sub(r'[^a-z0-9]+', ' ', _clean_text(' '.join(str(row.get(k) or '') for k in ('product_name','model','supplier','specs'))).lower()).strip()
    if not q or not text:
        return 0
    score = 0
    if q in text:
        score += 80
    qtokens = [t for t in q.split() if len(t) > 1 and t not in {'the','and','for','with','india','indiamart'}]
    for token in qtokens:
        if token in text:
            score += 8
    modelish = [t for t in qtokens if any(c.isdigit() for c in t)]
    for token in modelish:
        if token in text:
            score += 18
    if row.get('image_link'):
        score += 4
    if row.get('supplier'):
        score += 3
    if row.get('contact'):
        score += 2
    if row.get('purchase_price'):
        score += 2
    return score


def _enrich_indiamart_rows(rows, max_fetch=28):
    rows = [dict(r) for r in rows if r and _clean_text(r.get('product_name'))]
    if int(max_fetch or 0) <= 0:
        return rows
    jobs = []
    for idx, row in enumerate(rows):
        link = _clean_text(row.get('product_link'))
        if link and _indiamart_link_is_productish(link) and idx < max_fetch:
            # Fetch the real product page so image/supplier/contact are as exact as possible.
            if not (row.get('image_link') and row.get('supplier') and row.get('contact') and row.get('purchase_price')):
                jobs.append((idx, link, row.get('product_name',''), row.get('specs','')))
    if jobs:
        with ThreadPoolExecutor(max_workers=min(6, len(jobs))) as pool:
            futures = [(idx, pool.submit(_indiamart_detail, link, title, snippet, 6.5)) for idx, link, title, snippet in jobs]
            for idx, future in futures:
                try:
                    rows[idx] = _indiamart_merge_item(rows[idx], future.result())
                except Exception:
                    pass
    return rows

def _indiamart_set_cooldown(seconds):
    """Pause new IndiaMART requests after a temporary restriction/rate limit."""
    global _indiamart_blocked_until
    seconds = max(0.0, min(float(seconds or 0), 180.0))
    if not seconds:
        return
    with _indiamart_request_gate:
        _indiamart_blocked_until = max(_indiamart_blocked_until, time.monotonic() + seconds)


def _indiamart_wait_for_request_slot():
    """Small shared gap keeps wide searches fast without a request burst."""
    global _indiamart_next_request_at
    with _indiamart_request_gate:
        now = time.monotonic()
        if _indiamart_blocked_until > now:
            remaining = _indiamart_blocked_until - now
            raise RuntimeError(f"IndiaMART temporary cooldown active ({int(remaining) + 1}s)")
        wait = max(0.0, _indiamart_next_request_at - now)
        _indiamart_next_request_at = max(now, _indiamart_next_request_at) + INDIAMART_MIN_REQUEST_GAP
    if wait:
        time.sleep(wait)


def _indiamart_retry_after_seconds(exc, fallback):
    try:
        value = (exc.headers or {}).get('Retry-After', '')
        if value and str(value).strip().isdigit():
            return max(0.5, min(float(value), 12.0))
    except Exception:
        pass
    return max(0.5, min(float(fallback), 12.0))


def _indiamart_request(url, timeout=18):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
        "Referer": "https://www.indiamart.com/",
        "Connection": "keep-alive",
    }
    last_error = None
    for attempt in range(INDIAMART_TRANSIENT_RETRIES + 1):
        _indiamart_wait_for_request_slot()
        try:
            req = Request(url, headers=headers)
            with _indiamart_public_gate:
                with urlopen(req, timeout=timeout) as response:
                    raw = response.read(3 * 1024 * 1024)
                    body = raw.decode("utf-8", errors="replace")
                    final_url = response.geturl()
            low = body[:24000].lower()
            if "captcha" in low or "access denied" in low or "verify you are human" in low:
                _indiamart_set_cooldown(INDIAMART_VERIFY_COOLDOWN_SECONDS)
                raise RuntimeError("IndiaMART temporarily requested browser verification")
            return final_url, body
        except HTTPError as exc:
            last_error = exc
            code = int(getattr(exc, 'code', 0) or 0)
            # 403/verification is an access decision: do not try to evade it.
            if code == 403:
                _indiamart_set_cooldown(INDIAMART_VERIFY_COOLDOWN_SECONDS)
                raise RuntimeError("IndiaMART temporarily restricted automated requests (HTTP 403)") from exc
            # 429 and transient server failures may be retried after waiting.
            if code == 429 and attempt < INDIAMART_TRANSIENT_RETRIES:
                delay = _indiamart_retry_after_seconds(exc, 1.5 * (attempt + 1))
                _indiamart_set_cooldown(delay)
                time.sleep(delay + random.uniform(0.05, 0.22))
                continue
            if code in (500, 502, 503, 504) and attempt < INDIAMART_TRANSIENT_RETRIES:
                delay = min(3.5, 0.45 * (2 ** attempt)) + random.uniform(0.05, 0.2)
                time.sleep(delay)
                continue
            raise
        except URLError as exc:
            last_error = exc
            reason_text = str(getattr(exc, 'reason', exc) or '').lower()
            # DNS/offline/refused failures do not improve by repeating dozens of
            # wide-search requests.  Fail them immediately so the public-index
            # fallback can answer quickly instead of making the UI wait minutes.
            hard_network = any(token in reason_text for token in (
                'name resolution', 'getaddrinfo', 'no address associated',
                'network is unreachable', 'connection refused', 'nodename nor servname',
            ))
            if hard_network:
                raise
            if attempt < INDIAMART_TRANSIENT_RETRIES:
                time.sleep(min(1.2, 0.30 * (2 ** attempt)) + random.uniform(0.04, 0.14))
                continue
            raise
    if last_error:
        raise last_error
    raise RuntimeError("IndiaMART request failed")



def _indiamart_public_request_fast(url, timeout=4.2):
    """One keyless public-page request with no retry/cooldown wait.

    This is used by the toolbar free scraper. A 403/429 is treated as a normal
    unavailable source and we immediately continue with the other public sources.
    It intentionally does not try to evade CAPTCHA or verification controls.
    """
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
        "Cache-Control": "no-cache",
        "Referer": "https://www.indiamart.com/",
    })
    with _indiamart_public_gate:
        with urlopen(req, timeout=max(2.5, min(float(timeout or 4.2), 6.0))) as response:
            raw = response.read(3 * 1024 * 1024)
            final_url = response.geturl()
    return final_url, raw.decode("utf-8", errors="replace")


def search_indiamart_free_fast(query, limit=INDIAMART_MAX_RESULTS, mode="standard"):
    """Fast free IndiaMART search using a Google-style '<product> indiamart' flow.

    F14.8 keeps the F14.7 free toolbar behavior and adds stability controls in three important ways:
      1) web-index queries look like a person searching 'multimeter indiamart',
      2) ranked ``dir.indiamart.com`` category pages are accepted and parsed,
      3) live directory/product rows rank ahead of the bundled PDF snapshot.

    No paid API key is required and access controls/CAPTCHA are not bypassed.
    """
    query = _clean_text(query)
    mode = _normalize_search_mode(mode)
    if not query:
        return [], {"ok": True, "searched": False, "source": "IndiaMART", "freeScrapeApi": True, "requiresApiKey": False, "searchMode": mode}

    effective_query = _correct_obvious_query_typos(query) or query
    requested = max(1, min(int(limit or INDIAMART_MAX_RESULTS), INDIAMART_MAX_RESULTS))
    cache_key = "freefast|f148|" + mode + "|" + effective_query.lower()
    now = time.time()
    with _indiamart_lock:
        cached = _indiamart_cache.get(cache_key)
        if cached and now - cached[0] < INDIAMART_CACHE_SECONDS and len(cached[1]) >= requested:
            _indiamart_cache.move_to_end(cache_key)
            return list(cached[1][:requested]), dict(cached[2], cached=True, cachedPoolSize=len(cached[1]))

    variants = _search_query_variants(query, mode) or [effective_query]
    if effective_query.casefold() != query.casefold():
        variants = [query, effective_query] + [v for v in variants if v.casefold() not in {query.casefold(), effective_query.casefold()}]
    variants = variants[:(2 if effective_query.casefold() != query.casefold() else (1 if mode == "minimum" else 2))]

    # IndiaMART's own search page remains useful, but it is no longer the only
    # live source.  Directory pages found through a Google-style query are often
    # much richer (price, seller, city, image, product URL).
    direct_jobs = []
    for v in variants:
        enc = quote(v)
        direct_jobs.append(("IndiaMART search", INDIAMART_SEARCH_URL.format(query=enc) + "&prdsrc=1"))
        if mode != "minimum":
            direct_jobs.append(("IndiaMART mobile search", INDIAMART_MOBILE_SEARCH_URL.format(query=enc) + "&prdsrc=1"))
    direct_jobs = direct_jobs[:2 if mode == "minimum" else 4]

    seed_cap = 2 if mode == "minimum" else (6 if mode == "standard" else 12)
    seed_category_urls = _indiamart_seed_category_urls(effective_query, mode, seed_cap)

    # This is the requested search shape: 'multimeter indiamart'.  Bing RSS and
    # DDG are used as free public indexes.  The query semantics are Google-like;
    # if a Serper key is configured elsewhere, the non-free search path can still
    # use Google's ranked index through Serper.
    google_style_queries = _google_style_indiamart_queries(effective_query, mode)
    query_cap = 1 if mode == "minimum" else (2 if mode == "standard" else 3)
    index_jobs = []
    for web_query in google_style_queries[:query_cap]:
        q = quote(web_query)
        index_jobs.append(("Bing RSS · " + web_query, "https://www.bing.com/search?format=rss&count=50&q=" + q, "rss"))
        index_jobs.append(("DuckDuckGo · " + web_query, "https://html.duckduckgo.com/html/?q=" + q, "html"))

    rows, discovered, directory_links, errors, methods = [], [], [], [], []
    live_directory_rows = 0
    directory_pages_fetched = 0
    advertised = ""

    # Fetch direct IndiaMART search + conservative category guesses + free web index in parallel.
    work = []
    max_workers = min(INDIAMART_PUBLIC_MAX_CONCURRENCY, max(1, len(direct_jobs) + len(seed_category_urls) + len(index_jobs)))
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        for name, url in direct_jobs:
            work.append(("direct", name, url, pool.submit(_indiamart_public_request_fast, url, 4.4)))
        for url in seed_category_urls:
            work.append(("category", "IndiaMART category seed", url, pool.submit(_indiamart_public_request_fast, url, 4.4)))
        for name, url, kind in index_jobs:
            work.append((kind, name, url, pool.submit(_indiamart_search_engine_request, url, 4.4)))

        for kind, name, original_url, future in work:
            try:
                final_url, page = future.result()
                if kind in {"direct", "category"}:
                    parsed = _parse_indiamart_html(page, final_url)
                    if parsed:
                        rows.extend(parsed)
                        if kind == "category" or _indiamart_link_is_directory_listing(final_url):
                            live_directory_rows += len(parsed)
                    discovered.extend(_extract_indiamart_search_links(page, final_url, limit=min(requested, 500)))
                    for related in _extract_indiamart_related_urls(page, final_url, effective_query, limit=10):
                        directory_links.append((related, "", "IndiaMART related category"))
                    if kind == "category":
                        directory_pages_fetched += 1
                    if not advertised:
                        advertised = _indiamart_result_count_hint(page)
                else:
                    # Product pages + category/directory pages are both valuable.
                    if kind == "rss":
                        discovered.extend(_extract_bing_rss_indiamart_links(page, final_url, limit=min(requested, 500)))
                    else:
                        discovered.extend(_extract_indiamart_search_links(page, final_url, limit=min(requested, 500)))
                    directory_links.extend(_extract_indiamart_directory_links_from_index(page, final_url, limit=80))
                methods.append(name)
            except Exception as exc:
                errors.append(name + ": " + str(exc))

    discovered = _dedupe_discovered_links(discovered, requested)

    # Merge category seeds and index-discovered directory pages, then fetch the
    # strongest few.  This is the path that captures cards like the user's sample:
    # Digital Multimeter SF00001627 / Instrumentation / Coimbatore / ₹1,820.
    dir_seen = set()
    ordered_directory_urls = []
    for url in seed_category_urls:
        key = _canonical_indiamart_url(url) or url.lower()
        if key not in dir_seen:
            dir_seen.add(key); ordered_directory_urls.append(url)
    for url, _title, _snippet in directory_links:
        key = _canonical_indiamart_url(url) or url.lower()
        if key not in dir_seen:
            dir_seen.add(key); ordered_directory_urls.append(url)

    extra_dir_cap = 2 if mode == "minimum" else (6 if mode == "standard" else 12)
    # Seed pages were already fetched above; only fetch additional ranked pages here.
    seed_keys = {_canonical_indiamart_url(u) or u.lower() for u in seed_category_urls}
    extra_dirs = [u for u in ordered_directory_urls if (_canonical_indiamart_url(u) or u.lower()) not in seed_keys][:extra_dir_cap]
    failed_dir_urls = []
    if extra_dirs:
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(extra_dirs))) as pool:
            jobs = [(url, pool.submit(_indiamart_public_request_fast, url, 4.6)) for url in extra_dirs]
            for url, future in jobs:
                try:
                    final_url, page = future.result()
                    parsed = _parse_indiamart_html(page, final_url)
                    if parsed:
                        rows.extend(parsed)
                        live_directory_rows += len(parsed)
                    discovered.extend(_extract_indiamart_search_links(page, final_url, limit=min(requested, 500)))
                    directory_pages_fetched += 1
                    methods.append("Google-style IndiaMART directory page")
                except Exception as exc:
                    failed_dir_urls.append(url)
                    errors.append("IndiaMART directory: " + str(exc))
        discovered = _dedupe_discovered_links(discovered, requested)

    # If urllib receives thin/blocked directory HTML, try the user's installed
    # Edge/Chrome for at most two top-ranked directory pages. This does not evade
    # verification; it only renders the same public page normally.
    if live_directory_rows == 0 and failed_dir_urls and _find_local_chromium_browser():
        for url in failed_dir_urls[:2]:
            try:
                final_url, page = _browser_dump_dom(url, 16 if mode != "deep" else 20)
                parsed = _parse_indiamart_html(page, final_url)
                if parsed:
                    rows.extend(parsed)
                    live_directory_rows += len(parsed)
                    directory_pages_fetched += 1
                    methods.append("Browser-rendered IndiaMART directory")
            except Exception as exc:
                errors.append("Browser directory: " + str(exc))

    # Existing broad browser discovery remains a zero-key fallback for unusually
    # thin index/direct results.
    if len(rows) + len(discovered) < (2 if mode == "minimum" else 6):
        try:
            browser_rows, browser_links, browser_errors, browser_methods = _browser_indiamart_discovery(
                effective_query, "minimum" if mode == "minimum" else "standard", min(requested, 180)
            )
            if browser_rows:
                rows.extend(browser_rows)
            if browser_links:
                discovered.extend(browser_links)
                discovered = _dedupe_discovered_links(discovered, requested)
            errors.extend(browser_errors)
            methods.extend(browser_methods)
        except Exception as exc:
            errors.append("Local browser fallback: " + str(exc))

    managed_storefront_hosts = 0
    if len(rows) + len(discovered) < (3 if mode == "minimum" else 8):
        try:
            managed_mode = "minimum" if mode == "minimum" else "standard"
            managed_rows, managed_errors, managed_methods, managed_storefront_hosts = _discover_indiamart_managed_storefronts(
                effective_query, managed_mode, min(requested, 80)
            )
            if managed_rows:
                rows.extend(managed_rows)
            errors.extend(managed_errors)
            methods.extend(managed_methods)
        except Exception as exc:
            errors.append("IndiaMART managed storefront fallback: " + str(exc))

    # Detail-enrich the strongest product URLs found by the web-index search.
    detail_cap = 4 if mode == "minimum" else (10 if mode == "standard" else 18)
    detail_items = discovered[:min(detail_cap, len(discovered))]
    detailed_keys = set()
    if detail_items:
        with ThreadPoolExecutor(max_workers=min(INDIAMART_PUBLIC_MAX_CONCURRENCY, len(detail_items))) as pool:
            jobs = [(url, title, snippet, pool.submit(_indiamart_public_request_fast, url, 4.2)) for url, title, snippet in detail_items]
            for url, title, snippet, future in jobs:
                try:
                    final_url, page = future.result()
                    rec = _indiamart_page_record(page, final_url, title, snippet)
                    if rec:
                        rows.append(rec)
                        detailed_keys.add(_canonical_indiamart_url(url) or url.lower())
                except Exception:
                    pass

    for url, title, snippet in discovered:
        key = _canonical_indiamart_url(url) or url.lower()
        if key in detailed_keys:
            continue
        rec = _search_hint_record(url, title, snippet)
        if rec:
            rows.append(rec)
        if len(rows) >= requested:
            break

    # PDF is now a true fallback, not the first source. The user's complaint was
    # that 28 saved PDF rows hid the current Google/IndiaMART directory content.
    live_before_pdf = len(rows)
    pdf_rows, pdf_snapshot_titles = _indiamart_pdf_snapshot_rows(effective_query, requested)
    pdf_fallback_used = False
    if live_before_pdf < 3 and pdf_rows:
        rows.extend(pdf_rows)
        pdf_fallback_used = True
        methods.append("Bundled IndiaMART PDF fallback")

    # Collapse identical product URLs before applying the user's supplier+price
    # offer dedupe. Web indexes can rediscover the same URL already parsed from a
    # directory card; it must remain one Price List row, not a second hint row.
    exact_url_rows = OrderedDict()
    rows_without_url = []
    for row in rows:
        link_key = _canonical_indiamart_url(row.get("product_link")) if isinstance(row, dict) else ""
        if not link_key:
            rows_without_url.append(row)
            continue
        if link_key in exact_url_rows:
            exact_url_rows[link_key] = _indiamart_merge_item(exact_url_rows[link_key], row)
        else:
            exact_url_rows[link_key] = dict(row)
    rows = list(exact_url_rows.values()) + rows_without_url

    by_key = OrderedDict()
    for row in rows:
        if not row or not _clean_text(row.get("product_name")):
            continue
        if _indiamart_relevance(row, effective_query) <= 0:
            continue
        dkey = _indiamart_offer_dedupe_key(row)
        if dkey in by_key:
            by_key[dkey] = _indiamart_merge_item(by_key[dkey], row)
        else:
            by_key[dkey] = dict(row)
    rows = list(by_key.values())

    # Prefer current directory/live rows when relevance is otherwise similar.
    def _rank(row):
        score = _indiamart_relevance(row, effective_query)
        source = _clean_text(row.get("source_sheet") or "").lower()
        if "directory" in source or (row.get("product_link") and "/proddetail/" in str(row.get("product_link"))):
            score += 16
        if row.get("pdf_snapshot"):
            score -= 12
        if row.get("purchase_price"):
            score += 4
        if row.get("supplier"):
            score += 4
        if row.get("supplier_location") or row.get("location"):
            score += 2
        return score
    rows.sort(key=_rank, reverse=True)
    rows = _dedupe_indiamart_products(rows)[:requested]
    rows, translated_fields = _translate_rows_to_english(rows)
    rows = _dedupe_indiamart_products(rows)[:requested]
    for row in rows:
        row["source_type"] = "indiamart"
        row["source_sheet"] = row.get("source_sheet") or "IndiaMART Google-style Live"
        row["search_text"] = _product_search_text(row)
        if not row.get("supplier_location"):
            row["supplier_location"] = _clean_text(row.get("location") or "")
        if not row.get("contact"):
            row["contact_status"] = "view_on_indiamart"

    info = {
        "ok": bool(rows),
        "searched": True,
        "source": "IndiaMART",
        "query": query,
        "effectiveQuery": effective_query,
        "queryCorrected": effective_query.casefold() != query.casefold(),
        "count": len(rows),
        "searchUrl": INDIAMART_SEARCH_URL.format(query=quote(effective_query)),
        "googleStyleQuery": google_style_queries[0] if google_style_queries else (effective_query + " indiamart"),
        "searchMode": mode,
        "searchModeLabel": _search_mode_profile(mode)["label"],
        "freeScrapeApi": True,
        "requiresApiKey": False,
        "searchApisConfigured": [],
        "searchApisUsed": [],
        "scrapeArchitecture": "Google-style '<product> indiamart' public-index discovery + IndiaMART directory/category parsing + product detail enrichment + persistent fallback",
        "methods": list(dict.fromkeys(methods)),
        "liveRowsBeforePdf": live_before_pdf,
        "liveDirectoryRows": live_directory_rows,
        "directoryPagesFetched": directory_pages_fetched,
        "directoryPagesDiscovered": len(ordered_directory_urls),
        "pdfFallbackUsed": pdf_fallback_used,
        "pdfSnapshotCount": sum(1 for r in rows if r.get("pdf_snapshot")),
        "pdfSnapshotsUsed": pdf_snapshot_titles if pdf_fallback_used else [],
        "discoveredLinks": len(discovered),
        "managedStorefrontHosts": managed_storefront_hosts,
        "advertisedProductCount": advertised,
        "dedupeRule": "same company + same price",
        "translatedFields": translated_fields,
        "fullSearchComplete": not bool(errors),
        "complete": not bool(errors),
        "partial": bool(errors) and bool(rows),
        "dataStatus": "live" if live_before_pdf > 0 else ("saved" if rows else "unavailable"),
        "sourceErrors": errors[-8:],
        "returnedUniqueOffers": len(rows),
        "resultLimit": requested,
        "build": APP_BUILD,
        "supplierCount": len({_clean_text(r.get("supplier")).lower() for r in rows if _clean_text(r.get("supplier"))}),
        "phoneCount": sum(1 for r in rows if r.get("contact")),
    }
    if errors and not rows:
        info["error"] = errors[-1]
    elif errors:
        info["warning"] = errors[-1]
    if rows:
        with _indiamart_lock:
            _indiamart_cache[cache_key] = (time.time(), list(rows), dict(info))
            _indiamart_cache.move_to_end(cache_key)
            while len(_indiamart_cache) > INDIAMART_CACHE_MAX:
                _indiamart_cache.popitem(last=False)
    return rows, info

def search_indiamart(query, limit=INDIAMART_MAX_RESULTS, mode="standard", free_only=False):
    query = _clean_text(query)
    mode = _normalize_search_mode(mode)
    if not query:
        return [], {"ok": True, "searched": False, "source": "IndiaMART", "searchMode": mode}
    profile = _search_mode_profile(mode)
    key = ("free|" if free_only else "auto|") + mode + "|" + query.lower()
    now = time.time()
    stale_cached = None
    used_stale_cache = False
    with _indiamart_lock:
        cached = _indiamart_cache.get(key)
        if cached:
            age = now - cached[0]
            cached_rows = cached[1] or []
            cache_ttl = INDIAMART_CACHE_SECONDS if cached_rows else INDIAMART_EMPTY_CACHE_SECONDS
            if age < cache_ttl:
                _indiamart_cache.move_to_end(key)
                return list(cached_rows), dict(cached[2], cached=True)
            if age < INDIAMART_STALE_CACHE_SECONDS and cached_rows:
                stale_cached = cached

    encoded = quote(query)
    requested_limit = max(1, min(int(limit or INDIAMART_MAX_RESULTS), INDIAMART_MAX_RESULTS))
    page_count = int(profile["direct_pages"])
    start_offset_pages = int(profile.get("start_offsets", page_count))
    related_page_cap = int(profile.get("related_pages", 0))

    # Search the user's exact phrase plus a controlled keyword ladder. IndiaMART
    # currently exposes continuation with a `start=` offset on many search feeds;
    # older deployments also accepted `page=`. We prefer start= and keep only a
    # tiny page= compatibility fallback. This fixes the old behavior where many
    # requests could accidentally return page 1 again and therefore look like a
    # six-product cap after deduplication.
    query_variants = _search_query_variants(query, mode) or [query]
    urls = []
    offset_step = 20
    variant_offset_pages = 2 if mode == "minimum" else (4 if mode == "standard" else 6)
    strong_variant_cap = 1 if mode == "minimum" else (2 if mode == "standard" else 4)
    for idx, variant in enumerate(query_variants):
        base = INDIAMART_SEARCH_URL.format(query=quote(variant)) + "&prdsrc=1"
        urls.append(base)
        count = start_offset_pages if idx == 0 else (variant_offset_pages if idx < strong_variant_cap else 1)
        for n in range(1, max(1, count)):
            urls.append(base + f"&start={n * offset_step}")
    # Small compatibility sweep for IndiaMART layouts that still map page=N.
    for page in range(2, min(page_count, 4 if mode == "deep" else 3) + 1):
        urls.append(INDIAMART_SEARCH_URL.format(query=encoded) + f"&prdsrc=1&page={page}")
    direct_request_cap = 14 if mode == "minimum" else (42 if mode == "standard" else 72)
    urls = list(dict.fromkeys(urls))[:direct_request_cap]

    rows, errors, methods = [], [], []
    discovered = []
    direct_discovered = []
    discovery_methods = []
    related_urls = []
    seed_category_urls = []
    browser_fallback_used = False
    managed_storefront_used = False
    managed_storefront_hosts = 0
    advertised_count_hint = ""
    api_names = [] if free_only else _configured_search_api_names()

    # V16.8.14: the successful PH-meter recovery path now runs generically for
    # every Standard/Deep product search.  Category candidates are derived only
    # from the typed words/controlled aliases and run in the SAME parallel pool,
    # so wider coverage does not add a separate blocking stage to normal searches.
    initial_seed_cap = 0 if mode == "minimum" else (8 if mode == "standard" else 16)
    if initial_seed_cap:
        seed_sources = query_variants[:(2 if mode == "standard" else 4)] or [query]
        seed_category_urls = []
        for seed_query in seed_sources:
            seed_category_urls.extend(_indiamart_seed_category_urls(seed_query, mode, initial_seed_cap))
        seed_category_urls = list(dict.fromkeys(seed_category_urls))[:initial_seed_cap]
    search_budget = max(1, direct_request_cap - len(seed_category_urls))
    request_jobs = [('search', url) for url in urls[:search_budget]]
    request_jobs.extend(('category', url) for url in seed_category_urls if url not in urls[:search_budget])

    # Direct IndiaMART feed, typed category sweep and external link discovery
    # start together. Requests remain globally paced by _indiamart_request.
    direct_workers = 5 if mode == "minimum" else (14 if mode == "standard" else 24)
    with ThreadPoolExecutor(max_workers=min(direct_workers, max(2, len(request_jobs) + 1))) as pool:
        direct_futures = [
            (kind, pool.submit(_indiamart_request, url, 4.8 if api_names else 5.4))
            for kind, url in request_jobs
        ]
        discovery_queries = (query_variants[:1] if mode == "minimum" else query_variants[:(3 if mode == "standard" else 6)]) or [query]
        per_discovery_limit = max(180, min(INDIAMART_DISCOVERY_MAX_LINKS, requested_limit) // max(1, len(discovery_queries)))
        discovery_futures = [
            (dq, pool.submit(_discover_indiamart_links, dq, per_discovery_limit, mode, free_only))
            for dq in discovery_queries
        ] if query else []
        for kind, future in direct_futures:
            try:
                final_url, body = future.result()
                parsed_rows = _parse_indiamart_html(body, final_url)
                if parsed_rows:
                    methods.append('IndiaMART typed category sweep' if kind == 'category' else 'IndiaMART direct offset feed')
                    rows.extend(parsed_rows)
                if not advertised_count_hint:
                    advertised_count_hint = _indiamart_result_count_hint(body)
                embedded_links = _extract_indiamart_search_links(body, final_url, limit=requested_limit)
                if embedded_links:
                    direct_discovered.extend(embedded_links)
                if related_page_cap:
                    related_urls.extend(_extract_indiamart_related_urls(
                        body, final_url, query=query, limit=related_page_cap
                    ))
            except Exception as exc:
                errors.append(str(exc))
        for dq, discovery_future in discovery_futures:
            try:
                discovered_part, discovery_errors, discovery_part_methods = discovery_future.result()
                if discovered_part:
                    discovered.extend(discovered_part)
                errors.extend(discovery_errors)
                discovery_methods.extend(discovery_part_methods)
                methods.extend(discovery_part_methods)
            except Exception as exc:
                errors.append(str(exc))

    discovered = _dedupe_discovered_links(direct_discovered + discovered, requested_limit)
    if direct_discovered:
        methods.append('IndiaMART embedded-link expansion')

    # If a long/noisy phrase produced only a handful of offers, automatically
    # search the remaining relaxed variants before declaring the list complete.
    # This is the server-side replacement for the old UI state that could stay at
    # "2 offers · wider search still loading in background".
    thin_target = 12 if mode == "minimum" else (40 if mode == "standard" else 90)
    if len(rows) + len(discovered) < thin_target and len(query_variants) > len(discovery_queries):
        extra_queries = query_variants[len(discovery_queries):]
        extra_queries = extra_queries[:(2 if mode == "standard" else 6)]
        if extra_queries:
            per_extra_limit = max(160, min(INDIAMART_DISCOVERY_MAX_LINKS, requested_limit) // max(2, len(extra_queries) + 1))
            with ThreadPoolExecutor(max_workers=min(6, len(extra_queries))) as extra_pool:
                jobs = [(dq, extra_pool.submit(_discover_indiamart_links, dq, per_extra_limit, mode, free_only)) for dq in extra_queries]
                for dq, future in jobs:
                    try:
                        extra_links, extra_errors, extra_methods = future.result()
                        discovered = _dedupe_discovered_links(discovered + extra_links, requested_limit)
                        errors.extend(extra_errors)
                        discovery_methods.extend(extra_methods)
                        methods.extend(extra_methods)
                    except Exception as exc:
                        errors.append(str(exc))
            methods.append('IndiaMART relaxed-query full-list recovery')

    # Follow the public related-category links shown by IndiaMART itself. For a
    # search such as "PH Meter" this captures the visible lists for pH Testers,
    # Digital pH Meter, pH Analyzer, Pocket Tester, Benchtop pH Meter, etc. This
    # broadens coverage without fabricating unrelated keywords.
    related_urls = list(dict.fromkeys(related_urls))[:related_page_cap]
    if related_urls:
        with ThreadPoolExecutor(max_workers=min(6 if mode != "deep" else 8, len(related_urls))) as pool:
            futures = [pool.submit(_indiamart_request, url, 5.0 if mode != "deep" else 5.8) for url in related_urls]
            for future in futures:
                try:
                    final_url, body = future.result()
                    parsed_rows = _parse_indiamart_html(body, final_url)
                    if parsed_rows:
                        methods.append('IndiaMART related categories')
                        rows.extend(parsed_rows)
                except Exception as exc:
                    errors.append(str(exc))

    # Zero/thin-result recovery: if the initial generic sweep is still thin,
    # try additional public IndiaMART category pages derived directly from the
    # typed product term and controlled aliases. It does not attempt to bypass a 403,
    # CAPTCHA or verification cooldown; those remain respected by _indiamart_request.
    seed_threshold = 8 if mode == "minimum" else (20 if mode == "standard" else 45)
    if len(rows) < seed_threshold:
        seed_cap = 3 if mode == "minimum" else (7 if mode == "standard" else 12)
        existing_related = {_canonical_indiamart_url(x) for x in related_urls}
        already_seeded = {_canonical_indiamart_url(x) for x in seed_category_urls}
        extra_seed_urls = [
            u for u in _indiamart_seed_category_urls(query, mode, max(seed_cap, initial_seed_cap + seed_cap))
            if _canonical_indiamart_url(u) not in existing_related
            and _canonical_indiamart_url(u) not in already_seeded
        ][:seed_cap]
        if extra_seed_urls:
            second_level = []
            with ThreadPoolExecutor(max_workers=min(3 if mode == "minimum" else 5, len(extra_seed_urls))) as pool:
                futures = [pool.submit(_indiamart_request, url, 5.0 if mode != "deep" else 5.8) for url in extra_seed_urls]
                for future in futures:
                    try:
                        final_url, body = future.result()
                        parsed_rows = _parse_indiamart_html(body, final_url)
                        if parsed_rows:
                            methods.append('IndiaMART typed category recovery')
                            rows.extend(parsed_rows)
                        if related_page_cap and len(rows) < seed_threshold * 2:
                            second_level.extend(_extract_indiamart_related_urls(
                                body, final_url, query=query, limit=max(2, related_page_cap // 2)
                            ))
                    except Exception as exc:
                        errors.append(str(exc))
            seed_category_urls.extend(extra_seed_urls)
            seed_category_urls = list(dict.fromkeys(seed_category_urls))
            # Follow a few IndiaMART-supplied related lists discovered from the
            # typed category page, but keep it bounded for speed.
            if second_level and len(rows) < seed_threshold * 2:
                seed_keys = {_canonical_indiamart_url(x) for x in (seed_category_urls + extra_seed_urls)}
                second_level = [
                    u for u in dict.fromkeys(second_level)
                    if _canonical_indiamart_url(u) not in seed_keys
                ][:max(2, related_page_cap // 2)]
                if second_level:
                    with ThreadPoolExecutor(max_workers=min(4, len(second_level))) as pool:
                        futures = [pool.submit(_indiamart_request, url, 5.6) for url in second_level]
                        for future in futures:
                            try:
                                final_url, body = future.result()
                                parsed_rows = _parse_indiamart_html(body, final_url)
                                if parsed_rows:
                                    methods.append('IndiaMART category related-list recovery')
                                    rows.extend(parsed_rows)
                            except Exception as exc:
                                errors.append(str(exc))

    # Mobile fallback is only used when the desktop/JSON feed is still thin. Use
    # start offsets here as well so repeated page-1 results do not dominate.
    direct_threshold = 18 if mode == "minimum" else (50 if mode == "standard" else 100)
    if len(rows) < direct_threshold:
        mobile_pages = 2 if mode == 'minimum' else (4 if mode == 'standard' else 6)
        mobile_base = INDIAMART_MOBILE_SEARCH_URL.format(query=encoded) + "&prdsrc=1"
        mobile_urls = [mobile_base] + [mobile_base + f"&start={n * offset_step}" for n in range(1, mobile_pages)]
        with ThreadPoolExecutor(max_workers=min(4 if mode != "deep" else 6, len(mobile_urls))) as pool:
            futures = [pool.submit(_indiamart_request, url, 4.8 if mode == 'minimum' else 5.4) for url in mobile_urls]
            for future in futures:
                try:
                    final_url, body = future.result()
                    parsed_rows = _parse_indiamart_html(body, final_url)
                    if parsed_rows:
                        methods.append('IndiaMART mobile offset feed')
                        rows.extend(parsed_rows)
                except Exception as exc:
                    errors.append(str(exc))

    # If plain HTTP still produced nothing, retry with the installed Edge/Chrome
    # renderer. This is only a fallback, so current fast searches stay fast.
    if not rows and not discovered:
        try:
            browser_rows, browser_links, browser_errors, browser_methods = _browser_indiamart_discovery(
                query, mode, min(INDIAMART_DISCOVERY_MAX_LINKS, requested_limit)
            )
            if browser_rows or browser_links:
                browser_fallback_used = True
                rows.extend(browser_rows)
                discovered = _dedupe_discovered_links(discovered + browser_links, requested_limit)
            errors.extend(browser_errors)
            methods.extend(browser_methods)
        except Exception as exc:
            errors.append('Browser fallback: ' + str(exc))

    # IndiaMART also shows many supplier catalogs on seller-owned domains that
    # are still generated by IndiaMART/InterMESH. Verify those pages before using
    # them, so searches like "gas leak" do not show 0 just because the supplier
    # list is outside the strict indiamart.com hostname.
    strict_visible_count = len(rows) + len(discovered)
    if strict_visible_count == 0 or (mode == 'deep' and strict_visible_count < 18):
        try:
            managed_rows, managed_errors, managed_methods, managed_storefront_hosts = _discover_indiamart_managed_storefronts(
                query, mode, requested_limit
            )
            if managed_rows:
                managed_storefront_used = True
                rows.extend(managed_rows)
            errors.extend(managed_errors)
            methods.extend(managed_methods)
        except Exception as exc:
            errors.append('Managed storefront fallback: ' + str(exc))

    # Fetch exact details only for a bounded top subset. Remaining discovered URLs
    # still become usable hint rows immediately instead of holding the whole search.
    if discovered:
        methods.append('IndiaMART product-page discovery')
        detail_cap = min(int(profile["detail_fetch"]), len(discovered), requested_limit)
        detail_rows = discovered[:detail_cap]
        if detail_rows:
            with ThreadPoolExecutor(max_workers=min(10 if mode != "deep" else 14, len(detail_rows))) as pool:
                futures = [
                    (url, title, snippet, pool.submit(_indiamart_detail, url, title, snippet, 5.5 if mode != "deep" else 6.8))
                    for url, title, snippet in detail_rows
                ]
                for url, title, snippet, future in futures:
                    try:
                        rows.append(future.result())
                    except Exception:
                        fallback = _search_hint_record(url, title, snippet)
                        if fallback:
                            rows.append(fallback)
        for url, title, snippet in discovered[detail_cap:requested_limit]:
            fallback = _search_hint_record(url, title, snippet)
            if fallback:
                rows.append(fallback)

    # If IndiaMART temporarily blocks/rate-limits this refresh, keep the last
    # successful result set available instead of showing an empty table.
    if not rows and stale_cached and stale_cached[1]:
        rows = [dict(r) for r in stale_cached[1]]
        used_stale_cache = True
        methods.append('Recent IndiaMART cache fallback')
        errors.append('Live IndiaMART refresh was temporarily restricted; recent cached results were used.')

    by_key = OrderedDict()
    for row in rows:
        if not row or not _clean_text(row.get('product_name')):
            continue
        dkey = _indiamart_offer_dedupe_key(row)
        if dkey in by_key:
            by_key[dkey] = _indiamart_merge_item(by_key[dkey], row)
        else:
            by_key[dkey] = dict(row)

    # Keep final enrichment modest because detail fetching above already covered
    # the strongest candidates. This improves first-response time.
    final_enrich = 0
    rows = _enrich_indiamart_rows(list(by_key.values()), max_fetch=final_enrich)
    rows.sort(key=lambda r: _indiamart_relevance(r, query), reverse=True)
    rows = _dedupe_indiamart_products(rows)[:requested_limit]
    rows, translated_fields = _translate_rows_to_english(rows)
    # A second pass catches the rare case where the same listing appeared once
    # in a local language and once in English without a stable URL.
    rows = _dedupe_indiamart_products(rows)[:requested_limit]
    for row in rows:
        if not row.get('supplier_location'):
            row['supplier_location'] = _clean_text(row.get('location') or '')
        row['search_text'] = _product_search_text(row)
        if not row.get('contact'):
            row['contact_status'] = 'view_on_indiamart'

    unique_suppliers = {_clean_text(r.get('supplier')).lower() for r in rows if _clean_text(r.get('supplier'))}
    info = {
        "ok": bool(rows),
        "searched": True,
        "source": "IndiaMART",
        "query": query,
        "count": len(rows),
        "dedupeRule": "same company + same price",
        "searchUrl": INDIAMART_SEARCH_URL.format(query=encoded),
        "methods": list(dict.fromkeys(methods)),
        "searchApisConfigured": api_names,
        "searchApisUsed": [x for x in list(dict.fromkeys(discovery_methods)) if x in api_names],
        "freeScrapeApi": bool(free_only),
        "requiresApiKey": False if free_only else bool(api_names),
        "scrapeArchitecture": "Keyless local API: IndiaMART public HTML + public web-index/browser fallback" if free_only else "Automatic provider/direct discovery",
        "searchMode": mode,
        "searchModeLabel": profile["label"],
        "keywordQueries": query_variants,
        "advertisedProductCount": advertised_count_hint,
        "relatedCategoryPages": len(related_urls),
        "typedCategoryPages": len(seed_category_urls),
        "directRequestCount": len(request_jobs),
        "directEmbeddedLinks": len(_dedupe_discovered_links(direct_discovered, requested_limit)),
        "discoveredLinks": len(discovered),
        "zeroResultRecovery": "typed category sweep + embedded links + browser renderer + verified IndiaMART-managed storefronts",
        "browserFallbackUsed": browser_fallback_used,
        "browserFallbackAvailable": bool(_find_local_chromium_browser()),
        "managedStorefrontFallbackUsed": managed_storefront_used,
        "managedStorefrontHosts": managed_storefront_hosts,
        "build": APP_BUILD,
        "exactImages": sum(1 for r in rows if r.get('image_link')),
        "supplierCount": len(unique_suppliers),
        "phoneCount": sum(1 for r in rows if r.get('contact')),
        "supplierContacts": sum(1 for r in rows if r.get('contact')),
        "translatedFields": translated_fields,
        "fullSearchComplete": not bool(errors),
        "complete": not bool(errors),
        "partial": bool(errors) and bool(rows),
        "dataStatus": "saved" if used_stale_cache else ("live" if rows else "unavailable"),
        "sourceErrors": errors[-8:],
        "returnedUniqueOffers": len(rows),
        "resultLimit": requested_limit,
    }
    if errors and not rows:
        info["error"] = errors[-1]
    elif errors:
        info["warning"] = errors[-1]

    # Cache successful live searches. Empty searches are deliberately not cached:
    # IndiaMART/search providers can transiently throttle one request and the next
    # click should be allowed to recover immediately.
    if rows:
        with _indiamart_lock:
            _indiamart_cache[key] = (time.time(), list(rows), dict(info))
            _indiamart_cache.move_to_end(key)
            while len(_indiamart_cache) > INDIAMART_CACHE_MAX:
                _indiamart_cache.popitem(last=False)
    return rows, info


def search_indiamart_singleflight(query, limit=INDIAMART_MAX_RESULTS, mode="standard", free_only=False):
    """Share one expensive live IndiaMART search across duplicate browser requests.

    A user can press Search twice or change/re-submit the same query while the first
    Deep request is still running. Previously both server threads performed the
    complete network discovery independently. Waiters now reuse the first result.
    """
    clean_query = _clean_text(query)
    clean_mode = _normalize_search_mode(mode)
    key = ("free|" if free_only else "auto|") + clean_mode + "|" + clean_query.lower() + "|" + str(max(1, min(int(limit or INDIAMART_MAX_RESULTS), INDIAMART_MAX_RESULTS)))
    with _indiamart_singleflight_lock:
        state = _indiamart_singleflight.get(key)
        if state is None:
            state = {"event": threading.Event(), "result": None, "error": None}
            _indiamart_singleflight[key] = state
            owner = True
        else:
            owner = False
    if not owner:
        # Deep searches can legitimately take time on a cold cache. Wait for the
        # active identical request instead of launching another 20+ page crawl.
        if state["event"].wait(timeout=150):
            if state.get("error") is not None:
                raise state["error"]
            result = state.get("result")
            if result is not None:
                rows, info = result
                info = dict(info)
                info["sharedInflight"] = True
                return list(rows), info
        # If an owner was interrupted, the normal cache/search path can recover.
        return (search_indiamart_free_fast(clean_query, limit=limit, mode=clean_mode)
                if free_only else search_indiamart(clean_query, limit=limit, mode=clean_mode, free_only=False))
    search_token = None
    try:
        search_token = _office_search_enter(clean_query, clean_mode)
        result = (search_indiamart_free_fast(clean_query, limit=limit, mode=clean_mode)
                  if free_only else search_indiamart(clean_query, limit=limit, mode=clean_mode, free_only=False))
        state["result"] = (list(result[0]), dict(result[1]))
        return result
    except Exception as exc:
        state["error"] = exc
        raise
    finally:
        if search_token:
            _office_search_leave(search_token)
        state["event"].set()
        with _indiamart_singleflight_lock:
            if _indiamart_singleflight.get(key) is state:
                _indiamart_singleflight.pop(key, None)

def _sheet_request(url, timeout=45):
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    })
    with urlopen(req, timeout=timeout) as response:
        final_url = response.geturl()
        content_type = response.headers.get("Content-Type", "")
        body = response.read().decode("utf-8", errors="replace")
        return response.status, final_url, content_type, body


def _discover_sheet_tabs(sheet_id):
    tabs = {}
    for url in (
        f"https://docs.google.com/spreadsheets/d/{sheet_id}/htmlview",
        f"https://docs.google.com/spreadsheets/d/{sheet_id}/edit?usp=sharing",
    ):
        try:
            status, final_url, content_type, page = _sheet_request(url, 40)
            low = page[:7000].lower()
            if status != 200 or "accounts.google.com" in final_url.lower() or "request access" in low or "you need access" in low:
                continue
            for m in re.finditer(r'href=["\\\']([^"\\\']*gid(?:=|%3D)(\\d+)[^"\\\']*)["\\\'][^>]*>(.*?)</a>', page, flags=re.I | re.S):
                gid = m.group(2)
                name = re.sub(r"<[^>]+>", " ", html_lib.unescape(m.group(3)))
                name = _clean_text(html_lib.unescape(name)) or f"Sheet {gid}"
                if len(name) <= 120:
                    tabs.setdefault(gid, name)
            patterns = [
                (r'"title"\\s*:\\s*"([^"]{1,120})".{0,700}?"sheetId"\\s*:\\s*(\\d+)', 0),
                (r'"sheetId"\\s*:\\s*(\\d+).{0,700}?"title"\\s*:\\s*"([^"]{1,120})"', 1),
            ]
            for pattern, reverse in patterns:
                for m in re.finditer(pattern, page, flags=re.I | re.S):
                    if reverse:
                        gid, name = m.group(1), m.group(2)
                    else:
                        name, gid = m.group(1), m.group(2)
                    try:
                        name = bytes(name, "utf-8").decode("unicode_escape", errors="ignore")
                    except Exception:
                        pass
                    name = _clean_text(name)
                    if name:
                        tabs[gid] = name
            for gid in re.findall(r'gid(?:\\u003d|=|%3D)(\\d+)', page, flags=re.I):
                tabs.setdefault(gid, f"Sheet {gid}")
            if tabs:
                break
        except Exception:
            continue
    if "0" not in tabs:
        tabs.setdefault("0", "First sheet")
    return [{"gid": gid, "name": name} for gid, name in tabs.items()]


def _fetch_sheet_csv(sheet_id, gid):
    endpoints = [
        f"https://docs.google.com/spreadsheets/d/{sheet_id}/export?format=csv&gid={quote(str(gid))}",
        f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq?tqx=out%3Acsv&gid={quote(str(gid))}",
    ]
    errors = []
    for url in endpoints:
        try:
            status, final_url, content_type, body = _sheet_request(url, 45)
            low = body[:7000].lower()
            if status != 200:
                errors.append(f"HTTP {status}")
                continue
            if "accounts.google.com" in final_url.lower() or "request access" in low or "you need access" in low:
                errors.append("Google Sheet needs access/sign-in")
                continue
            if "text/html" in content_type.lower() and "<html" in body[:500].lower():
                errors.append("HTML returned instead of CSV")
                continue
            rows = list(csv.reader(io.StringIO(body)))
            if rows:
                return rows
            errors.append("empty CSV")
        except Exception as exc:
            errors.append(str(exc))
    raise RuntimeError("; ".join(errors[-2:]) or "Could not read Google Sheet tab")




def _fetch_sheet_csv_full(sheet_id, gid, chunk_size=20000, max_rows=500000):
    """Read a complete Google Sheet tab, including very large tabs.

    Google's normal CSV export is fast and is used first.  For large sheets we
    also use the Visualization endpoint in chunks and keep whichever result is
    larger.  This prevents a partial/truncated export from silently reducing a
    100k+ product register to only a few hundred rows.
    """
    base_rows = _fetch_sheet_csv(sheet_id, gid)
    best_rows = base_rows

    collected = []
    header = None
    offset = 0
    safety = 0
    while offset < max_rows:
        tq = quote(f"limit {int(chunk_size)} offset {int(offset)}")
        url = (
            f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq"
            f"?tqx=out%3Acsv&gid={quote(str(gid))}&tq={tq}"
        )
        try:
            status, final_url, content_type, body = _sheet_request(url, 60)
            low = body[:7000].lower()
            if status != 200:
                break
            if "accounts.google.com" in final_url.lower() or "request access" in low or "you need access" in low:
                break
            if "text/html" in content_type.lower() and "<html" in body[:500].lower():
                break
            rows = list(csv.reader(io.StringIO(body)))
            if not rows:
                break
        except Exception:
            break

        if header is None:
            header = rows[0]
            collected.extend(rows)
            data_count = max(0, len(rows) - 1)
        else:
            # gviz normally repeats the header for each query window.
            if rows and [_norm_header(x) for x in rows[0]] == [_norm_header(x) for x in header]:
                payload = rows[1:]
            else:
                payload = rows
            collected.extend(payload)
            data_count = len(payload)

        if data_count < chunk_size:
            break
        offset += chunk_size
        safety += 1
        if safety > 30:
            break

    if len(collected) > len(best_rows):
        best_rows = collected
    return best_rows

def _header_index(rows):
    best_idx = None
    best_score = -1
    for idx, row in enumerate(rows[:40]):
        normalized = [_norm_header(v) for v in row]
        if not any(v in PRICE_ALIASES["product_name"] for v in normalized):
            continue
        hits = sum(1 for v in normalized if v in PRICE_ALL_HEADERS)
        if hits >= 2 and hits > best_score:
            best_idx, best_score = idx, hits
    return best_idx


def _first_col(headers, aliases):
    normalized = [_norm_header(v) for v in headers]
    for alias in aliases:
        try:
            return normalized.index(alias)
        except ValueError:
            pass
    return None


def _row_cell(row, idx):
    if idx is None or idx < 0 or idx >= len(row):
        return ""
    return _clean_text(row[idx])


def _normalize_image_link(value):
    """Extract a browser-fetchable image URL from common Excel/Sheets cells."""
    value = _clean_text(value)
    if not value:
        return ""

    # Excel/Google Sheets formulas such as =IMAGE("https://...") and
    # =HYPERLINK("https://...","IMAGE") are sometimes preserved in cache files.
    formula_url = re.search(r'https?://[^"\'\s,)]+', value, flags=re.I)
    if formula_url:
        value = formula_url.group(0)
    elif value.lower().startswith(('http%3a', 'https%3a')):
        try:
            value = unquote(value)
        except Exception:
            pass
    if value.startswith('//'):
        value = 'https:' + value

    # Google Drive public/share/image variants -> a stable browser image URL.
    # Also accepts a raw Drive file ID commonly stored directly in Excel cells.
    drive_patterns = (
        r'drive\.google\.com/file/d/([A-Za-z0-9_-]+)',
        r'drive\.google\.com/(?:open|uc|thumbnail)\?[^#]*?(?:id|file_id)=([A-Za-z0-9_-]+)',
        r'drive\.usercontent\.google\.com/download\?[^#]*?id=([A-Za-z0-9_-]+)',
        r'docs\.google\.com/(?:uc|file/d)/[^#]*?([A-Za-z0-9_-]{20,})',
        r'lh3\.googleusercontent\.com/d/([A-Za-z0-9_-]+)',
    )
    for pattern in drive_patterns:
        m = re.search(pattern, value, flags=re.I)
        if m:
            return "https://lh3.googleusercontent.com/d/" + m.group(1)
    if re.fullmatch(r'[A-Za-z0-9_-]{20,}', value):
        return "https://lh3.googleusercontent.com/d/" + value

    # Dropbox share links need raw download mode to return image bytes.
    if 'dropbox.com/' in value.lower():
        value = re.sub(r'([?&])dl=0(?:&|$)', r'\1dl=1&', value)
        value = value.rstrip('&?')
        if '?' not in value:
            value += '?dl=1'
        elif 'dl=' not in value.lower():
            value += '&dl=1'
    return value


def _products_from_rows(rows, sheet_name):
    header_idx = _header_index(rows)
    if header_idx is None:
        return []
    mapping = {field: _first_col(rows[header_idx], aliases) for field, aliases in PRICE_ALIASES.items()}
    if mapping["product_name"] is None:
        return []
    products = []
    for source_row, row in enumerate(rows[header_idx + 1:], start=header_idx + 2):
        product_name = _row_cell(row, mapping["product_name"])
        if not product_name:
            continue
        p = {field: _row_cell(row, mapping[field]) for field in PRICE_ALIASES}
        p["product_name"] = product_name
        p["image_link"] = _normalize_image_link(p.get("image_link", ""))
        # Some registers keep the Drive/photo formula in a differently named
        # column.  If the mapped Photo/Image column is empty, scan the original
        # row for an explicit image/Drive URL instead of falling back to a web
        # image that may not match the Sheet.
        if not p["image_link"]:
            headers = rows[header_idx]
            product_link_col = mapping.get("product_link")
            for col_idx, raw_cell in enumerate(row):
                if product_link_col is not None and col_idx == product_link_col:
                    continue
                raw_text = _clean_text(raw_cell)
                low = raw_text.lower()
                if not raw_text:
                    continue
                header = _norm_header(headers[col_idx]) if col_idx < len(headers) else ''
                image_header = any(word in header for word in ('image', 'photo', 'picture', 'pic', 'thumbnail'))
                explicit_image = '=image(' in low or bool(re.search(r'https?://[^ ]+\.(?:jpe?g|png|webp|gif)(?:[?#]|$)', raw_text, flags=re.I))
                drive_image = image_header and ('drive.google.com/' in low or 'googleusercontent.com/' in low)
                if explicit_image or drive_image:
                    candidate = _normalize_image_link(raw_text)
                    if candidate:
                        p["image_link"] = candidate
                        break
        p["source_sheet"] = sheet_name
        p["source_row"] = source_row
        p["source_type"] = "google_sheet"
        p["search_text"] = _product_search_text(p)
        products.append(p)
    return products


def refresh_price_index(force=False):
    now = time.time()
    with _price_lock:
        if _price_cache["loading"]:
            return
        if not force and _price_cache["products"] and now - _price_cache["loaded_at"] < PRICE_REFRESH_SECONDS:
            return
        _price_cache["loading"] = True

    try:
        # 1) Prime memory from the already-synced/local cache only when memory
        #    is empty. Re-reading a 100k+ row JSON file on every refresh wastes
        #    CPU and disk I/O. On startup, a valid local cache is enough to make
        #    the UI ready immediately; the live Sheet refresh happens later.
        with _price_lock:
            current_count = len(_price_cache.get("products") or [])
        if not current_count:
            cached_products, cached_sheets, cache_path = _load_v108_full_cache()
            if cached_products:
                cached_products.sort(key=_display_sort_key)
                cache_loaded_at = time.time()
                with _price_lock:
                    _price_cache.update({
                        "products": cached_products,
                        "loaded_at": cache_loaded_at,
                        "error": "",
                        "sheets": cached_sheets,
                        "cache_path": cache_path,
                    })
                _clear_price_search_cache()
                _build_price_keyword_index_async(cached_products, cache_loaded_at)
                print(f"[PRICE INDEX] Active full cache: {len(cached_products)} products.")
                if not force:
                    return

        # 2) Refresh from Google Sheet.  Never downgrade a larger full cache to
        #    a smaller partial export such as the 637-row result seen before.
        tabs = _discover_sheet_tabs(PRICE_SHEET_ID)
        products = []
        loaded_sheets = []
        for tab in tabs:
            try:
                rows = _fetch_sheet_csv_full(PRICE_SHEET_ID, tab["gid"])
                parsed = _products_from_rows(rows, tab["name"])
                if parsed:
                    products.extend(parsed)
                    loaded_sheets.append(tab["name"])
            except Exception as exc:
                print(f"[PRICE INDEX] Skipped {tab['name']}: {exc}")

        # stable row-level dedupe only; do not collapse legitimate repeated
        # product names/models from different source rows.
        deduped=[]
        seen=set()
        for p in products:
            key=(
                _clean_text(p.get("source_sheet")).lower(),
                str(p.get("source_row") or ""),
                _clean_text(p.get("product_name")).lower(),
                _clean_text(p.get("model")).lower(),
            )
            if key in seen:
                continue
            seen.add(key); deduped.append(p)
        products=deduped
        # Preserve all genuine Sheet price rows.  Only the impossible duplicate
        # of the exact same source-sheet/source-row record above is removed.
        # This keeps the complete Excel/Drive price list searchable and visible.
        products.sort(key=_display_sort_key)

        with _price_lock:
            active_count=len(_price_cache.get("products") or [])
            if products and len(products) >= active_count:
                live_loaded_at = time.time()
                _price_cache.update({
                    "products": products,
                    "loaded_at": live_loaded_at,
                    "error": "",
                    "sheets": loaded_sheets,
                    "cache_path": "google-sheet-live",
                })
                _clear_price_search_cache()
                _build_price_keyword_index_async(products, live_loaded_at)
                print(f"[PRICE INDEX] Loaded {len(products)} products from {len(loaded_sheets)} sheet tab(s).")
                # Save outside the normal browser request path. The next launch
                # can then render the Price stage from disk before Google responds.
                threading.Thread(
                    target=_persist_price_cache,
                    args=(products, loaded_sheets),
                    name="nunes-price-cache-save",
                    daemon=True,
                ).start()
            elif products:
                print(f"[PRICE INDEX] Ignored smaller partial refresh ({len(products)}) because active index has {active_count} products.")
            elif not active_count:
                raise RuntimeError("No price products could be loaded from cache or Google Sheet")
    except Exception as exc:
        with _price_lock:
            if not _price_cache.get("products"):
                _price_cache["error"] = str(exc)
        print(f"[PRICE INDEX] Refresh failed: {exc}")
    finally:
        with _price_lock:
            _price_cache["loading"] = False

def _price_refresh_worker():
    # Load the persisted full register immediately. Then refresh the live Sheet
    # shortly afterwards in the background, rather than making the browser wait
    # or leaving a fast-start cache stale for the whole refresh interval.
    try:
        refresh_price_index(force=False)
    except Exception as exc:
        print(f"[PRICE INDEX] Fast-start load failed: {exc}")
    time.sleep(2.0)
    while True:
        try:
            refresh_price_index(force=True)
        except Exception as exc:
            print(f"[PRICE INDEX] Background refresh failed: {exc}")
        time.sleep(PRICE_REFRESH_SECONDS)


def start_price_index_worker():
    threading.Thread(target=_price_refresh_worker, name="nunes-price-index", daemon=True).start()


def _tokens(value):
    return [x for x in re.findall(r"[a-z0-9]+", _clean_text(value).lower()) if len(x) > 1]


def _build_price_keyword_index(products, loaded_at):
    global _price_keyword_index, _price_keyword_index_loaded_at, _price_keyword_index_building
    try:
        local = {}
        for idx, product in enumerate(products or []):
            # Keep the index compact: product/model/category/supplier are the fields
            # users normally search. Full text/spec search remains a safe fallback.
            text = " ".join(_clean_text(product.get(k)) for k in ("product_name", "model", "category", "supplier"))
            for token in set(_tokens(text)):
                if len(token) > 48:
                    continue
                local.setdefault(token, []).append(idx)
        frozen = {token: tuple(ids) for token, ids in local.items()}
        with _price_keyword_lock:
            _price_keyword_index = frozen
            _price_keyword_index_loaded_at = float(loaded_at or 0)
        print(f"[PRICE INDEX] Keyword search index ready: {len(frozen)} terms for {len(products or [])} products.")
    except Exception as exc:
        print(f"[PRICE INDEX] Keyword index build skipped: {exc}")
    finally:
        with _price_keyword_lock:
            _price_keyword_index_building = False


def _build_price_keyword_index_async(products, loaded_at):
    global _price_keyword_index_building
    with _price_keyword_lock:
        if _price_keyword_index_building:
            return
        if _price_keyword_index and float(_price_keyword_index_loaded_at or 0) == float(loaded_at or 0):
            return
        _price_keyword_index_building = True
    threading.Thread(
        target=_build_price_keyword_index,
        args=(products, loaded_at),
        name="nunes-price-keyword-index",
        daemon=True,
    ).start()


def _price_keyword_candidate_rows(products, query, loaded_at):
    groups = _query_word_groups(query)
    if not groups:
        return products
    with _price_keyword_lock:
        ready = bool(_price_keyword_index) and float(_price_keyword_index_loaded_at or 0) == float(loaded_at or 0)
        index = _price_keyword_index if ready else None
    if not index:
        _build_price_keyword_index_async(products, loaded_at)
        return products
    ids = set()
    for group in groups:
        for token in group:
            ids.update(index.get(token, ()))
    # A very generic one-word query can legitimately touch most rows; in that
    # case the original scan is no slower and preserves every legacy match.
    if not ids or len(ids) > max(50000, int(len(products) * 0.72)):
        return products
    return [products[i] for i in ids if 0 <= i < len(products)]


def _ensure_price_refresh_async():
    """Start at most one on-demand price refresh without blocking search."""
    global _price_async_thread
    with _price_async_lock:
        if _price_async_thread is not None and _price_async_thread.is_alive():
            return
        with _price_lock:
            if _price_cache.get("loading"):
                return
        _price_async_thread = threading.Thread(
            target=refresh_price_index,
            kwargs={"force": True},
            name="nunes-price-index-on-demand",
            daemon=True,
        )
        _price_async_thread.start()


PRICE_DISPLAY_FIELDS = (
    "image_link", "product_name", "model", "supplier",
    "purchase_price", "price_date", "category", "contact",
)


def _display_completeness(product):
    """Return (complete, filled-count) for the eight visible price-list fields."""
    filled = sum(1 for field in PRICE_DISPLAY_FIELDS if _clean_text(product.get(field)))
    return (filled == len(PRICE_DISPLAY_FIELDS), filled)


def _display_sort_key(product):
    complete, filled = _display_completeness(product)
    return (
        -int(complete), -filled, -_price_row_quality(product),
        _clean_text(product.get("product_name")).lower(),
        _clean_text(product.get("model")).lower(),
    )


def _compact_search_text(value):
    return re.sub(r"[^a-z0-9]+", "", _clean_text(value).lower())


def _score_price_products(query):
    query = _clean_text(query).lower()
    query_compact = _compact_search_text(query)
    groups = _query_word_groups(query)
    qtokens = [g[0] for g in groups]
    with _price_lock:
        products = _price_cache["products"]
        state = {
            "loaded_at": _price_cache["loaded_at"],
            "loading": _price_cache["loading"],
            "error": _price_cache["error"],
            "sheets": list(_price_cache["sheets"]),
        }
    if not products and not state["loading"]:
        _ensure_price_refresh_async()
        state["loading"] = True

    if not query:
        return products, state

    cached = _cached_price_search(query, state["loaded_at"])
    if cached is not None:
        return cached, state

    candidates = _price_keyword_candidate_rows(products, query, state["loaded_at"])
    scored = []
    append = scored.append
    group_count = len(groups)
    query_words = _query_words(query)
    core_positions = [i for i, token in enumerate(query_words) if token not in SEARCH_QUERY_MODIFIERS and token not in SEARCH_QUERY_GENERIC]
    if not core_positions:
        core_positions = list(range(group_count))
    core_count = len(core_positions)
    # Match a useful majority of the actual instrument/action words, not every
    # material/adjective. Example: "Stainless Steel Pipe Cutting Machine" can
    # still find "Pipe Cutter" while exact stainless-steel rows rank above it.
    min_core_groups = 1 if core_count <= 1 else max(2, (core_count + 1) // 2)

    for p in candidates:
        hay = p.get("search_text", "") or _product_search_text(p)
        name = _clean_text(p.get("product_name")).lower()
        model = _clean_text(p.get("model")).lower()
        name_compact = _compact_search_text(name)
        model_compact = _compact_search_text(model)
        compact_match = bool(query_compact) and (query_compact in name_compact or query_compact in model_compact)

        matched_groups = 0
        matched_core_groups = 0
        alias_hits = 0
        name_hits = 0
        model_hits = 0
        for group_index, group in enumerate(groups):
            hit = False
            for pos, token in enumerate(group):
                if token and token in hay:
                    hit = True
                    if pos > 0:
                        alias_hits += 1
                    if token in name:
                        name_hits += 1
                    if model and token in model:
                        model_hits += 1
                    break
            if hit:
                matched_groups += 1
                if group_index in core_positions:
                    matched_core_groups += 1

        exact_phrase = bool(query and query in hay)
        all_words = group_count > 0 and matched_groups == group_count
        modelish = [t for t in qtokens if any(c.isdigit() for c in t)]
        model_match = any(t in model for t in modelish) if modelish and model else False
        if not (exact_phrase or compact_match or all_words or model_match or matched_core_groups >= min_core_groups):
            continue

        score = matched_groups * 95 + name_hits * 45 + model_hits * 70 - alias_hits * 12
        if query == name or (model and query == model): score += 1000
        if query_compact and model_compact and query_compact == model_compact: score += 1150
        if query_compact and name_compact and query_compact == name_compact: score += 1050
        if name.startswith(query): score += 600
        if query in name: score += 450
        if model and query in model: score += 550
        if compact_match: score += 500
        if exact_phrase: score += 380
        if all_words: score += 260

        # Reward useful adjacent phrase fragments such as "pipe cutting machine".
        words = _query_words(query)
        for width, bonus in ((4, 100), (3, 80), (2, 45)):
            if len(words) >= width:
                for i in range(0, len(words) - width + 1):
                    phrase = " ".join(words[i:i + width])
                    if phrase in hay:
                        score += bonus
                        break

        tier, _tier_label, _confidence = _model_match_tier(query, p)
        complete, filled = _display_completeness(p)
        append((tier, 1 if complete else 0, filled, score, p))

    scored.sort(key=lambda x: (-x[0], -x[1], -x[2], -x[3], x[4].get("product_name", "").lower(), x[4].get("model", "").lower()))
    rows = [p for _, _, _, _, p in scored]
    _remember_price_search(query, state["loaded_at"], rows)
    return rows, state


def _excel_name_rows(query):
    """Excel/Drive-only search preserving every matching source price row."""
    # The old implementation collapsed repeated product/model rows to a single
    # representative.  The price register is a price list/history, so every
    # genuine matching source row must remain available.
    return _score_price_products(query)

def search_price_products_page(query, drive_results=None, offset=0, limit=500, excel_names=False):
    rows, state = _excel_name_rows(query) if excel_names else _score_price_products(query)
    total = len(rows)
    offset = max(0, int(offset or 0))
    limit = max(50, min(1000, int(limit or 240)))
    page = rows[offset:offset + limit]
    page, _translated_fields = _translate_rows_to_english(page)

    drive_results = drive_results or []
    output = []
    for p in page:
        item = dict(p)
        tier, tier_label, confidence = _model_match_tier(query, item)
        item["match_tier"] = tier_label
        item["match_confidence"] = confidence
        ptoks = set(_tokens(item.get("product_name", "") + " " + item.get("model", "")))
        matches = []
        for d in drive_results:
            dtext = " ".join(str(d.get(k, "")) for k in ("product", "name", "category", "path", "folder", "driveFolder")).lower()
            overlap = sum(1 for tok in ptoks if tok in dtext)
            model = _clean_text(item.get("model")).lower()
            if (model and model in dtext) or overlap >= max(1, min(2, len(ptoks))):
                matches.append(d)
        item["catalog_files"] = matches[:12]
        output.append(item)

    return output, state, total, offset, limit


def search_price_products(query, drive_results=None, limit=500):
    """Compatibility wrapper for existing callers."""
    page, state, _total, _offset, _limit = search_price_products_page(
        query, drive_results=drive_results, offset=0, limit=limit
    )
    return page, state


_image_lookup_lock = threading.RLock()
_image_lookup_cache = OrderedDict()
_image_cache_save_timer = None
_image_singleflight_lock = threading.RLock()
_image_singleflight = {}
IMAGE_LOOKUP_CACHE_MAX = 1200
IMAGE_LOOKUP_POSITIVE_TTL = 86400
IMAGE_LOOKUP_NEGATIVE_TTL = 1800
IMAGE_LOOKUP_CACHE_PATH = RUNTIME_CACHE_DIR / "product_images.json"


def _load_persistent_image_cache():
    """Restore valid image lookups from local disk so restart does not repeat web searches."""
    try:
        if not IMAGE_LOOKUP_CACHE_PATH.exists():
            seed = PACKAGE_CACHE_DIR / "product_images.json"
            if seed.is_file():
                try:
                    IMAGE_LOOKUP_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(seed, IMAGE_LOOKUP_CACHE_PATH)
                except Exception:
                    pass
        if not IMAGE_LOOKUP_CACHE_PATH.is_file():
            return
        payload = json.loads(IMAGE_LOOKUP_CACHE_PATH.read_text(encoding="utf-8"))
        items = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(items, dict):
            return
        now = time.time()
        restored = []
        for key, entry in items.items():
            if not isinstance(entry, dict):
                continue
            expires_at = float(entry.get("expires_at") or 0)
            if expires_at <= now:
                continue
            value = str(entry.get("url") or "")
            restored.append((str(key), (expires_at, value)))
        restored = restored[-IMAGE_LOOKUP_CACHE_MAX:]
        with _image_lookup_lock:
            _image_lookup_cache.clear()
            _image_lookup_cache.update(restored)
        if restored:
            print(f"[IMAGE CACHE] Restored {len(restored)} persistent image lookups")
    except Exception as exc:
        print(f"[IMAGE CACHE] Persistent cache read skipped: {exc}")


def _persist_image_lookup_cache():
    """Atomically persist the current image lookup cache without blocking normal requests."""
    global _image_cache_save_timer
    try:
        now = time.time()
        with _image_lookup_lock:
            valid = [
                (key, expires_at, value)
                for key, (expires_at, value) in _image_lookup_cache.items()
                if expires_at > now
            ][-IMAGE_LOOKUP_CACHE_MAX:]
            _image_cache_save_timer = None
        if not valid and not IMAGE_LOOKUP_CACHE_PATH.exists():
            return
        IMAGE_LOOKUP_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "saved_at": now,
            "items": {
                key: {"expires_at": expires_at, "url": value}
                for key, expires_at, value in valid
            },
        }
        tmp = IMAGE_LOOKUP_CACHE_PATH.with_suffix(IMAGE_LOOKUP_CACHE_PATH.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, IMAGE_LOOKUP_CACHE_PATH)
    except Exception as exc:
        with _image_lookup_lock:
            _image_cache_save_timer = None
        print(f"[IMAGE CACHE] Persistent cache save skipped: {exc}")


def _schedule_image_cache_save():
    """Coalesce bursts of image results into one small disk write."""
    global _image_cache_save_timer
    with _image_lookup_lock:
        if _image_cache_save_timer is not None and _image_cache_save_timer.is_alive():
            return
        timer = threading.Timer(1.0, _persist_image_lookup_cache)
        timer.daemon = True
        _image_cache_save_timer = timer
        timer.start()


def _bing_image_search_candidates(query, timeout=9):
    """Return image URLs from Bing HTML without accepting them as valid yet."""
    from urllib.parse import quote_plus
    if not _clean_text(query):
        return []
    try:
        url = "https://www.bing.com/images/search?q=" + quote_plus(query)
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36",
            "Accept-Language": "en-IN,en;q=0.9",
        })
        with urlopen(req, timeout=timeout) as response:
            page = response.read(3 * 1024 * 1024).decode("utf-8", errors="replace")
        candidates = []
        for pattern in (r'\"murl\":\"(.*?)\"', r'\"turl\":\"(.*?)\"'):
            for match in re.finditer(pattern, page):
                value = match.group(1).replace('\\/', '/').replace('\\u0026', '&')
                value = value.replace('\\u003d', '=').replace('\\u002f', '/')
                if value.startswith(('http://', 'https://')):
                    candidates.append(value)
        candidates = list(dict.fromkeys(candidates))
        candidates.sort(key=lambda u: 0 if any(u.lower().split('?')[0].endswith(ext) for ext in ('.jpg','.jpeg','.png','.webp')) else 1)
        return candidates[:30]
    except Exception:
        return []



def _serper_image_search_candidates(query, timeout=SEARCH_API_TIMEOUT):
    if not SERPER_API_KEY or not _clean_text(query):
        return []
    try:
        data = _api_post_json(
            "https://google.serper.dev/images",
            {"q": _clean_text(query), "gl": "in", "hl": "en", "num": 24},
            {"X-API-KEY": SERPER_API_KEY},
            timeout=timeout,
        )
        candidates = []
        for item in data.get("images") or []:
            value = _normalize_image_link(item.get("imageUrl") or item.get("image") or item.get("thumbnailUrl"))
            if value:
                candidates.append(value)
        return list(dict.fromkeys(candidates))[:24]
    except Exception:
        return []


def _search_image_candidates(query, mode="standard"):
    mode = _normalize_search_mode(mode)
    profile = _search_mode_profile(mode)
    # Minimum never spends a paid API credit just to fill a thumbnail. Standard
    # and Deep use Serper Images first and keep the existing Bing HTML fallback.
    if profile.get("paid_images") and SERPER_API_KEY:
        rows = _serper_image_search_candidates(query)
        if rows:
            return rows
    return _bing_image_search_candidates(query, timeout=7 if mode != "deep" else 9)

def _is_indiamart_cdn_image(url):
    try:
        host = (urlparse(str(url or '')).hostname or '').lower()
        return host == 'imimg.com' or host.endswith('.imimg.com')
    except Exception:
        return False


def _live_image_from_bing(product, model="", supplier="", product_link="", image_link="", mode="standard"):
    """Find a usable product image while protecting IndiaMART result accuracy.

    Sheet rows keep the existing general image-search fallback.  IndiaMART rows
    are stricter: use the listing's supplied image, its exact product-page image,
    or an IndiaMART CDN (imimg.com) result only.  This avoids showing an unrelated
    generic web image beside an IndiaMART supplier row.
    """
    mode = _normalize_search_mode(mode)
    product = _clean_text(product)
    model = _clean_text(model)
    supplier = _clean_text(supplier)
    product_link = _clean_text(product_link)
    image_link = _normalize_image_link(image_link)
    queries = []
    for parts in ((product, model, supplier), (product, model), (product,)):
        q = _clean_text(" ".join(x for x in parts if x))
        if q and q.lower() not in {x.lower() for x in queries}:
            queries.append(q)
    if not queries:
        return None

    try:
        host = (urlparse(product_link).hostname or '').lower()
        is_indiamart = host == 'indiamart.com' or host.endswith('.indiamart.com')
    except Exception:
        is_indiamart = False

    key = (mode + " | " + " | ".join(queries) + " | " + image_link + " | " + product_link + (" | im-only" if is_indiamart else "")).lower()
    now = time.time()
    with _image_lookup_lock:
        cached = _image_lookup_cache.get(key)
        if cached and cached[0] > now:
            _image_lookup_cache.move_to_end(key)
            return cached[1] or None
        if cached:
            _image_lookup_cache.pop(key, None)
            _schedule_image_cache_save()

    found = None

    # 1) A row-supplied image is the strongest source.  For IndiaMART rows,
    # require the IndiaMART CDN unless the URL came directly from the exact page.
    if image_link:
        try:
            if (not is_indiamart) or _is_indiamart_cdn_image(image_link):
                _fetch_remote_image(image_link)
                found = _normalize_image_link(image_link)
        except Exception:
            found = None

    # 2) Exact product page OpenGraph/Twitter image.
    if not found and product_link:
        for candidate in _page_image_candidates(product_link):
            try:
                if is_indiamart and not _is_indiamart_cdn_image(candidate):
                    continue
                _fetch_remote_image(candidate)
                found = candidate
                break
            except Exception:
                continue

    # 3) IndiaMART-specific fallback: search only the IndiaMART image CDN using
    # product + model + supplier. This is intentionally used before any generic
    # image search and is the final fallback for IndiaMART rows.
    if not found and is_indiamart:
        for query in queries:
            for candidate in _search_image_candidates(query + ' site:imimg.com', mode):
                if not _is_indiamart_cdn_image(candidate):
                    continue
                try:
                    _fetch_remote_image(candidate)
                    found = candidate
                    break
                except Exception:
                    continue
            if found:
                break

    # 4) Existing general fallback applies only to Google Sheet/local rows.
    if not found and not is_indiamart:
        for query in queries:
            for candidate in _search_image_candidates(query, mode):
                try:
                    _fetch_remote_image(candidate)
                    found = candidate
                    break
                except Exception:
                    continue
            if found:
                break

    ttl = IMAGE_LOOKUP_POSITIVE_TTL if found else IMAGE_LOOKUP_NEGATIVE_TTL
    with _image_lookup_lock:
        _image_lookup_cache[key] = (now + ttl, found or "")
        _image_lookup_cache.move_to_end(key)
        while len(_image_lookup_cache) > IMAGE_LOOKUP_CACHE_MAX:
            _image_lookup_cache.popitem(last=False)
    _schedule_image_cache_save()
    return found


def _live_image_singleflight(product, model="", supplier="", product_link="", image_link="", mode="standard"):
    """Prevent duplicate visible rows from launching the same web image lookup together."""
    key = "|".join(_clean_text(x).lower() for x in (mode, product, model, supplier, product_link, image_link))
    with _image_singleflight_lock:
        state = _image_singleflight.get(key)
        if state is None:
            state = {"event": threading.Event(), "result": None}
            _image_singleflight[key] = state
            owner = True
        else:
            owner = False
    if not owner:
        if state["event"].wait(timeout=18):
            return state.get("result") or None
        return _live_image_from_bing(product, model, supplier, product_link, image_link, mode)
    try:
        result = _live_image_from_bing(product, model, supplier, product_link, image_link, mode)
        state["result"] = result or ""
        return result
    finally:
        state["event"].set()
        with _image_singleflight_lock:
            if _image_singleflight.get(key) is state:
                _image_singleflight.pop(key, None)


_load_persistent_image_cache()
atexit.register(_persist_image_lookup_cache)

# Same-origin product image proxy. Many supplier/CDN/Drive images reject direct
# browser hot-linking; fetching them through the local app makes card rendering
# substantially more reliable while keeping the original price-sheet URL intact.
_remote_image_lock = threading.RLock()
_remote_image_cache = OrderedDict()
_remote_image_negative_cache = OrderedDict()
REMOTE_IMAGE_CACHE_MAX = 800
REMOTE_IMAGE_CACHE_TTL = 6 * 60 * 60
REMOTE_IMAGE_NEGATIVE_CACHE_MAX = 1600
REMOTE_IMAGE_NEGATIVE_CACHE_TTL = 20 * 60
REMOTE_IMAGE_MAX_BYTES = 12 * 1024 * 1024
# F15.1: persistent server-side image byte cache. Client PCs now reuse images
# from the main PriceMaster PC across browser sessions instead of re-downloading
# the same supplier/CDN image every time. No extra image/Pillow dependency.
REMOTE_IMAGE_DISK_DIR = RUNTIME_CACHE_DIR / "image_bytes"
REMOTE_IMAGE_DISK_TTL = 3 * 24 * 60 * 60
REMOTE_IMAGE_DISK_MAX_FILES = 1200
try:
    REMOTE_IMAGE_DISK_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

def _remote_image_disk_paths(url):
    key = hashlib.sha256(url.encode("utf-8", errors="ignore")).hexdigest()
    return REMOTE_IMAGE_DISK_DIR / (key + ".bin"), REMOTE_IMAGE_DISK_DIR / (key + ".mime")

def _load_remote_image_disk(url):
    try:
        data_path, mime_path = _remote_image_disk_paths(url)
        if not data_path.is_file() or not mime_path.is_file():
            return None
        if time.time() - data_path.stat().st_mtime > REMOTE_IMAGE_DISK_TTL:
            return None
        data = data_path.read_bytes()
        if not data or len(data) > REMOTE_IMAGE_MAX_BYTES:
            return None
        mime = mime_path.read_text(encoding="utf-8").strip()
        if not mime.startswith("image/"):
            return None
        return data, mime
    except Exception:
        return None

def _save_remote_image_disk(url, data, mime):
    try:
        REMOTE_IMAGE_DISK_DIR.mkdir(parents=True, exist_ok=True)
        data_path, mime_path = _remote_image_disk_paths(url)
        tmp = data_path.with_suffix(".tmp")
        tmp.write_bytes(data)
        os.replace(tmp, data_path)
        mime_path.write_text(mime, encoding="utf-8")
        # Bounded cleanup only when the directory grows past the configured cap.
        files = sorted(REMOTE_IMAGE_DISK_DIR.glob("*.bin"), key=lambda x: x.stat().st_mtime, reverse=True)
        for old in files[REMOTE_IMAGE_DISK_MAX_FILES:]:
            try:
                old.unlink()
                old.with_suffix(".mime").unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


def _safe_public_remote_url(value):
    value = _clean_text(value)
    if not value:
        return ''
    parsed = urlparse(value)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return ''
    host = parsed.hostname.strip().lower()
    if host in ('localhost',) or host.endswith('.local'):
        return ''
    try:
        # Block literal private/loopback IPs immediately.
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved:
            return ''
    except ValueError:
        pass
    return value


def _detect_image_mime(data, header=''):
    h = str(header or '').split(';', 1)[0].strip().lower()
    if data.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    if data.startswith(b'\xff\xd8\xff'):
        return 'image/jpeg'
    if data.startswith((b'GIF87a', b'GIF89a')):
        return 'image/gif'
    if len(data) >= 12 and data[:4] == b'RIFF' and data[8:12] == b'WEBP':
        return 'image/webp'
    if data.lstrip().startswith(b'<svg') or b'<svg' in data[:500].lower():
        return 'image/svg+xml'
    return h if h.startswith('image/') else ''


def _image_url_variants(value):
    """Return safe candidate URLs for tricky hosted images (especially Drive)."""
    raw = _normalize_image_link(value)
    if not raw:
        return []
    out = [raw]
    m = re.search(r'googleusercontent\.com/d/([A-Za-z0-9_-]+)', raw, flags=re.I)
    if not m:
        m = re.search(r'drive\.google\.com/(?:file/d/|(?:open|uc|thumbnail)\?[^#]*?id=)([A-Za-z0-9_-]+)', raw, flags=re.I)
    if m:
        fid = m.group(1)
        out.extend([
            f'https://drive.google.com/thumbnail?id={fid}&sz=w1600',
            f'https://lh3.googleusercontent.com/d/{fid}=w1600',
            f'https://drive.google.com/uc?export=view&id={fid}',
            f'https://drive.usercontent.google.com/download?id={fid}&export=view&confirm=t',
        ])

    # Bing/Sheet data occasionally contains an Amazon CDN image URL with its
    # final image extension removed (for example ..._AC_UF1000).  Trying the
    # normal .jpg form once repairs many of those rows without any extra search.
    try:
        parsed_raw = urlparse(raw)
        host_raw = (parsed_raw.hostname or '').lower()
        path_raw = parsed_raw.path or ''
        if (
            ('media-amazon.com' in host_raw or 'ssl-images-amazon.com' in host_raw)
            and '/images/' in path_raw
            and not re.search(r'\.(?:jpe?g|png|webp|gif|avif)(?:$|[?#])', raw, flags=re.I)
        ):
            out.append(raw + '.jpg')
    except Exception:
        pass

    unique=[]
    seen=set()
    for u in out:
        u=_safe_public_remote_url(u)
        if u and u not in seen:
            seen.add(u); unique.append(u)
    return unique


def _page_image_candidates(product_link):
    """Read a product page and return OpenGraph/Twitter image candidates."""
    url = _safe_public_remote_url(product_link)
    if not url:
        return []
    try:
        req = Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/151 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        with urlopen(req, timeout=5.5) as response:
            final = _safe_public_remote_url(response.geturl()) or url
            ctype = str(response.headers.get('Content-Type','')).lower()
            if 'html' not in ctype and 'text/' not in ctype:
                return []
            page = response.read(2 * 1024 * 1024).decode('utf-8', errors='replace')
        found=[]
        patterns=(
            r'<meta[^>]+(?:property|name)=["\'](?:og:image|twitter:image(?::src)?)["\'][^>]+content=["\']([^"\']+)',
            r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:og:image|twitter:image(?::src)?)["\']',
            r'<link[^>]+rel=["\']image_src["\'][^>]+href=["\']([^"\']+)',
        )
        for pat in patterns:
            for m in re.finditer(pat, page, flags=re.I):
                candidate=html_lib.unescape(m.group(1)).strip()
                if candidate:
                    found.append(urljoin(final,candidate))
        return list(dict.fromkeys(found))[:10]
    except Exception:
        return []


def _fetch_remote_image(value):
    candidates = _image_url_variants(value)
    if not candidates:
        raise ValueError('Invalid image URL')
    last_error = None
    now = time.time()

    for url in candidates:
        disk_cached = _load_remote_image_disk(url)
        if disk_cached:
            data, mime = disk_cached
            with _remote_image_lock:
                _remote_image_cache[url] = (now + REMOTE_IMAGE_CACHE_TTL, data, mime)
                _remote_image_cache.move_to_end(url)
            return data, mime
        with _remote_image_lock:
            cached = _remote_image_cache.get(url)
            if cached and cached[0] > now:
                _remote_image_cache.move_to_end(url)
                return cached[1], cached[2]
            if cached:
                _remote_image_cache.pop(url, None)

            failed = _remote_image_negative_cache.get(url)
            if failed and failed[0] > now:
                _remote_image_negative_cache.move_to_end(url)
                last_error = ValueError(failed[1] or 'Remote image unavailable')
                continue
            if failed:
                _remote_image_negative_cache.pop(url, None)

        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        origin = f'{parsed.scheme}://{parsed.netloc}/'

        # Different CDNs block different hot-link patterns. Keep this bounded:
        # two lightweight browser-like attempts for normal hosts, plus the
        # IndiaMART referer profile for imimg.com.
        header_profiles = [
            {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36',
                'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                'Referer': origin,
                'Accept-Language': 'en-IN,en;q=0.9',
            },
            {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36',
                'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
                'Accept-Language': 'en-IN,en;q=0.9',
            },
        ]
        if host == 'imimg.com' or host.endswith('.imimg.com'):
            header_profiles.insert(0, {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36',
                'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
                'Referer': 'https://dir.indiamart.com/',
                'Accept-Language': 'en-IN,en;q=0.9',
            })

        url_error = None
        for headers in header_profiles:
            try:
                req = Request(url, headers=headers)
                with urlopen(req, timeout=4.5) as response:
                    final_url = _safe_public_remote_url(response.geturl())
                    if not final_url:
                        raise ValueError('Unsafe image redirect')
                    data = response.read(REMOTE_IMAGE_MAX_BYTES + 1)
                    if len(data) > REMOTE_IMAGE_MAX_BYTES:
                        raise ValueError('Image is too large')
                    mime = _detect_image_mime(data, response.headers.get('Content-Type', ''))
                if not mime or len(data) < 32:
                    raise ValueError('Remote URL did not return an image')

                with _remote_image_lock:
                    _remote_image_cache[url] = (now + REMOTE_IMAGE_CACHE_TTL, data, mime)
                    _remote_image_cache.move_to_end(url)
                    _remote_image_negative_cache.pop(url, None)
                    while len(_remote_image_cache) > REMOTE_IMAGE_CACHE_MAX:
                        _remote_image_cache.popitem(last=False)
                _save_remote_image_disk(url, data, mime)
                return data, mime
            except Exception as exc:
                url_error = exc
                last_error = exc

        # Do not repeatedly spend network time on the same dead/truncated image.
        # The browser can still request it again after this short negative TTL.
        with _remote_image_lock:
            _remote_image_negative_cache[url] = (
                now + REMOTE_IMAGE_NEGATIVE_CACHE_TTL,
                str(url_error or 'Remote image unavailable')[:300],
            )
            _remote_image_negative_cache.move_to_end(url)
            while len(_remote_image_negative_cache) > REMOTE_IMAGE_NEGATIVE_CACHE_MAX:
                _remote_image_negative_cache.popitem(last=False)

    raise ValueError(str(last_error or 'Remote URL did not return an image'))

# -----------------------------------------------------------------------------
# Hidden Google Lens visual supplier matching
# -----------------------------------------------------------------------------
# This is intentionally a backend-only extension to FIND PRODUCTS.  The normal
# Sheet + IndiaMART search renders first; visual matches arrive asynchronously
# and are merged into the same product table without adding a separate Lens UI.
VISUAL_SEARCH_CACHE_SECONDS = 6 * 60 * 60
VISUAL_SEARCH_NEGATIVE_CACHE_SECONDS = 10 * 60
VISUAL_SEARCH_CACHE_MAX = 80
VISUAL_SEARCH_MAX_RESULTS = 24
VISUAL_SEARCH_MAX_CANDIDATES = 36
VISUAL_SEARCH_FETCH_WORKERS = 8
VISUAL_SEARCH_CACHE_PATH = RUNTIME_CACHE_DIR / "visual_matches.json"
_visual_search_lock = threading.RLock()
_visual_search_cache = OrderedDict()
_visual_search_save_timer = None


def _visual_cache_key(query, image_url):
    raw = (_clean_text(query).lower() + "\n" + _clean_text(image_url)).encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()


def _load_visual_search_cache():
    try:
        if not VISUAL_SEARCH_CACHE_PATH.exists():
            seed = PACKAGE_CACHE_DIR / "visual_matches.json"
            if seed.is_file():
                try:
                    VISUAL_SEARCH_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(seed, VISUAL_SEARCH_CACHE_PATH)
                except Exception:
                    pass
        if not VISUAL_SEARCH_CACHE_PATH.is_file():
            return
        payload = json.loads(VISUAL_SEARCH_CACHE_PATH.read_text(encoding="utf-8"))
        items = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(items, dict):
            return
        now = time.time()
        restored = []
        for key, entry in items.items():
            if not isinstance(entry, dict):
                continue
            expires_at = float(entry.get("expires_at") or 0)
            data = entry.get("data")
            if expires_at > now and isinstance(data, dict):
                restored.append((str(key), (expires_at, data)))
        restored = restored[-VISUAL_SEARCH_CACHE_MAX:]
        with _visual_search_lock:
            _visual_search_cache.clear()
            _visual_search_cache.update(restored)
        if restored:
            print(f"[VISUAL MATCH] Restored {len(restored)} cached searches")
    except Exception as exc:
        print(f"[VISUAL MATCH] Cache read skipped: {exc}")


def _persist_visual_search_cache():
    global _visual_search_save_timer
    try:
        now = time.time()
        with _visual_search_lock:
            valid = [
                (key, expires_at, data)
                for key, (expires_at, data) in _visual_search_cache.items()
                if expires_at > now and isinstance(data, dict)
            ][-VISUAL_SEARCH_CACHE_MAX:]
            _visual_search_save_timer = None
        VISUAL_SEARCH_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "saved_at": now,
            "items": {
                key: {"expires_at": expires_at, "data": data}
                for key, expires_at, data in valid
            },
        }
        tmp = VISUAL_SEARCH_CACHE_PATH.with_suffix(VISUAL_SEARCH_CACHE_PATH.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, VISUAL_SEARCH_CACHE_PATH)
    except Exception as exc:
        with _visual_search_lock:
            _visual_search_save_timer = None
        print(f"[VISUAL MATCH] Cache save skipped: {exc}")


def _schedule_visual_cache_save():
    global _visual_search_save_timer
    with _visual_search_lock:
        if _visual_search_save_timer is not None and _visual_search_save_timer.is_alive():
            return
        timer = threading.Timer(1.0, _persist_visual_search_cache)
        timer.daemon = True
        _visual_search_save_timer = timer
        timer.start()


def _visual_decode_url_token(value):
    value = html_lib.unescape(str(value or "").strip())
    value = value.replace("\\/", "/").replace("\\u0026", "&").replace("\\u003d", "=")
    value = value.replace("\\u003a", ":").replace("\\u002f", "/")
    try:
        value = unquote(value)
    except Exception:
        pass
    return value


def _visual_external_url(value, base_url=""):
    """Resolve Lens/search redirect URLs to a safe external product-page URL."""
    value = _visual_decode_url_token(value)
    if not value:
        return ""
    absolute = urljoin(base_url, value)
    try:
        parsed = urlparse(absolute)
        host = (parsed.hostname or "").lower()
        qs = parse_qs(parsed.query)
        if host.endswith("google.com") or ".google." in host or host.startswith("google."):
            for key in ("url", "q", "adurl", "imgrefurl", "source", "u"):
                target = (qs.get(key) or [""])[0]
                if str(target).startswith(("http://", "https://")):
                    absolute = _visual_decode_url_token(target)
                    parsed = urlparse(absolute)
                    host = (parsed.hostname or "").lower()
                    break
        if parsed.scheme not in ("http", "https") or not host:
            return ""
        blocked = (
            "google.", "gstatic.com", "googleusercontent.com", "youtube.com", "youtu.be",
            "facebook.com", "instagram.com", "pinterest.", "tiktok.com", "x.com", "twitter.com",
        )
        if any(token in host for token in blocked):
            return ""
        path = (parsed.path or "").lower()
        if any(path.endswith(ext) for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg", ".pdf")):
            return ""
        return _safe_public_remote_url(absolute)
    except Exception:
        return ""


def _lens_candidate_links(page, base_url):
    """Extract external result pages from the Google Lens response HTML/JSON."""
    raw = []
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)', page or "", flags=re.I):
        raw.append(m.group(1))
    for pattern in (
        r'"(?:url|link|targetUrl|pageUrl)"\s*:\s*"(https?:\\?/\\?/[^"<>]+)"',
        r'(https?:\\?/\\?/[^"\'<>\s]{12,})',
    ):
        for m in re.finditer(pattern, page or "", flags=re.I):
            raw.append(m.group(1))

    out = []
    seen = set()
    domain_counts = {}
    for token in raw:
        url = _visual_external_url(token, base_url)
        if not url:
            continue
        try:
            host = (urlparse(url).hostname or "").lower()
        except Exception:
            continue
        if not host or url in seen:
            continue
        # Keep result diversity and avoid spending the whole request on one marketplace.
        count = domain_counts.get(host, 0)
        if count >= 4:
            continue
        domain_counts[host] = count + 1
        seen.add(url)
        out.append(url)
        if len(out) >= VISUAL_SEARCH_MAX_CANDIDATES:
            break
    return out


def _request_google_lens(image_url, timeout=12):
    """Submit a public image URL to Google Lens and return its response page."""
    image_url = _safe_public_remote_url(image_url)
    if not image_url:
        raise ValueError("Visual matching needs a public product image URL")
    lens_url = "https://lens.google.com/uploadbyurl?" + urlencode({
        "url": image_url,
        "hl": "en-IN",
        "re": "df",
    })
    req = Request(lens_url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
        "Referer": "https://lens.google.com/",
    })
    with urlopen(req, timeout=timeout) as response:
        final_url = response.geturl()
        page = response.read(5 * 1024 * 1024).decode("utf-8", errors="replace")
    low = (final_url + " " + page[:12000]).lower()
    verification = any(x in low for x in (
        "our systems have detected unusual traffic", "recaptcha", "sorry/index", "verify you are human",
        "before you continue to google", "consent.google.com",
    ))
    return final_url, page, verification


def _request_google_lens_bytes(image_data, image_mime="image/jpeg", timeout=12):
    """Upload local image bytes to Lens using several lightweight endpoint variants.

    Google occasionally blocks one undocumented upload shape with HTTP 403 while
    another still works. Keep this best-effort and short; callers have a local OCR
    fallback, so Lens can never block PriceMaster's normal search.
    """
    if not isinstance(image_data, (bytes, bytearray)) or not image_data:
        raise ValueError("Image search needs image data")
    if len(image_data) > 8 * 1024 * 1024:
        raise ValueError("Image is too large. Maximum is 8 MB")
    image_mime = _detect_image_mime(bytes(image_data), image_mime)
    if image_mime not in {"image/jpeg", "image/png", "image/webp", "image/gif"}:
        raise ValueError("Unsupported image format. Use JPG, PNG, WEBP or GIF")

    boundary = "----PriceMasterLens" + uuid.uuid4().hex
    filename = "image.png" if image_mime == "image/png" else "image.webp" if image_mime == "image/webp" else "image.gif" if image_mime == "image/gif" else "image.jpg"
    body = bytearray()
    body.extend((f"--{boundary}\r\nContent-Disposition: form-data; name=\"encoded_image\"; filename=\"{filename}\"\r\nContent-Type: {image_mime}\r\n\r\n").encode("utf-8"))
    body.extend(image_data)
    body.extend((f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"sbisrc\"\r\n\r\nGoogle Chrome\r\n").encode("utf-8"))
    body.extend(f"--{boundary}--\r\n".encode("utf-8"))

    stamp = str(int(time.time() * 1000))
    attempts = [
        ("https://lens.google.com/v3/upload?" + urlencode({"ep":"gsbubb","st":stamp,"authuser":"0","hl":"en-IN"}),
         'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36'),
        ("https://lens.google.com/v3/upload?" + urlencode({"stcs":stamp,"hl":"en-IN"}),
         'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/152 Mobile Safari/537.36'),
        ("https://lens.google.com/v3/upload?" + urlencode({"ep":"ccm","st":stamp,"hl":"en-IN"}),
         'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36'),
    ]
    last_error = None
    per_try = max(4.0, min(7.0, float(timeout or 12) / 2.0))
    for endpoint, ua in attempts:
        jar = http.cookiejar.CookieJar()
        opener = build_opener(HTTPCookieProcessor(jar))
        req = Request(endpoint, data=bytes(body), headers={
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-IN,en;q=0.9",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "Referer": "https://lens.google.com/",
        }, method="POST")
        try:
            with opener.open(req, timeout=per_try) as response:
                final_url = response.geturl()
                page = response.read(5 * 1024 * 1024).decode("utf-8", errors="replace")
            if final_url and final_url != endpoint and len(_lens_candidate_links(page, final_url)) < 2:
                try:
                    follow = Request(final_url, headers={
                        "User-Agent": ua,
                        "Accept": "text/html,application/xhtml+xml",
                        "Accept-Language": "en-IN,en;q=0.9",
                        "Referer": "https://www.google.com/",
                    })
                    with opener.open(follow, timeout=per_try) as response:
                        final_url = response.geturl()
                        page = response.read(5 * 1024 * 1024).decode("utf-8", errors="replace")
                except Exception:
                    pass
            low = (str(final_url or "") + " " + page[:12000]).lower()
            verification = any(x in low for x in (
                "our systems have detected unusual traffic", "recaptcha", "sorry/index", "verify you are human",
                "before you continue to google", "consent.google.com",
            ))
            if verification:
                last_error = RuntimeError('Google Lens verification required')
                continue
            return final_url, page, False
        except Exception as exc:
            last_error = exc
            continue
    raise RuntimeError(str(last_error or 'Google Lens upload unavailable'))


def _visual_json_ld_products(obj, output):
    if isinstance(obj, dict):
        typ = obj.get("@type")
        types = [str(x).lower() for x in typ] if isinstance(typ, list) else [str(typ or "").lower()]
        if any("product" in t for t in types):
            output.append(obj)
        for value in obj.values():
            if isinstance(value, (dict, list)):
                _visual_json_ld_products(value, output)
    elif isinstance(obj, list):
        for value in obj:
            _visual_json_ld_products(value, output)


def _visual_ld_product(page):
    products = []
    for m in re.finditer(r'<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', page or "", flags=re.I | re.S):
        raw = html_lib.unescape(m.group(1)).strip()
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except Exception:
            continue
        _visual_json_ld_products(payload, products)
    return products[0] if products else {}


def _visual_named_value(value):
    if isinstance(value, dict):
        return _clean_text(value.get("name") or value.get("legalName") or value.get("value"))
    if isinstance(value, list):
        for item in value:
            result = _visual_named_value(item)
            if result:
                return result
        return ""
    return _clean_text(value)


def _visual_offer(value):
    if isinstance(value, list):
        return next((x for x in value if isinstance(x, dict)), {})
    return value if isinstance(value, dict) else {}


def _visual_price_text(price, currency=""):
    price = _clean_text(price)
    currency = _clean_text(currency).upper()
    if not price:
        return ""
    if currency == "INR":
        return "₹ " + price.replace("₹", "").strip()
    if currency:
        return f"{currency} {price}"
    return price


def _fetch_visual_html(url, timeout=9):
    url = _safe_public_remote_url(url)
    if not url:
        raise ValueError("Unsafe visual result URL")
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
    })
    with urlopen(req, timeout=timeout) as response:
        final_url = _safe_public_remote_url(response.geturl()) or url
        ctype = str(response.headers.get("Content-Type", "")).lower()
        if "html" not in ctype and "text/" not in ctype:
            raise ValueError("Visual result is not an HTML product page")
        page = response.read(2 * 1024 * 1024).decode("utf-8", errors="replace")
    return final_url, page


def _visual_page_record(url, query=""):
    """Map a Lens-discovered product/supplier page into the existing PriceMaster row schema."""
    final_url, page = _fetch_visual_html(url)
    ld = _visual_ld_product(page)
    offer = _visual_offer(ld.get("offers")) if isinstance(ld, dict) else {}

    title = _visual_named_value(ld.get("name")) if ld else ""
    if not title:
        title = _meta_content(page, ("og:title", "twitter:title"))
    if not title:
        title = _first_regex(page, (r'<h1\b[^>]*>(.*?)</h1>', r'<title\b[^>]*>(.*?)</title>'))
    title = _html_to_text(title)[:240]
    if not title:
        raise ValueError("No product title")

    supplier = _visual_named_value(offer.get("seller")) if offer else ""
    if ld and not supplier:
        for field in ("seller", "manufacturer", "brand"):
            supplier = _visual_named_value(ld.get(field))
            if supplier:
                break
    if not supplier:
        supplier = _meta_content(page, ("og:site_name", "application-name"))
    if not supplier:
        try:
            host = (urlparse(final_url).hostname or "").lower().removeprefix("www.")
            supplier = host.split(".")[0].replace("-", " ").title()
        except Exception:
            supplier = ""

    image = ""
    if ld:
        raw_image = ld.get("image")
        if isinstance(raw_image, list):
            raw_image = raw_image[0] if raw_image else ""
        if isinstance(raw_image, dict):
            raw_image = raw_image.get("url") or raw_image.get("contentUrl") or ""
        image = _normalize_image_link(raw_image)
    if not image:
        image = _normalize_image_link(_meta_content(page, ("og:image", "twitter:image", "twitter:image:src")))
    if image:
        image = urljoin(final_url, image)

    price = ""
    currency = ""
    if offer:
        price = offer.get("price") or offer.get("lowPrice") or offer.get("highPrice") or ""
        currency = offer.get("priceCurrency") or ""
    if not price:
        price = _meta_content(page, ("product:price:amount", "og:price:amount"))
        currency = currency or _meta_content(page, ("product:price:currency", "og:price:currency"))
    if not price:
        price = _first_regex(page, (
            r'((?:₹|Rs\.?|INR)\s*[\d,]+(?:\.\d+)?)',
            r'((?:USD|EUR|GBP|AED)\s*[\d,]+(?:\.\d+)?)',
        ))
    price = _visual_price_text(price, currency) if price else ""

    model = ""
    if ld:
        for field in ("model", "mpn", "sku", "productID"):
            model = _visual_named_value(ld.get(field))
            if model:
                break
    if not model:
        model = _first_regex(page, (
            r'["\'](?:model|modelNo|modelNumber|mpn|sku)["\']\s*[:=]\s*["\']([^"\']{1,120})',
            r'(?i)\bModel(?:\s*(?:No\.?|Number|Code))?\s*[:#-]\s*([A-Z0-9][A-Z0-9._/-]{2,60})',
        ))

    contact = ""
    telephone = _visual_named_value(ld.get("telephone")) if ld else ""
    if not telephone and isinstance(offer.get("seller") if offer else None, dict):
        telephone = _visual_named_value(offer.get("seller", {}).get("telephone"))
    if not telephone and isinstance(ld.get("seller") if ld else None, dict):
        telephone = _visual_named_value(ld.get("seller", {}).get("telephone"))
    if not telephone:
        telephone = _first_regex(page, (
            r'href=["\']tel:([^"\']+)',
            r'["\']telephone["\']\s*:\s*["\']([^"\']+)',
        ))
    telephone = _normalise_indiamart_phone(telephone)
    if telephone:
        contact = telephone
    else:
        email = _first_regex(page, (r'href=["\']mailto:([^"\'?]+)', r'\b([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})\b'))
        contact = email[:100] if email else ""

    category = _visual_named_value(ld.get("category")) if ld else ""
    if not category:
        category = _meta_content(page, ("product:category", "article:section"))
    description = _visual_named_value(ld.get("description")) if ld else ""
    if not description:
        description = _meta_content(page, ("description", "og:description"))

    record = {
        "product_name": title,
        "model": model[:120],
        "specs": _clean_text(description)[:1600],
        "purchase_price": price[:120],
        "price_date": "",
        "supplier": _clean_text(supplier)[:180],
        "contact": _clean_text(contact)[:120],
        "category": _clean_text(category)[:160],
        "product_link": final_url,
        "image_link": image,
        "image_source": "Google Lens visual match" if image else "",
        "source_sheet": "Visual Match",
        "source_row": final_url,
        "source_type": "visual_match",
        "visual_source": "google_lens",
    }
    record["search_text"] = _product_search_text(record)
    record["visual_score"] = _visual_relevance(record, query, bool(ld))
    return record


def _visual_relevance(row, query, has_product_schema=False):
    q = re.sub(r"[^a-z0-9]+", " ", _clean_text(query).lower()).strip()
    if not q:
        return 20
    tokens = [t for t in q.split() if len(t) > 1 and t not in {"the", "and", "for", "with"}]
    title = re.sub(r"[^a-z0-9]+", " ", _clean_text(row.get("product_name")).lower()).strip()
    model = re.sub(r"[^a-z0-9]+", "", _clean_text(row.get("model")).lower())
    qcompact = re.sub(r"[^a-z0-9]+", "", q)
    score = 0
    if q and q in title:
        score += 55
    matched = sum(1 for t in tokens if t in title or t in model)
    score += matched * 12
    if tokens and matched == len(tokens):
        score += 18
    if qcompact and len(qcompact) >= 5 and qcompact in re.sub(r"[^a-z0-9]+", "", title + model):
        score += 50
    if has_product_schema:
        score += 18
    if _clean_text(row.get("purchase_price")):
        score += 8
    if _clean_text(row.get("supplier")):
        score += 5
    if _clean_text(row.get("image_link")):
        score += 5
    return score


def search_visual_matches(query, image_url, limit=VISUAL_SEARCH_MAX_RESULTS):
    """Google Lens -> external product pages -> normal PriceMaster rows.

    Failures are intentionally soft.  The caller still has Sheet and IndiaMART
    results even if Google asks for browser verification.
    """
    query = _clean_text(query)
    image_url = _safe_public_remote_url(image_url)
    if not query or not image_url:
        return [], {"ok": True, "searched": False, "source": "visual", "reason": "no_seed"}

    key = _visual_cache_key(query, image_url)
    now = time.time()
    with _visual_search_lock:
        cached = _visual_search_cache.get(key)
        if cached and cached[0] > now:
            _visual_search_cache.move_to_end(key)
            payload = dict(cached[1])
            payload["cached"] = True
            return list(payload.get("products") or []), payload
        if cached:
            _visual_search_cache.pop(key, None)

    started = time.time()
    info = {
        "ok": True,
        "searched": True,
        "source": "visual",
        "engine": "google_lens",
        "seedImage": image_url,
        "verificationRequired": False,
        "candidateCount": 0,
    }
    rows = []
    try:
        final_url, page, verification = _request_google_lens(image_url)
        info["verificationRequired"] = bool(verification)
        candidates = [] if verification else _lens_candidate_links(page, final_url)
        info["candidateCount"] = len(candidates)
        if candidates:
            with ThreadPoolExecutor(max_workers=min(VISUAL_SEARCH_FETCH_WORKERS, len(candidates))) as pool:
                futures = [pool.submit(_visual_page_record, url, query) for url in candidates]
                for future in futures:
                    try:
                        row = future.result()
                    except Exception:
                        continue
                    if row and int(row.get("visual_score") or 0) >= 24:
                        rows.append(row)
        deduped = []
        seen_links = set()
        seen_logical = set()
        for row in sorted(rows, key=lambda r: int(r.get("visual_score") or 0), reverse=True):
            link = _clean_text(row.get("product_link")).lower()
            logical = _logical_price_key(row)
            if (link and link in seen_links) or logical in seen_logical:
                continue
            if link:
                seen_links.add(link)
            seen_logical.add(logical)
            row.pop("visual_score", None)
            deduped.append(row)
            if len(deduped) >= max(1, min(int(limit or VISUAL_SEARCH_MAX_RESULTS), VISUAL_SEARCH_MAX_RESULTS)):
                break
        rows = deduped
    except Exception as exc:
        info["ok"] = False
        info["error"] = str(exc)

    info["count"] = len(rows)
    info["elapsedMs"] = int((time.time() - started) * 1000)
    info["products"] = rows
    ttl = VISUAL_SEARCH_CACHE_SECONDS if rows else VISUAL_SEARCH_NEGATIVE_CACHE_SECONDS
    with _visual_search_lock:
        _visual_search_cache[key] = (time.time() + ttl, dict(info))
        _visual_search_cache.move_to_end(key)
        while len(_visual_search_cache) > VISUAL_SEARCH_CACHE_MAX:
            _visual_search_cache.popitem(last=False)
    _schedule_visual_cache_save()
    return rows, info


def _clean_ocr_product_query(text):
    """Turn OCR output into a compact product/model search hint."""
    text = html_lib.unescape(str(text or '')).replace('\x00', ' ')
    lines = [_clean_text(x) for x in re.split(r'[\r\n]+', text) if _clean_text(x)]
    if not lines:
        return ''
    bad = {'www', 'http', 'https', 'made in', 'warning', 'caution'}
    scored = []
    for line in lines:
        low = line.lower()
        if len(line) < 2 or any(low.startswith(x) for x in bad):
            continue
        words = re.findall(r'[A-Za-z0-9][A-Za-z0-9._/+\-]*', line)
        if not words:
            continue
        modelish = sum(1 for w in words if re.search(r'[A-Za-z]', w) and re.search(r'\d', w))
        score = min(len(words), 8) * 2 + modelish * 8 + (4 if 3 <= len(words) <= 10 else 0)
        scored.append((score, line))
    if not scored:
        return ''
    scored.sort(reverse=True)
    chosen = []
    seen = set()
    for _, line in scored:
        low = line.lower()
        if low in seen:
            continue
        seen.add(low)
        chosen.append(line)
        if len(' '.join(chosen)) >= 90 or len(chosen) >= 3:
            break
    return _clean_text(' '.join(chosen))[:140]


def _windows_ocr_image_bytes(image_data, image_mime='image/jpeg', timeout=7):
    """Best-effort OCR using Windows' built-in OCR engine; no API key/install."""
    if os.name != 'nt' or not image_data:
        return ''
    script = os.path.join(BASE_DIR, 'WINDOWS_OCR_IMAGE.ps1')
    if not os.path.isfile(script):
        return ''
    ext = '.png' if image_mime == 'image/png' else '.webp' if image_mime == 'image/webp' else '.gif' if image_mime == 'image/gif' else '.jpg'
    path = ''
    try:
        fd, path = tempfile.mkstemp(prefix='pricemaster_ocr_', suffix=ext)
        with os.fdopen(fd, 'wb') as handle:
            handle.write(bytes(image_data))
        proc = subprocess.run(
            ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-ImagePath', path],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=max(3, float(timeout or 7)), check=False
        )
        raw = proc.stdout or b''
        for enc in ('utf-8-sig', 'utf-16', 'cp1252'):
            try:
                text = raw.decode(enc).strip()
                if text:
                    return text
            except Exception:
                pass
        return ''
    except Exception:
        return ''
    finally:
        if path:
            try:
                os.remove(path)
            except Exception:
                pass


def search_visual_matches_bytes(query, image_data, image_mime="image/jpeg", limit=VISUAL_SEARCH_MAX_RESULTS):
    """Pasted image -> Lens, with Windows OCR + keyword search fallback."""
    query = _clean_text(query)
    if not isinstance(image_data, (bytes, bytearray)) or not image_data:
        return [], {"ok": True, "searched": False, "source": "visual", "reason": "no_image"}

    image_hash = hashlib.sha256(bytes(image_data)).hexdigest()
    key = _visual_cache_key(query, "upload:" + image_hash)
    now = time.time()
    with _visual_search_lock:
        cached = _visual_search_cache.get(key)
        if cached and cached[0] > now:
            _visual_search_cache.move_to_end(key)
            payload = dict(cached[1])
            payload["cached"] = True
            return list(payload.get("products") or []), payload
        if cached:
            _visual_search_cache.pop(key, None)

    started = time.time()
    info = {
        "ok": True,
        "searched": True,
        "source": "visual",
        "engine": "google_lens_upload",
        "seedImageHash": image_hash[:16],
        "verificationRequired": False,
        "candidateCount": 0,
        "fallbackUsed": False,
        "identifiedQuery": "",
    }
    rows = []
    lens_error = ""
    try:
        final_url, page, verification = _request_google_lens_bytes(bytes(image_data), image_mime)
        info["verificationRequired"] = bool(verification)
        candidates = [] if verification else _lens_candidate_links(page, final_url)
        info["candidateCount"] = len(candidates)
        if candidates:
            with ThreadPoolExecutor(max_workers=min(VISUAL_SEARCH_FETCH_WORKERS, len(candidates))) as pool:
                futures = [pool.submit(_visual_page_record, url, query) for url in candidates]
                for future in futures:
                    try:
                        row = future.result()
                    except Exception:
                        continue
                    threshold = 24 if query else 18
                    if row and int(row.get("visual_score") or 0) >= threshold:
                        rows.append(row)

        deduped = []
        seen_links = set()
        seen_logical = set()
        for row in sorted(rows, key=lambda r: int(r.get("visual_score") or 0), reverse=True):
            link = _clean_text(row.get("product_link")).lower()
            logical = _logical_price_key(row)
            if (link and link in seen_links) or logical in seen_logical:
                continue
            if link:
                seen_links.add(link)
            seen_logical.add(logical)
            row.pop("visual_score", None)
            deduped.append(row)
            if len(deduped) >= max(1, min(int(limit or VISUAL_SEARCH_MAX_RESULTS), VISUAL_SEARCH_MAX_RESULTS)):
                break
        rows = deduped
    except Exception as exc:
        lens_error = str(exc)
        info["error"] = lens_error

    if rows:
        best = rows[0]
        identified = " ".join(x for x in (_clean_text(best.get("product_name")), _clean_text(best.get("model"))) if x).strip()
        info["identifiedQuery"] = identified[:240]
    else:
        # If Google returns 403/verification/no usable matches, use Windows OCR.
        # Industrial photos often contain a model number/nameplate, which is enough
        # to continue through the normal Sheet + IndiaMART + API keyword pipeline.
        fallback_query = query or _clean_ocr_product_query(_windows_ocr_image_bytes(bytes(image_data), image_mime))
        if fallback_query:
            info["ok"] = True
            info["fallbackUsed"] = True
            info["fallbackEngine"] = "windows_ocr_keyword" if not query else "typed_hint_keyword"
            info["identifiedQuery"] = fallback_query
            info["verificationRequired"] = False
            if lens_error:
                info["lensError"] = lens_error
                info.pop("error", None)
        elif lens_error:
            info["ok"] = False

    info["count"] = len(rows)
    info["elapsedMs"] = int((time.time() - started) * 1000)
    info["products"] = rows
    ttl = VISUAL_SEARCH_CACHE_SECONDS if (rows or info.get("identifiedQuery")) else VISUAL_SEARCH_NEGATIVE_CACHE_SECONDS
    with _visual_search_lock:
        _visual_search_cache[key] = (time.time() + ttl, dict(info))
        _visual_search_cache.move_to_end(key)
        while len(_visual_search_cache) > VISUAL_SEARCH_CACHE_MAX:
            _visual_search_cache.popitem(last=False)
    _schedule_visual_cache_save()
    return rows, info


_load_visual_search_cache()
atexit.register(_persist_visual_search_cache)


TIMEOUT = 120
REQUIRED_GMAIL_BACKEND_BUILD = 'V6.5_GMAIL_AUTH_2026-08-31'
# Shared only between this local server and the matching Code.gs deployment.
# It is used to HMAC-sign direct Gmail requests so knowing the public Apps Script URL alone is not enough to send mail.
GMAIL_AUTH_SECRET = '7b73fbc923306eba2e6a80415976d1b9d9825fdee4f60fa669cf4cede797dce0'
GMAIL_AUTH_MAX_AGE_SECONDS = 300

QR_FILES = {
    "location1": "location1_qr.png",
    "location2": "location2_qr.png",
    "location3": "location3_qr.png",
}

AUTO_PASTE_DELAY_MS = {
    "email": 7000,
    "whatsapp": 9000,
}


def _set_windows_clipboard_image(image_path):
    """Put a PNG/JPG on the Windows clipboard as a real image."""
    escaped = image_path.replace("'", "''")
    command = (
        "Add-Type -AssemblyName System.Windows.Forms; "
        "Add-Type -AssemblyName System.Drawing; "
        f"$img=[System.Drawing.Image]::FromFile('{escaped}'); "
        "try {[System.Windows.Forms.Clipboard]::SetImage($img)} "
        "finally {$img.Dispose()}"
    )

    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    last_error = None

    for _ in range(4):
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoProfile",
                    "-STA",
                    "-WindowStyle",
                    "Hidden",
                    "-Command",
                    command,
                ],
                capture_output=True,
                text=True,
                timeout=12,
                creationflags=creationflags,
            )
            if result.returncode == 0:
                return
            last_error = result.stderr.strip() or result.stdout.strip()
        except Exception as exc:
            last_error = str(exc)
        time.sleep(0.20)

    raise RuntimeError(last_error or "Could not place QR image on the Windows clipboard.")


def _send_ctrl_v():
    """Send Ctrl+V to the currently focused Windows application."""
    user32 = ctypes.windll.user32
    KEYEVENTF_KEYUP = 0x0002
    VK_CONTROL = 0x11
    VK_V = 0x56

    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(VK_V, 0, 0, 0)
    time.sleep(0.05)
    user32.keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)


def _auto_paste_qr_worker(location_id, channel):
    """Wait for the compose window, then paste the selected QR automatically."""
    try:
        if os.name != "nt":
            print("[AUTO QR] Windows auto-paste is only available on Windows.")
            return

        qr_name = QR_FILES.get(location_id)
        if not qr_name:
            print(f"[AUTO QR] Unknown location: {location_id}")
            return

        qr_path = os.path.join(BASE_DIR, qr_name)
        if not os.path.isfile(qr_path):
            print(f"[AUTO QR] QR file missing: {qr_path}")
            return

        delay_ms = AUTO_PASTE_DELAY_MS.get(channel, 5500)
        time.sleep(delay_ms / 1000.0)

        _set_windows_clipboard_image(qr_path)
        time.sleep(0.20)
        _send_ctrl_v()
        print(f"[AUTO QR] Pasted {location_id} QR into {channel}.")

    except Exception as exc:
        print(f"[AUTO QR] Auto-paste failed: {exc}")


def schedule_auto_qr_paste(location_id, channel):
    thread = threading.Thread(
        target=_auto_paste_qr_worker,
        args=(location_id, channel),
        daemon=True,
    )
    thread.start()


def _website_category_qr_path(category_id):
    row = WEBSITE_CATEGORY_BY_ID.get(str(category_id or "").strip().lower())
    if not row:
        return None
    path = os.path.abspath(os.path.join(BASE_DIR, str(row.get("qrFile") or "")))
    allowed_root = os.path.abspath(CATEGORY_QR_DIR) + os.sep
    if not path.startswith(allowed_root) or not os.path.isfile(path):
        return None
    return path


def _auto_paste_category_qrs_worker(category_ids, channel):
    """Paste selected website category QR images into the active WhatsApp compose window."""
    try:
        if os.name != "nt":
            return
        rows = []
        for category_id in category_ids[:60]:
            path = _website_category_qr_path(category_id)
            if path:
                rows.append((category_id, path))
        if not rows:
            return
        # Give WhatsApp Web time to open. Then paste each QR with a small gap.
        delay_ms = AUTO_PASTE_DELAY_MS.get(channel, 9000)
        time.sleep(delay_ms / 1000.0)
        for index, (category_id, path) in enumerate(rows):
            _set_windows_clipboard_image(path)
            time.sleep(0.22)
            _send_ctrl_v()
            # WhatsApp's media composer needs a moment before accepting another image.
            if index + 1 < len(rows):
                time.sleep(1.35)
        print(f"[AUTO QR] Pasted {len(rows)} website category QR image(s) into {channel}.")
    except Exception as exc:
        print(f"[AUTO QR] Category QR auto-paste failed: {exc}")


def schedule_auto_category_qrs(category_ids, channel):
    thread = threading.Thread(
        target=_auto_paste_category_qrs_worker,
        args=(list(category_ids or []), channel),
        daemon=True,
    )
    thread.start()


def _focus_email_body(provider):
    """Best-effort focus of the web email body before inserting the template."""
    if os.name != "nt":
        return

    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return

    class RECT(ctypes.Structure):
        _fields_ = [
            ("left", ctypes.c_long),
            ("top", ctypes.c_long),
            ("right", ctypes.c_long),
            ("bottom", ctypes.c_long),
        ]

    rect = RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        return

    width = max(1, rect.right - rect.left)
    height = max(1, rect.bottom - rect.top)

    # Gmail full compose and Outlook web both keep the message body in the
    # large central area. Click there, then move the caret to the beginning.
    if provider == "outlook":
        x = rect.left + int(width * 0.60)
        y = rect.top + int(height * 0.58)
    else:
        x = rect.left + int(width * 0.56)
        y = rect.top + int(height * 0.56)

    user32.SetCursorPos(x, y)
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(0.25)

    # Ctrl+Home places the template before the fallback text/link body.
    KEYEVENTF_KEYUP = 0x0002
    VK_CONTROL = 0x11
    VK_HOME = 0x24
    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(VK_HOME, 0, 0, 0)
    time.sleep(0.04)
    user32.keybd_event(VK_HOME, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
    time.sleep(0.18)


def _auto_paste_template_worker(image_path, channel, provider):
    """Paste the generated full share-template PNG into the email compose body."""
    try:
        if os.name != "nt":
            print("[AUTO TEMPLATE] Windows auto-paste is only available on Windows.")
            return

        delay_ms = AUTO_PASTE_DELAY_MS.get(channel, 7000)
        time.sleep(delay_ms / 1000.0)

        _set_windows_clipboard_image(image_path)
        time.sleep(0.25)

        if channel == "email":
            _focus_email_body(provider)

        _send_ctrl_v()
        print(f"[AUTO TEMPLATE] Pasted full template into {channel} ({provider}).")
    except Exception as exc:
        print(f"[AUTO TEMPLATE] Auto-paste failed: {exc}")
    finally:
        try:
            if image_path and os.path.isfile(image_path):
                os.remove(image_path)
        except Exception:
            pass


def schedule_auto_template_paste(image_path, channel, provider):
    thread = threading.Thread(
        target=_auto_paste_template_worker,
        args=(image_path, channel, provider),
        daemon=True,
    )
    thread.start()


def cloud_get(params):
    query = "&".join(
        f"{quote(str(k))}={quote(str(v))}"
        for k, v in params.items()
    )
    url = APPS_SCRIPT_URL
    if query:
        url += "?" + query

    req = Request(
        url,
        headers={
            "User-Agent": "NUNES-Cloud-BAT/1.0",
            "Accept": "application/json,text/plain,*/*"
        }
    )

    with urlopen(req, timeout=TIMEOUT) as response:
        body = response.read().decode("utf-8", errors="replace")
        return body


def cloud_post(action):
    url = APPS_SCRIPT_URL + "?action=" + quote(action)

    req = Request(
        url,
        method="POST",
        data=b"",
        headers={
            "User-Agent": "NUNES-Cloud-BAT/1.0",
            "Accept": "application/json,text/plain,*/*"
        }
    )

    with urlopen(req, timeout=TIMEOUT) as response:
        return response.read().decode("utf-8", errors="replace")


def _sign_gmail_payload(payload):
    """Attach a short-lived HMAC signature understood by the matching Code.gs."""
    safe = dict(payload or {})
    timestamp = str(int(time.time()))
    recipient = str(safe.get("recipient", "")).strip().lower()
    file_ids = sorted(
        str(item.get("fileId", "")).strip()
        for item in (safe.get("files") or [])
        if isinstance(item, dict) and str(item.get("fileId", "")).strip()
    )
    message = timestamp + "\n" + recipient + "\n" + ",".join(file_ids)
    signature = hmac.new(
        GMAIL_AUTH_SECRET.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    safe["_authTs"] = timestamp
    safe["_authSig"] = signature
    return safe


def cloud_post_json(action, payload):
    """POST Gmail payload as JSON; action is duplicated in URL and JSON body."""
    safe_payload = dict(payload or {})
    if str(action).lower() == "sendgmail":
        safe_payload = _sign_gmail_payload(safe_payload)
    safe_payload["action"] = action
    safe_payload["_action"] = action

    url = APPS_SCRIPT_URL + "?action=" + quote(action)
    data = json.dumps(safe_payload, separators=(",", ":")).encode("utf-8")

    req = Request(
        url,
        method="POST",
        data=data,
        headers={
            "User-Agent": "NUNES-Cloud-BAT/1.2",
            "Accept": "application/json,text/plain,*/*",
            "Content-Type": "application/json; charset=utf-8",
        },
    )

    with urlopen(req, timeout=TIMEOUT) as response:
        return response.read().decode("utf-8", errors="replace")


def _local_inline_asset(filename, mime_type):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.isfile(path):
        return None

    with open(path, "rb") as handle:
        raw = handle.read()

    return {
        "mimeType": mime_type,
        "base64": base64.b64encode(raw).decode("ascii"),
    }


def prepare_gmail_payload(payload):
    """Add trusted local location/category QR assets without trusting browser file paths."""
    safe = dict(payload or {})
    assets = {
        "location1": _local_inline_asset("location1_qr.png", "image/png"),
        "location2": _local_inline_asset("location2_qr.png", "image/png"),
        "location3": _local_inline_asset("location3_qr.png", "image/png"),
        "company": _local_inline_asset("nunes_website_instrumentation.jpg", "image/jpeg"),
    }
    locations = list(safe.get("locations") or []) if isinstance(safe.get("locations"), list) else []
    category_rows = safe.get("categories") if isinstance(safe.get("categories"), list) else []
    added = 0
    seen = set()
    for item in category_rows[:60]:
        if not isinstance(item, dict):
            continue
        cid = re.sub(r"[^a-z0-9-]+", "", str(item.get("id", "")).lower())
        row = WEBSITE_CATEGORY_BY_ID.get(cid)
        if not row or cid in seen:
            continue
        seen.add(cid)
        asset_id = "cat_" + cid
        qr_rel = str(row.get("qrFile") or "")
        asset = _local_inline_asset(qr_rel, "image/png")
        if not asset:
            continue
        assets[asset_id] = asset
        locations.append({
            "id": asset_id,
            "label": "CATEGORY • " + str(row.get("name") or "Category"),
            "url": str(row.get("url") or ""),
        })
        added += 1
    safe["locations"] = locations
    safe["assets"] = assets
    safe["categoryQrCount"] = added
    return safe


def gmail_backend_status():
    """Read the deployed backend build before attempting a direct Gmail send."""
    result = cloud_json({"action": "status"})
    if not isinstance(result, dict):
        return {"ok": False, "error": "Backend status returned an unexpected response."}
    return result


def cloud_json_payload(action, payload):
    try:
        raw = cloud_post_json(action, payload)
        data = json.loads(raw.strip())
        if isinstance(data, dict):
            error_text = str(data.get("error", "")).strip().lower()
            if "unknown post action" in error_text:
                return {
                    "ok": False,
                    "error": (
                        "The ONLINE Google Apps Script backend does not contain the direct Gmail route. "
                        "Copy the V6.5 Code.gs into the Apps Script editor and update the EXISTING Web App deployment to a NEW VERSION. "
                        "Replacing Code.gs only inside this Windows ZIP does not update Google. "
                        "Backend response: " + str(data.get("error", "Unknown POST action."))
                    ),
                    "backendBuild": data.get("backendBuild", "unknown"),
                }
            return data
        return {"ok": False, "error": "Cloud returned an unexpected response."}
    except HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        return {
            "ok": False,
            "error": f"Cloud HTTP {error.code}: {detail[:700]}",
        }
    except URLError as error:
        return {"ok": False, "error": f"Cloud connection failed: {error.reason}"}
    except Exception as error:
        return {"ok": False, "error": str(error)}


_cloud_cache_lock = threading.RLock()
_cloud_get_cache = OrderedDict()
CLOUD_GET_CACHE_MAX = 160


def _cloud_cache_ttl(params):
    action = str((params or {}).get("action") or "").lower()
    if action == "search":
        return 300
    if action == "categories":
        return 600
    if action == "status":
        return 30
    return 0


def cloud_json(params=None, post_action=None):
    params = params or {}
    cache_key = None
    ttl = 0
    if not post_action:
        ttl = _cloud_cache_ttl(params)
        if ttl:
            cache_key = tuple(sorted((str(k), str(v)) for k, v in params.items()))
            now = time.time()
            with _cloud_cache_lock:
                cached = _cloud_get_cache.get(cache_key)
                if cached and cached[0] > now:
                    _cloud_get_cache.move_to_end(cache_key)
                    return cached[1]
                if cached:
                    _cloud_get_cache.pop(cache_key, None)
    try:
        if post_action:
            raw = cloud_post(post_action)
        else:
            raw = cloud_get(params)

        raw = raw.strip()
        try:
            result = json.loads(raw)
        except json.JSONDecodeError:
            result = {
                "ok": False,
                "error":
                    "Apps Script did not return JSON. "
                    "Open the Web App URL in a browser and verify it loads."
                    + "\n\nResponse:\n" + raw[:1000]
            }

        if cache_key is not None and isinstance(result, dict) and result.get("ok"):
            with _cloud_cache_lock:
                _cloud_get_cache[cache_key] = (time.time() + ttl, result)
                _cloud_get_cache.move_to_end(cache_key)
                while len(_cloud_get_cache) > CLOUD_GET_CACHE_MAX:
                    _cloud_get_cache.popitem(last=False)
        return result

    except HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return {"ok": False, "error": f"Cloud HTTP error {exc.code}: {body[:1000]}"}
    except URLError as exc:
        return {
            "ok": False,
            "error": "Could not connect to the Google Apps Script cloud service.\n" + str(exc)
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _pdf_literal(value):
    return _pdf_safe_text(value).replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _wrap_pdf_text(value, max_chars):
    text = " ".join(_pdf_safe_text(value).split())
    if not text:
        return [""]
    words = text.split(" ")
    lines = []
    current = ""
    for word in words:
        if len(word) > max_chars:
            chunks = [word[i:i + max_chars] for i in range(0, len(word), max_chars)]
        else:
            chunks = [word]
        for chunk in chunks:
            trial = chunk if not current else current + " " + chunk
            if len(trial) <= max_chars:
                current = trial
            else:
                if current:
                    lines.append(current)
                current = chunk
    if current:
        lines.append(current)
    return lines or [""]


def _pdf_money(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "Price unavailable"
    if number != number or number in (float("inf"), float("-inf")):
        return "Price unavailable"
    return "INR {:,.2f}".format(number)


def _build_simple_pdf(page_streams):
    # Object 1 = Catalog, 2 = Pages, 3/4 = fonts. Remaining objects are page/content pairs.
    objects = [None] * (4 + 2 * len(page_streams))
    page_ids = []
    content_ids = []
    for idx in range(len(page_streams)):
        page_ids.append(5 + idx * 2)
        content_ids.append(6 + idx * 2)

    objects[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects[1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode("ascii")
    objects[2] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
    objects[3] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>"

    for idx, stream in enumerate(page_streams):
        page_obj = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
            f"/Contents {content_ids[idx]} 0 R >>"
        ).encode("ascii")
        raw = stream.encode("latin-1", errors="replace")
        content_obj = b"<< /Length " + str(len(raw)).encode("ascii") + b" >>\nstream\n" + raw + b"\nendstream"
        objects[page_ids[idx] - 1] = page_obj
        objects[content_ids[idx] - 1] = content_obj

    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for obj_id, obj in enumerate(objects, start=1):
        offsets.append(len(out))
        out.extend(f"{obj_id} 0 obj\n".encode("ascii"))
        out.extend(obj or b"<<>>")
        out.extend(b"\nendobj\n")
    xref = len(out)
    out.extend(f"xref\n0 {len(objects)+1}\n".encode("ascii"))
    out.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        out.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    out.extend(
        f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode("ascii")
    )
    return bytes(out)


def build_quotation_pdf(payload):
    payload = payload if isinstance(payload, dict) else {}
    products = payload.get("products") if isinstance(payload.get("products"), list) else []
    locations = payload.get("locations") if isinstance(payload.get("locations"), list) else []
    catalogs = payload.get("catalogs") if isinstance(payload.get("catalogs"), list) else []
    profile = _pdf_safe_text(payload.get("profile") or "INDIA")[:30]
    try:
        margin1 = float(payload.get("margin1", 0))
    except Exception:
        margin1 = 0.0
    try:
        margin2 = float(payload.get("margin2", 0))
    except Exception:
        margin2 = 0.0

    pages = []
    cmds = []
    y = 0

    def text(x, y_pos, value, size=9, bold=False, align="left"):
        val = _pdf_literal(value)
        if align == "right":
            # Approximate width for Helvetica to keep money aligned consistently.
            x_pos = x - (len(_pdf_safe_text(value)) * size * 0.50)
        else:
            x_pos = x
        cmds.append(f"BT /{'F2' if bold else 'F1'} {size} Tf 1 0 0 1 {x_pos:.1f} {y_pos:.1f} Tm ({val}) Tj ET")

    def line(x1, y1, x2, y2, width=0.5):
        cmds.append(f"{width:.2f} w {x1:.1f} {y1:.1f} m {x2:.1f} {y2:.1f} l S")

    def fill_rect(x, y_pos, w, h, gray):
        cmds.append(f"{gray:.3f} g {x:.1f} {y_pos:.1f} {w:.1f} {h:.1f} re f 0 g")

    col_x = [36, 60, 250, 330, 365, 460, 559]

    def page_header(first=False):
        nonlocal y
        fill_rect(0, 770, 595, 72, 0.10)
        cmds.append("1 g")
        text(36, 813, "NUNES INSTRUMENTS", 17, True)
        text(36, 791, "QUOTATION - CONFIRMED FINAL PRICE", 10, True)
        cmds.append("0 g")
        text(559, 813, time.strftime("%d-%m-%Y"), 8, False, "right")
        text(36, 754, f"Pricing Profile: {profile}    Margin 1: {margin1:g}%    Margin 2: {margin2:g}%", 9, True)
        text(36, 738, "Final prices below are the confirmed values carried from the Price / Margin popup.", 8)
        y = 710
        table_header()

    def table_header():
        nonlocal y
        h = 24
        fill_rect(36, y - h, 523, h, 0.92)
        for x in col_x:
            line(x, y, x, y - h)
        line(36, y, 559, y)
        line(36, y - h, 559, y - h)
        text(42, y - 16, "#", 8, True)
        text(66, y - 16, "PRODUCT", 8, True)
        text(256, y - 16, "MODEL / CODE", 8, True)
        text(336, y - 16, "QTY", 8, True)
        text(454, y - 16, "UNIT PRICE", 8, True, "right")
        text(553, y - 16, "TOTAL", 8, True, "right")
        y -= h

    def finish_page():
        nonlocal cmds
        line(36, 38, 559, 38, 0.4)
        text(36, 24, "Nunes Instruments - Generated from confirmed application pricing", 7)
        text(559, 24, f"Page {len(pages)+1}", 7, False, "right")
        pages.append("\n".join(cmds))
        cmds = []

    page_header(True)
    for index, product in enumerate(products, start=1):
        if not isinstance(product, dict):
            continue
        name_lines = _wrap_pdf_text(product.get("name") or "Unnamed product", 42)
        model_lines = _wrap_pdf_text(product.get("model") or "-", 18)
        row_lines = max(len(name_lines), len(model_lines), 1)
        row_h = max(28, 12 + row_lines * 10)
        if y - row_h < 105:
            finish_page()
            page_header(False)
        top = y
        bottom = y - row_h
        for x in col_x:
            line(x, top, x, bottom)
        line(36, bottom, 559, bottom)
        text(42, top - 17, str(index), 8)
        for li, value in enumerate(name_lines):
            text(66, top - 15 - li * 10, value, 8, li == 0)
        for li, value in enumerate(model_lines):
            text(256, top - 15 - li * 10, value, 8)
        text(336, top - 17, str(product.get("quantity") or 1), 8)
        text(454, top - 17, _pdf_money(product.get("finalUnit")), 8, True, "right")
        text(553, top - 17, _pdf_money(product.get("finalTotal")), 8, True, "right")
        y = bottom

    if y < 120:
        finish_page(); page_header(False)
    y -= 18
    line(360, y + 11, 559, y + 11, 0.8)
    text(375, y - 2, "GRAND TOTAL", 10, True)
    text(553, y - 2, _pdf_money(payload.get("grandTotal")), 11, True, "right")
    y -= 28

    if locations:
        if y < 110:
            finish_page(); page_header(False)
        text(36, y, "LOCATIONS", 9, True); y -= 15
        for loc in locations[:12]:
            if not isinstance(loc, dict):
                continue
            for part in _wrap_pdf_text(f"{loc.get('label','')}: {loc.get('url','')}", 95):
                text(42, y, part, 8); y -= 11
                if y < 70:
                    finish_page(); page_header(False)
            y -= 2

    if catalogs:
        if y < 110:
            finish_page(); page_header(False)
        text(36, y, "PRODUCT CATALOGS", 9, True); y -= 15
        for idx, cat in enumerate(catalogs[:20], start=1):
            if not isinstance(cat, dict):
                continue
            text(42, y, f"{idx}. {_pdf_safe_text(cat.get('name') or 'Catalog')}", 8, True); y -= 11
            link = cat.get("link") or ""
            if link:
                for part in _wrap_pdf_text(link, 100):
                    text(48, y, part, 7); y -= 10
            y -= 2
            if y < 65:
                finish_page(); page_header(False)

    finish_page()
    return _build_simple_pdf(pages)


def _is_allowed_client_ip(value):
    """Allow this PC, LAN clients and Tailscale clients; reject public direct hits."""
    try:
        ip = ipaddress.ip_address(str(value or "").split("%", 1)[0])
        if ip.is_loopback or ip.is_private or ip.is_link_local:
            return True
        if isinstance(ip, ipaddress.IPv4Address) and ip in TAILSCALE_NETWORK:
            return True
    except Exception:
        pass
    return False


def _lan_ipv4():
    candidates = []
    try:
        host = socket.gethostname()
        for item in socket.getaddrinfo(host, None, socket.AF_INET):
            ip = item[4][0]
            if ip.startswith("127.") or ip.startswith("169.254."):
                continue
            if ip not in candidates:
                candidates.append(ip)
    except Exception:
        pass
    # UDP connect discovers the preferred outbound interface without sending data.
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.2)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip and not ip.startswith("127.") and ip not in candidates:
            candidates.insert(0, ip)
    except Exception:
        pass
    return candidates


def _tailscale_ipv4():
    """Return this PC's Tailscale IPv4 even when tailscale.exe is not in PATH."""
    commands = [["tailscale", "ip", "-4"]]
    if os.name == "nt":
        for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramW6432")):
            if not base:
                continue
            exe = os.path.join(base, "Tailscale", "tailscale.exe")
            if os.path.exists(exe):
                commands.insert(0, [exe, "ip", "-4"])
    seen = set()
    for command in commands:
        key = tuple(command)
        if key in seen:
            continue
        seen.add(key)
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=3, creationflags=(subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0))
            for line in (result.stdout or "").splitlines():
                value = line.strip()
                try:
                    ip = ipaddress.ip_address(value)
                    if isinstance(ip, ipaddress.IPv4Address) and ip in TAILSCALE_NETWORK:
                        return value
                except Exception:
                    continue
        except Exception:
            continue
    return ""



_connectivity_lock = threading.RLock()
_connectivity_cache = {"at": 0.0, "online": None}

def _internet_status_cached():
    now = time.time()
    with _connectivity_lock:
        if now - float(_connectivity_cache.get("at") or 0) < 25 and _connectivity_cache.get("online") is not None:
            return bool(_connectivity_cache.get("online"))
    online = False
    try:
        sock = socket.create_connection(("1.1.1.1", 53), timeout=0.8)
        sock.close()
        online = True
    except Exception:
        try:
            socket.gethostbyname("www.google.com")
            online = True
        except Exception:
            online = False
    with _connectivity_lock:
        _connectivity_cache.update({"at": now, "online": online})
    return online

def _system_metrics_builtin():
    out = {"cpuPercent": None, "memoryPercent": None, "memoryAvailable": None, "memoryTotal": None}
    if os.name == "nt":
        try:
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            mem = MEMORYSTATUSEX(); mem.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem)):
                out.update({"memoryPercent": float(mem.dwMemoryLoad), "memoryAvailable": int(mem.ullAvailPhys), "memoryTotal": int(mem.ullTotalPhys)})
        except Exception:
            pass
        try:
            class FILETIME(ctypes.Structure):
                _fields_ = [("dwLowDateTime", ctypes.c_ulong), ("dwHighDateTime", ctypes.c_ulong)]
            def snap():
                idle=FILETIME(); kernel=FILETIME(); user=FILETIME()
                ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user))
                def v(ft): return (int(ft.dwHighDateTime) << 32) + int(ft.dwLowDateTime)
                return v(idle), v(kernel), v(user)
            a=snap(); time.sleep(0.06); b=snap()
            idle=b[0]-a[0]; total=(b[1]-a[1])+(b[2]-a[2])
            if total>0: out["cpuPercent"] = round(max(0.0, min(100.0, 100.0*(1.0-idle/total))), 1)
        except Exception:
            pass
    else:
        try:
            with open('/proc/meminfo','r',encoding='utf-8') as f:
                vals={}
                for line in f:
                    parts=line.split(':',1)
                    if len(parts)==2: vals[parts[0]]=int(re.findall(r'\d+',parts[1])[0])*1024 if re.findall(r'\d+',parts[1]) else 0
            total=vals.get('MemTotal',0); avail=vals.get('MemAvailable',0)
            if total: out.update({"memoryTotal":total,"memoryAvailable":avail,"memoryPercent":round((total-avail)*100/total,1)})
        except Exception:
            pass
        try:
            load1=os.getloadavg()[0]; cpus=os.cpu_count() or 1; out["cpuPercent"]=round(min(100.0,load1*100/cpus),1)
        except Exception:
            pass
    return out

def _server_access_urls():
    local_url = f"http://{LOCAL_BROWSER_HOST}:{PORT}/index.html"
    hostname = socket.gethostname().strip()
    hostname_url = f"http://{hostname}:{PORT}/index.html" if hostname else ""
    lan_urls = [f"http://{ip}:{PORT}/index.html" for ip in _lan_ipv4()]
    tailscale_ip = _tailscale_ipv4()
    tailscale_url = f"http://{tailscale_ip}:{PORT}/index.html" if tailscale_ip else ""
    return local_url, hostname_url, lan_urls, tailscale_url


def _write_client_links(local_url, hostname_url, lan_urls, tailscale_url):
    """Write current browser-only client addresses and a ready-to-share shortcut."""
    try:
        # Prefer a LAN IP for office clients because it works even when Windows
        # hostname discovery/NetBIOS is disabled. Hostname remains an easy fallback.
        preferred_client_url = (lan_urls[0] if lan_urls else (hostname_url or tailscale_url or local_url))
        lines = [
            "PRICEMASTER CLIENT LINKS",
            "========================",
            "",
            "BEST LINK FOR OTHER OFFICE COMPUTERS",
            preferred_client_url,
            "",
            "MAIN SERVER PC",
            local_url,
            "",
            "SAME WI-FI / LAN CLIENTS",
        ]
        if hostname_url:
            lines += [hostname_url + "  (easy name; use an IP below if the name does not resolve)"]
        lines += lan_urls or ["No LAN IPv4 address detected yet."]
        lines += ["", "DIFFERENT WI-FI / INTERNET (TAILSCALE)"]
        if tailscale_url:
            lines.append(tailscale_url)
        else:
            lines.append("Install/sign in to Tailscale on the server and client PCs, then restart PriceMaster.")
        lines += [
            "",
            "Clients only need a web browser. Keep this main server PC powered on, signed in, and PriceMaster running.",
            "All PriceMaster backend fetching, search, cache and data access runs on the main server PC.",
            "Do not use localhost/127.0.0.1 on a client PC.",
            "",
        ]
        Path(os.path.join(BASE_DIR, "CLIENT_LINKS.txt")).write_text("\n".join(lines), encoding="utf-8")
        Path(os.path.join(BASE_DIR, "CLIENT_URL.txt")).write_text(preferred_client_url + "\n", encoding="utf-8")
        shortcut = "[InternetShortcut]\nURL=" + preferred_client_url + "\n"
        Path(os.path.join(BASE_DIR, "PriceMaster_CLIENT.url")).write_text(shortcut, encoding="utf-8")
    except Exception as exc:
        print("[SERVER] Could not write client access files:", exc)



# V16.8.23 enhanced supplier search. Keeps the previous provider/search code as
# fallback, but adds query cleanup, India-only filtering, multi-provider parallel
# discovery, contact-page deep scan, continuation batches, pricing hints and local
# saved/history files. All contact actions remain manual in the browser.
_SUPPLIER_SAVED_FILE = RUNTIME_CACHE_DIR / "supplier_contacts_saved.json"
_SUPPLIER_HISTORY_FILE = RUNTIME_CACHE_DIR / "supplier_contact_history.json"
_SUPPLIER_V23_CACHE = {}
_SUPPLIER_V23_LOCK = threading.RLock()


def _supplier_clean_query_v23(value):
    text = _clean_text(value or "")
    text = re.sub(r'https?://[^\s"\']+', ' ', text, flags=re.I)
    text = re.sub(r'["“”]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def _supplier_provider_search_v23(provider, query, limit=40, mode="standard", scope="india"):
    mode = _normalize_search_mode(mode); india = scope != "global"
    region = "India" if india else ""
    intent = f'{query} supplier dealer distributor reseller stockist {region} contact phone email'.strip()
    if provider == "Public Web Index":
        # Existing free fallback already has resilient Bing RSS / DDG / Chromium logic.
        return _free_supplier_links(intent, limit, mode)
    if provider == "Serper" and SERPER_API_KEY:
        data = _api_post_json('https://google.serper.dev/search', {'q':intent,'gl':'in' if india else 'us','hl':'en','num':max(10,min(100,int(limit)))}, {'X-API-KEY':SERPER_API_KEY})
        return [r for r in (_generic_search_result_tuple(x.get('link'),x.get('title'),x.get('snippet')) for x in (data.get('organic') or [])) if r][:limit]
    if provider == "Exa" and EXA_API_KEY:
        typ='instant' if mode=='minimum' else ('fast' if mode=='standard' else 'deep-lite')
        data=_api_post_json('https://api.exa.ai/search',{'query':intent,'type':typ,'numResults':max(5,min(100,int(limit))),'moderation':True},{'x-api-key':EXA_API_KEY})
        return [r for r in (_generic_search_result_tuple(x.get('url'),x.get('title'),x.get('text') or x.get('summary') or '') for x in (data.get('results') or [])) if r][:limit]
    if provider == "Tavily" and TAVILY_API_KEY:
        depth='ultra-fast' if mode=='minimum' else ('basic' if mode=='standard' else 'advanced')
        payload={'query':intent,'search_depth':depth,'max_results':max(5,min(20,int(limit))),'topic':'general','include_answer':False,'include_raw_content':False,'include_images':False,'include_usage':True}
        if india: payload['country']='india'
        data=_api_post_json('https://api.tavily.com/search',payload,{'Authorization':'Bearer '+TAVILY_API_KEY})
        return [r for r in (_generic_search_result_tuple(x.get('url'),x.get('title'),x.get('content')) for x in (data.get('results') or [])) if r][:limit]
    if provider == "Firecrawl" and FIRECRAWL_API_KEY:
        payload={'query':intent,'limit':max(5,min(20,int(limit))),'sources':['web'],'safe':True,'timeout':int(SEARCH_API_TIMEOUT*1000),'highlights':True}
        if india: payload['country']='IN'
        data=_api_post_json('https://api.firecrawl.dev/v2/search',payload,{'Authorization':'Bearer '+FIRECRAWL_API_KEY}); section=data.get('data') or {}; items=section.get('web') if isinstance(section,dict) else []
        out=[]
        for x in items or []:
            sn=x.get('description') or x.get('markdown') or x.get('highlights') or ''
            if isinstance(sn,list): sn=' '.join(str(v) for v in sn[:4])
            r=_generic_search_result_tuple(x.get('url'),x.get('title'),sn)
            if r: out.append(r)
        return out[:limit]
    return []


def _supplier_query_variants_v23(query, model="", specification="", batch=0, mode="standard"):
    q=_supplier_clean_query_v23(query); model=_clean_text(model); spec=_clean_text(specification)
    base=' '.join(x for x in (q,model) if x).strip(); variants=[]
    def add(x):
        x=_clean_text(x)
        if x and x.lower() not in {v.lower() for v in variants}: variants.append(x)
    add(base)
    if model: add(f'"{model}" {q}')
    if batch >= 1 or mode == 'deep': add(f'{base} authorised dealer distributor')
    if batch >= 2 or mode == 'deep': add(f'{base} manufacturer stockist reseller')
    if spec and mode == 'deep': add(f'{base} {spec[:180]}')
    return variants[:1 if mode=='minimum' else (2 if mode=='standard' and batch==0 else 4)]


def _supplier_extra_contact_links_v23(page, base_url, limit=3):
    out=[]; seen=set()
    try: base_host=(urlparse(base_url).hostname or '').lower().replace('www.','')
    except Exception: return []
    for m in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', str(page or ''), flags=re.I|re.S):
        label=_html_to_text(m.group(2)).lower(); raw=m.group(1)
        if not re.search(r'contact|about|reach us|enquir|support|location|branch', label+' '+raw.lower()): continue
        url=urljoin(base_url, html_lib.unescape(raw))
        try:
            u=urlparse(url); host=(u.hostname or '').lower().replace('www.','')
            if host!=base_host or u.scheme not in ('http','https'): continue
        except Exception: continue
        key=url.split('#',1)[0].rstrip('/').lower()
        if key in seen: continue
        seen.add(key); out.append(url)
        if len(out)>=limit: break
    return out


def _supplier_country_v23(text, url, phones):
    hay=_html_to_text(text or '').lower(); host=(urlparse(url).hostname or '').lower()
    if host.endswith('.in') or re.search(r'\b(india|gujarat|maharashtra|tamil nadu|karnataka|telangana|delhi|rajasthan|madhya pradesh|uttar pradesh|west bengal|kerala|punjab|haryana|bihar|odisha|andhra pradesh|chhattisgarh|jharkhand|uttarakhand|goa)\b',hay) or any(re.sub(r'\D','',p).startswith('91') for p in phones): return 'India'
    foreign={'China':r'\bchina\b|\+86','United States':r'\b(united states|usa)\b|\+1\s','United Kingdom':r'\b(united kingdom|uk)\b|\+44','Germany':r'\bgermany\b|\+49','UAE':r'\b(united arab emirates|uae|dubai)\b|\+971'}
    combo=hay+' '+' '.join(phones)
    for country,pat in foreign.items():
        if re.search(pat,combo,re.I): return country
    return ''


def _supplier_price_v23(text, score):
    if score < 35: return ''
    raw=_html_to_text(text or '')
    for pat in (r'₹\s*\d[\d,]*(?:\.\d+)?', r'(?i)\b(?:Rs\.?|INR)\s*\d[\d,]*(?:\.\d+)?'):
        m=re.search(pat,raw)
        if m: return _clean_text(m.group(0))[:40]
    return ''


def _supplier_page_image_v24(page, base_url):
    """Best product/business image explicitly published by the candidate page."""
    text=str(page or '')
    candidates=[]
    pats=(
        r'<meta[^>]+property=["\']og:image(?::secure_url)?["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image(?::secure_url)?["\']',
        r'<meta[^>]+name=["\']twitter:image(?::src)?["\'][^>]+content=["\']([^"\']+)',
        r'<link[^>]+rel=["\'][^"\']*image_src[^"\']*["\'][^>]+href=["\']([^"\']+)',
    )
    for pat in pats:
        m=re.search(pat,text,flags=re.I|re.S)
        if m:candidates.append(html_lib.unescape(m.group(1)))
    # Product cards commonly omit OG metadata, so inspect a few real <img> URLs.
    for m in re.finditer(r'<img\b[^>]+(?:src|data-src|data-original)=["\']([^"\']+)["\']',text,flags=re.I|re.S):
        candidates.append(html_lib.unescape(m.group(1)))
        if len(candidates)>=14:break
    for raw in candidates:
        try:url=urljoin(base_url,raw.strip())
        except Exception:continue
        if not url.startswith(('http://','https://')):continue
        low=url.lower()
        if any(x in low for x in ('logo','favicon','sprite','icon','avatar','placeholder','blank.gif','1x1')):continue
        return url
    return ''


def _supplier_match_score_v24(query,title,snippet,page):
    """Score only visible result/page content; never let the search URL echo the query."""
    qtokens=[t for t in re.sub(r'[^a-z0-9]+',' ',_clean_text(query).lower()).split() if len(t)>1 and t not in {'the','and','for','with','india'}]
    visible=_clean_text(' '.join((title or '',snippet or '',_html_to_text((page or '')[:220000]))).lower())
    hay=re.sub(r'[^a-z0-9]+',' ',visible)
    hits=sum(1 for t in qtokens if t in hay)
    qnorm=' '.join(qtokens)
    exact_phrase=bool(qnorm and qnorm in hay)
    score=hits*10+(85 if exact_phrase else 0)
    if re.search(r'\b(supplier|dealer|distributor|manufacturer|stockist|reseller|channel partner|trader|wholesaler)\b',hay):score+=10
    return score,hits,len(qtokens),exact_phrase


def _supplier_contact_record_v23(query,url,title='',snippet='',source_provider='Web',scope='india',model='',deep_scan=False):
    page=''; final=url
    try: final,page=_managed_site_request(url, timeout=6.5 if deep_scan else 4.5)
    except Exception: page=''
    try: host=(urlparse(final or url).hostname or '').lower()
    except Exception: host=''
    # Prevent documentation/forums/privacy/help pages from being mislabeled as suppliers.
    blocked_hosts=('support.microsoft.com','learn.microsoft.com','answers.microsoft.com','microsoft.com','github.com','stackoverflow.com','reddit.com','quora.com','wikipedia.org')
    if any(host==h or host.endswith('.'+h) for h in blocked_hosts):return None
    page_title=_html_to_text(title or '')
    if re.search(r'(?i)\b(privacy statement|privacy policy|terms of use|microsoft q&a|security issue|file handler|documentation|support article|community forum)\b',page_title):return None
    combined=' '.join((snippet or '',page or '')); phones,emails=_extract_public_business_contacts(combined)
    extra_pages=[]
    if deep_scan or not phones or not emails:
        for link in _supplier_extra_contact_links_v23(page,final,3 if deep_scan else 2):
            try:
                ef,ep=_managed_site_request(link,timeout=5.0);extra_pages.append(ep);p2,e2=_extract_public_business_contacts(ep)
                for p in p2:
                    if p not in phones: phones.append(p)
                for e in e2:
                    if e not in emails: emails.append(e)
            except Exception: pass
            if phones and emails and not deep_scan: break
    combined_all=' '.join([combined]+extra_pages)
    match_query=' '.join(x for x in (query,model) if x)
    score,hits,total,exact_phrase=_supplier_match_score_v24(match_query,title,snippet,combined_all)
    # Require genuine product evidence in visible content. This removes unrelated search-index noise.
    min_hits=1 if total<=2 else 2
    if hits<min_hits and not exact_phrase:return None
    if total>=4 and hits<max(2,(total+1)//2) and not exact_phrase:return None
    country=_supplier_country_v23(combined_all,final,phones)
    if scope!='global' and country and country!='India': return None
    if not (phones or emails) and score<35: return None
    supplier=_supplier_company_name(title,page,final); location=_supplier_location(combined_all)
    if not supplier or re.search(r'(?i)\b(microsoft|privacy|support|documentation|q&a|security issue)\b',supplier):return None
    if country=='India' and location and 'india' not in location.lower(): location += ' / India'
    exact=bool(total and (exact_phrase or hits>=max(1,total-1))); model_exact=bool(model and re.search(r'(?i)(?<![A-Z0-9])'+re.escape(model)+r'(?![A-Z0-9])', _html_to_text(combined_all+' '+title)))
    conf=max(60,min(99,58 + min(30,hits*7) + (10 if exact else 0) + (7 if model_exact else 0) + (4 if phones else 0) + (3 if emails else 0)))
    match='⭐ Exact product/model match' if model_exact or exact else ('Strong related supplier/dealer' if hits>=max(2,total//2) else 'Related supplier/dealer')
    if phones and emails: status='Ready to WhatsApp + Mail'
    elif phones: status='Ready to WhatsApp'
    elif emails: status='Ready to Mail'
    else: status='Needs manual review'
    verified_contact=bool(phones or emails)
    verified_product=bool(exact or model_exact or (hits>=max(2,total//2)))
    verification='Verified product + public contact' if verified_contact and verified_product else ('Product verified · contact review' if verified_product else 'Related supplier · review')
    image=_supplier_page_image_v24(page,final) if page else ''
    uid=hashlib.sha1((str(final)+'|'+str(supplier)).encode('utf-8','ignore')).hexdigest()[:18]
    return {'row_uid':'supplier-'+uid,'product_name':_supplier_clean_query_v23(query),'model':model or '','specs':match,'purchase_price':_supplier_price_v23(combined_all,score),'supplier':supplier,'contact':' / '.join(phones[:4]),'contact_email':' / '.join(emails[:4]),'supplier_location':location,'location':location,'category':'Supplier Contact','price_date':'Live web contact','product_link':final,'image_link':image,'image_source':'Supplier website' if image else '','source_sheet':'Supplier Contacts','source_type':'supplier_contact','contact_status':status,'verification_status':verification,'verified_contact':verified_contact,'verified_product_match':verified_product,'match_note':match,'match_score':score,'match_confidence':conf,'match_tier':'exact_model' if model_exact else ('exact_product' if exact else 'same_model_series'),'search_snippet':_clean_text(snippet)[:900],'source_provider':source_provider,'country':country or ('India' if scope!='global' else ''),'deep_scanned':bool(deep_scan)}


def search_supplier_contacts(query, limit=20, mode='standard', offset=0, model='', specification='', delivery='', scope='india'):
    query=_supplier_clean_query_v23(query);mode=_normalize_search_mode(mode);scope='global' if str(scope).lower()=='global' else 'india';limit=max(1,min(40,int(limit or 20)));offset=max(0,min(160,int(offset or 0)));wanted=min(200,offset+limit);batch=offset//20
    if not query:return [],{'ok':True,'searched':False,'methods':[],'offset':offset,'limit':limit,'exhausted':True}
    cache_key=(query.lower(),_clean_text(model).lower(),_clean_text(specification).lower(),mode,scope,batch)
    with _SUPPLIER_V23_LOCK:
        cached=_SUPPLIER_V23_CACHE.get(cache_key)
        if cached and time.time()-cached[0]<_SUPPLIER_CONTACT_TTL and len(cached[1])>=wanted:
            rows=cached[1][offset:offset+limit];info=dict(cached[2],cached=True,offset=offset,limit=limit,exhausted=offset+len(rows)>=len(cached[1]))
            return rows,info
    providers=['Public Web Index']
    if SERPER_API_KEY: providers.append('Serper')
    if EXA_API_KEY: providers.append('Exa')
    if TAVILY_API_KEY: providers.append('Tavily')
    if FIRECRAWL_API_KEY: providers.append('Firecrawl')
    # Minimum is cheapest. Standard/Deep use every configured method in parallel, as requested.
    chosen=providers[:1 if mode=='minimum' else len(providers)]
    variants=_supplier_query_variants_v23(query,model,specification,batch,mode);target_each=max(20,min(70,wanted*2)); discovered=[];methods=[];errors=[]
    jobs=[]
    with ThreadPoolExecutor(max_workers=min(10,max(1,len(chosen)*len(variants)))) as pool:
        for provider in chosen:
            for variant in variants: jobs.append((provider,variant,pool.submit(_supplier_provider_search_v23,provider,variant,target_each,mode,scope)))
        for provider,variant,fut in jobs:
            try:
                rows=fut.result() or []
                if rows: methods.append(provider)
                for url,title,snip in rows: discovered.append((url,title,snip,provider))
            except Exception as exc: errors.append(provider+': '+str(exc)[:160])
    # Always include a targeted IndiaMART discovery when Serper is configured.
    if scope=='india' and SERPER_API_KEY:
        try:
            im=_serper_indiamart_links(' '.join(x for x in (query,model) if x),min(50,target_each),mode)
            for url,title,snip in im: discovered.append((url,title,snip,'IndiaMART via Serper'))
            if im: methods.append('IndiaMART via Serper')
        except Exception as exc: errors.append('IndiaMART: '+str(exc)[:120])
    uniq=[];seen=set()
    for row in discovered:
        url=row[0];key=url.split('#',1)[0].rstrip('/').lower()
        if not key or key in seen: continue
        seen.add(key);uniq.append(row)
    fetch_cap=min(len(uniq), max(28,wanted*2) if mode!='minimum' else max(14,wanted));candidates=[]
    with ThreadPoolExecutor(max_workers=min(10,max(1,fetch_cap))) as pool:
        futures=[pool.submit(_supplier_contact_record_v23,query,u,t,s,p,scope,model,mode=='deep') for u,t,s,p in uniq[:fetch_cap]]
        for fut in as_completed(futures):
            try:
                rec=fut.result()
                if rec:candidates.append(rec)
            except Exception:pass
    # Fast snippet-only fallback on un-fetched candidates using the old parser when possible.
    for u,t,s,p in uniq[fetch_cap:]:
        rec=_supplier_contact_record_v23(query,u,t,s,p,scope,model,False)
        if rec:candidates.append(rec)
    best={}
    for r in candidates:
        supplier_key=re.sub(r'\W+','',_clean_text(r.get('supplier')).lower()); phone=re.sub(r'\D','',_clean_text(r.get('contact')))[:12]; email=_clean_text(r.get('contact_email')).lower().split('/')[0].strip(); host=(urlparse(r.get('product_link') or '').hostname or '').lower()
        key=(supplier_key or host, phone, email)
        if key not in best or int(r.get('match_score') or 0)>int(best[key].get('match_score') or 0):best[key]=r
    all_rows=sorted(best.values(),key=lambda r:(-int(r.get('match_score') or 0),0 if r.get('contact') else 1,0 if r.get('contact_email') else 1,_clean_text(r.get('supplier')).lower()))
    info={'ok':True,'searched':True,'query':query,'count':min(limit,max(0,len(all_rows)-offset)),'totalDiscovered':len(all_rows),'methods':list(dict.fromkeys(methods)),'errors':errors,'configuredProviders':_configured_search_api_names(),'source':'Supplier Contacts','searchMode':mode,'scope':scope,'offset':offset,'limit':limit,'cached':False,'exhausted':offset+limit>=len(all_rows)}
    with _SUPPLIER_V23_LOCK:_SUPPLIER_V23_CACHE[cache_key]=(time.time(),all_rows,info)
    return all_rows[offset:offset+limit],info


def _supplier_json_file_read(path):
    try:
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except Exception:return []


def _supplier_json_file_append(path,item,unique_key=None,max_items=2000):
    with _SUPPLIER_V23_LOCK:
        rows=_supplier_json_file_read(path)
        if unique_key:
            key=unique_key(item);rows=[x for x in rows if unique_key(x)!=key]
        rows.insert(0,item);rows=rows[:max_items]
        Path(path).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
        return len(rows)


class Handler(SimpleHTTPRequestHandler):
    # Browser tabs can cancel/reset keep-alive sockets while a new search replaces an
    # old one. Swallow only those normal disconnects at the top request-handler level
    # so they can never print a traceback or destabilise the threaded local server.
    def handle(self):
        try:
            return super().handle()
        except Exception as exc:
            if self._is_client_disconnect(exc):
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return
            raise

    # Persistent local connections reduce repeated request setup while the UI
    # loads price pages, catalogs and category metadata.
    protocol_version = "HTTP/1.1"

    def client_allowed(self):
        ip = self.client_address[0] if self.client_address else ""
        if _is_allowed_client_ip(ip):
            return True
        self.send_response(403)
        data = b"PriceMaster remote access is limited to localhost, private LAN and Tailscale clients."
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return False

    @staticmethod
    def _is_client_disconnect(exc):
        if isinstance(exc, (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
            return True
        if isinstance(exc, OSError):
            if getattr(exc, "winerror", None) in (10053, 10054, 10058):
                return True
            if getattr(exc, "errno", None) in (32, 54, 104):
                return True
        return False

    def _write_response_bytes(self, data):
        try:
            self.wfile.write(data)
            return True
        except Exception as exc:
            if self._is_client_disconnect(exc):
                # The browser cancelled a superseded search/image request.
                # That is normal during fast typing/new searches; do not turn it
                # into a second JSON error response or print a traceback.
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return False
            raise

    def copyfile(self, source, outputfile):
        # Browsers frequently cancel an old HTML/image transfer when the user
        # starts a new search or reloads.  SimpleHTTPRequestHandler normally
        # prints a traceback for that harmless disconnect; keep the server quiet
        # and ready for the next request instead.
        try:
            shutil.copyfileobj(source, outputfile)
        except Exception as exc:
            if self._is_client_disconnect(exc):
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return
            raise

    def json_response(self, payload, status=200):
        data = json.dumps(
            payload,
            ensure_ascii=False,
            separators=(",", ":")
        ).encode("utf-8")
        accept_encoding = (self.headers.get("Accept-Encoding", "") or "").lower()
        use_gzip = len(data) > 2048 and "gzip" in accept_encoding
        if use_gzip:
            data = gzip.compress(data, compresslevel=4)

        try:
            self.send_response(status)
            self.send_header(
                "Content-Type",
                "application/json; charset=utf-8"
            )
            self.send_header(
                "Cache-Control",
                "no-store"
            )
            if use_gzip:
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Vary", "Accept-Encoding")
            self.send_header(
                "Content-Length",
                str(len(data))
            )
            self.end_headers()
            return self._write_response_bytes(data)
        except Exception as exc:
            if self._is_client_disconnect(exc):
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return False
            raise

    def image_response(self, data, content_type="image/jpeg"):
        try:
            self.send_response(200)
            self.send_header("Content-Type", content_type or "image/jpeg")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "public, max-age=21600")
            self.end_headers()
            return self._write_response_bytes(data)
        except Exception as exc:
            if self._is_client_disconnect(exc):
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return False
            raise

    def svg_response(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8")
        try:
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return self._write_response_bytes(data)
        except Exception as exc:
            if self._is_client_disconnect(exc):
                return False
            raise

    def pdf_response(self, data, filename="NUNES_Quotation.pdf"):
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", filename or "NUNES_Quotation.pdf")
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Disposition", f'attachment; filename="{safe_name}"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            return self._write_response_bytes(data)
        except Exception as exc:
            if self._is_client_disconnect(exc):
                try:
                    self.close_connection = True
                except Exception:
                    pass
                return False
            raise

    def end_headers(self):
        # Do not overwrite explicit cache headers. JSON/HTML remain no-store,
        # while proxied product images can be browser-cached for faster scrolling.
        try:
            header_blob = b"".join(getattr(self, "_headers_buffer", [])).lower()
        except Exception:
            header_blob = b""
        if b"cache-control:" not in header_blob:
            self.send_header(
                "Cache-Control",
                "no-store, no-cache, must-revalidate, max-age=0"
            )
            self.send_header("Pragma", "no-cache")
        super().end_headers()

    def _is_local_admin(self):
        try:
            return ipaddress.ip_address(self.client_address[0]).is_loopback
        except Exception:
            return False

    def _client_meta(self, query="", increment_search=False):
        client_id = _clean_text(self.headers.get("X-PriceMaster-Client", ""))[:120]
        client_name = _clean_text(self.headers.get("X-PriceMaster-Client-Name", ""))[:80]
        if not client_id:
            return {"clientId": "", "name": client_name or "Browser"}
        try:
            return pm_intel.client_seen(
                client_id, client_name or "Office-PC",
                ip=self.client_address[0] if self.client_address else "",
                user_agent=self.headers.get("User-Agent", ""),
                query=query, increment_search=increment_search,
            )
        except Exception:
            return {"clientId": client_id, "name": client_name or "Office-PC"}

    def do_GET(self):
        if not self.client_allowed():
            return
        parsed = urlparse(self.path)
        self._client_meta()

        # The operations/admin console is intentionally localhost-only. Client PCs
        # keep the normal PriceMaster page and never see server controls.
        if parsed.path in {"/admin", "/admin.html"} and not self._is_local_admin():
            return self.json_response({"ok": False, "error": "Admin dashboard is available only on the main PriceMaster server PC."}, 403)

        # Local-only health marker used by Windows launch/status scripts. It does
        # not depend on Google, IndiaMART, Drive, or any other internet service.
        if parsed.path == "/api/local-health":
            return self.json_response({
                "ok": True,
                "app": "PriceMaster",
                "build": APP_BUILD,
                "port": PORT,
                "server": socket.gethostname(),
            })

        if parsed.path == "/api/client-info":
            local_url, hostname_url, lan_urls, tailscale_url = _server_access_urls()
            preferred = (lan_urls[0] if lan_urls else (hostname_url or tailscale_url or local_url))
            return self.json_response({
                "ok": True,
                "app": "PriceMaster",
                "build": APP_BUILD,
                "server": socket.gethostname(),
                "port": PORT,
                "preferredClientUrl": preferred,
                "hostnameUrl": hostname_url,
                "lanUrls": lan_urls,
                "tailscaleUrl": tailscale_url,
            })

        # Compatibility/status endpoint. Some existing clients poll /api/state;
        # F14.6 answers it locally instead of producing repeated 404 log spam.
        if parsed.path == "/api/state":
            try:
                with _price_async_lock:
                    active_products = len(_price_cache.get("products") or [])
                    price_loading = bool(_price_cache.get("loading"))
                    price_error = _clean_text(_price_cache.get("error") or "")
            except Exception:
                active_products, price_loading, price_error = 0, False, ""
            return self.json_response({
                "ok": True,
                "app": "PriceMaster",
                "build": APP_BUILD,
                "server": socket.gethostname(),
                "port": PORT,
                "priceProducts": active_products,
                "priceLoading": price_loading,
                "priceError": price_error,
                "indiaMartPersistentSearches": _indiamart_persisted_search_count(),
                "indiaMartPersistentFile": str(INDIAMART_PERSIST_FILE),
                "timestamp": time.time(),
            })

        if parsed.path == "/api/client-register":
            meta = self._client_meta()
            return self.json_response({"ok": True, "client": meta, "server": socket.gethostname(), "build": APP_BUILD})

        if parsed.path == "/api/product-intelligence":
            q = parse_qs(parsed.query).get("q", [""])[0].strip()
            try:
                result = pm_intel.product_intelligence(q)
                result["build"] = APP_BUILD
                return self.json_response(result)
            except Exception as exc:
                return self.json_response({"ok": False, "query": q, "error": str(exc)}, 500)

        if parsed.path.startswith("/api/admin/"):
            if not self._is_local_admin():
                return self.json_response({"ok": False, "error": "Main server PC only"}, 403)
            if parsed.path == "/api/admin/client-qr.svg":
                try:
                    import qrcode
                    import qrcode.image.svg
                    local_url, hostname_url, lan_urls, tailscale_url = _server_access_urls()
                    target = (lan_urls[0] if lan_urls else (hostname_url or tailscale_url or local_url))
                    img = qrcode.make(target, image_factory=qrcode.image.svg.SvgPathImage, border=2)
                    buf = io.BytesIO(); img.save(buf)
                    return self.svg_response(buf.getvalue())
                except Exception as exc:
                    return self.json_response({"ok": False, "error": str(exc)}, 500)
            if parsed.path == "/api/admin/health":
                try:
                    with _price_lock:
                        price_count = len(_price_cache.get("products") or [])
                        price_loading = bool(_price_cache.get("loading"))
                        price_error = _clean_text(_price_cache.get("error") or "")
                    clients = pm_intel.list_clients()
                    backups = pm_intel.list_backups(limit=1)
                    runtime_total, runtime_used, runtime_free = shutil.disk_usage(str(RUNTIME_CACHE_DIR))
                    payload = {
                        "ok": True, "build": APP_BUILD, "server": socket.gethostname(), "port": PORT,
                        "serverOnline": True, "clients": clients,
                        "connectedClients": sum(1 for x in clients if x.get("active")),
                        "searchWork": _office_search_stats(), "sharedCache": _central_cache_stats(),
                        "cacheBytes": pm_intel.cache_size_bytes(), "brain": pm_intel.db_counts(),
                        "priceIndex": {"products": price_count, "loading": price_loading, "error": price_error},
                        "indiaMart": {"persistentSearches": _indiamart_persisted_search_count(), "ramCacheEntries": len(_indiamart_cache)},
                        "runtimeDisk": {"total": runtime_total, "used": runtime_used, "free": runtime_free},
                        "lastBackup": backups[0] if backups else None,
                        "clientLinks": _server_access_urls(),
                        "internetOnline": _internet_status_cached(),
                        "system": _system_metrics_builtin(),
                        "timestamp": time.time(),
                    }
                    return self.json_response(payload)
                except Exception as exc:
                    return self.json_response({"ok": False, "error": str(exc)}, 500)
            if parsed.path == "/api/admin/clients":
                return self.json_response({"ok": True, "clients": pm_intel.list_clients()})
            if parsed.path == "/api/admin/search-inspector":
                return self.json_response({"ok": True, "events": pm_intel.search_inspector(80)})
            if parsed.path == "/api/admin/suppliers":
                return self.json_response({"ok": True, "suppliers": pm_intel.supplier_summary(150)})
            if parsed.path == "/api/admin/backups":
                return self.json_response({"ok": True, "backups": pm_intel.list_backups(30)})

        # Integrated NUNES Quotation & Price Hub (local shared-file browser).
        if quotation_hub.handle_get(self, parsed):
            return

        # Lightweight catalog-only search used by Overall Category PDF attachments.
        # It intentionally skips the large local Price Master scan.
        if parsed.path == "/api/catalog-search":
            query = parse_qs(parsed.query).get("q", [""])[0].strip()
            if not query:
                return self.json_response({"ok": True, "results": [], "totalMatches": 0})
            result = cloud_json({"action": "search", "q": query})
            if not isinstance(result, dict):
                result = {"ok": False, "error": "Invalid cloud search response.", "results": []}
            if not isinstance(result.get("results"), list):
                result["results"] = []
            result["catalogOnly"] = True
            return self.json_response(result)

        # Local search -> cloud Apps Script searchDrive(query)
        if parsed.path == "/api/search":
            query = parse_qs(
                parsed.query
            ).get("q", [""])[0].strip()

            if query:
                result = cloud_json({"action": "search", "q": query})
            else:
                result = {"ok": True, "results": [], "indexedFiles": 0, "totalMatches": 0}

            drive_results = result.get("results", []) if isinstance(result, dict) else []
            if not isinstance(drive_results, list):
                drive_results = []
            try:
                price_results, price_state, price_total, price_offset, price_limit = search_price_products_page(
                    query, drive_results=drive_results, offset=0, limit=240
                )
            except Exception as exc:
                price_results, price_state, price_total, price_offset, price_limit = [], {"error": str(exc), "loading": False, "loaded_at": 0, "sheets": []}, 0, 0, 240

            if not isinstance(result, dict):
                result = {"ok": False, "error": "Invalid cloud search response."}
            result["priceResults"] = price_results
            result["priceCount"] = len(price_results)
            result["priceTotal"] = price_total
            result["priceOffset"] = price_offset
            result["priceLimit"] = price_limit
            result["priceHasMore"] = price_offset + len(price_results) < price_total
            result["priceIndex"] = price_state
            result["combinedArchitecture"] = "NUNES single-server merged search"

            return self.json_response(result)

        if parsed.path == "/api/supplier-contacts":
            params = parse_qs(parsed.query)
            query = params.get("q", [""])[0].strip(); mode = _normalize_search_mode(params.get("mode", ["standard"])[0])
            model = params.get("model", [""])[0].strip(); specification = params.get("specification", [""])[0].strip(); delivery = params.get("delivery", [""])[0].strip(); scope = params.get("scope", ["india"])[0].strip()
            try: limit = max(1, min(40, int(params.get("limit", ["20"])[0])) )
            except Exception: limit = 20
            try: offset = max(0, min(160, int(params.get("offset", ["0"])[0])) )
            except Exception: offset = 0
            try:
                rows, info = search_supplier_contacts(query, limit=limit, mode=mode, offset=offset, model=model, specification=specification, delivery=delivery, scope=scope)
                payload = dict(info or {}); payload.update({"products": rows, "count": len(rows), "ok": True})
                return self.json_response(payload)
            except Exception as exc:
                return self.json_response({"ok": False, "products": [], "count": 0, "query": query, "error": str(exc)}, 500)

        if parsed.path == "/api/indiamart-saved":
            params = parse_qs(parsed.query)
            query = params.get("q", [""])[0].strip()
            mode = _normalize_search_mode(params.get("mode", ["standard"])[0])
            free_only = str(params.get("free", ["1"])[0]).strip().lower() in {"1", "true", "yes", "on"}
            rows, info = _load_persisted_indiamart_results_any_mode(query, preferred_mode=mode, free_only=free_only)
            payload = dict(info or {})
            payload.update({
                "ok": bool(rows),
                "saved": bool(rows),
                "products": rows,
                "count": len(rows),
                "query": query,
                "searchMode": mode,
                "freeScrapeApi": bool(free_only),
                "persistentFile": str(INDIAMART_PERSIST_DB),
            })
            return self.json_response(payload, 200 if rows else 404)

        if parsed.path == "/api/indiamart-search":
            params = parse_qs(parsed.query)
            query = params.get("q", [""])[0].strip()
            request_started = time.time()
            request_meta = self._client_meta(query=query, increment_search=bool(query))
            try:
                limit = max(1, min(INDIAMART_PAGE_SIZE_MAX, int(params.get("limit", [str(INDIAMART_PAGE_SIZE_DEFAULT)])[0])))
            except Exception:
                limit = INDIAMART_PAGE_SIZE_DEFAULT
            try:
                cursor_raw = params.get("cursor", params.get("offset", ["0"]))[0]
                offset = max(0, min(INDIAMART_MAX_RESULTS - 1, int(cursor_raw or 0)))
            except Exception:
                offset = 0
            search_limit = min(INDIAMART_MAX_RESULTS, max(INDIAMART_PAGE_SIZE_MAX, offset + limit))
            mode = _normalize_search_mode(params.get("mode", ["standard"])[0])
            free_only = str(params.get("free", ["0"])[0]).strip().lower() in {"1", "true", "yes", "on"}
            if not query:
                return self.json_response({"ok": True, "products": [], "count": 0, "searched": False, "source": "IndiaMART", "searchMode": mode})
            try:
                rows, info = search_indiamart_singleflight(query, limit=search_limit, mode=mode, free_only=free_only)
                payload = dict(info)
                payload["products"] = rows
                payload["count"] = len(rows)
                try:
                    print("[INDIAMART FREE] query=%r mode=%s rows=%d methods=%s" % (
                        query, mode, len(rows), ", ".join(payload.get("methods") or []) or "none"
                    ), flush=True)
                    if payload.get("warning"):
                        print("[INDIAMART FREE] warning: %s" % payload.get("warning"), flush=True)
                    elif payload.get("error"):
                        print("[INDIAMART FREE] error: %s" % payload.get("error"), flush=True)
                except Exception:
                    pass

                if rows:
                    # Server-side durable save happens before the GET response is
                    # returned. This means even if the browser closes before its
                    # explicit POST save, the fetched IndiaMART list is safe.
                    try:
                        save_result = _persist_indiamart_results(
                            query, rows, payload, mode=mode, free_only=free_only, origin="server-get"
                        )
                        payload.update({
                            "persisted": bool(save_result.get("saved")),
                            "persistChanged": bool(save_result.get("changed", True)),
                            "persistedAt": save_result.get("savedAt", 0),
                            "persistentFile": save_result.get("persistentFile", str(INDIAMART_PERSIST_DB)),
                        })
                    except Exception as save_exc:
                        payload["persisted"] = False
                        payload["persistError"] = str(save_exc)
                    total_available = len(rows)
                    page_rows = rows[offset:offset + limit]
                    payload["products"] = page_rows
                    payload["count"] = len(page_rows)
                    payload["offset"] = offset
                    payload["pageSize"] = limit
                    payload["totalFound"] = total_available
                    payload["hasMore"] = offset + len(page_rows) < total_available
                    payload["nextCursor"] = str(offset + len(page_rows)) if payload["hasMore"] else ""
                    payload["dataStatus"] = payload.get("dataStatus") or "live"
                    for row in page_rows:
                        if isinstance(row, dict):
                            row.setdefault("dataStatus", payload.get("dataStatus") or "live")
                            row.setdefault("retrieved_at", time.time())
                            tier, tier_label, confidence = _model_match_tier(query, row)
                            row["match_tier"] = tier_label
                            row["match_confidence"] = confidence
                    try:
                        pm_intel.learn_rows(query, rows, source="indiamart")
                        pm_intel.record_search(query, "indiamart", request_started, len(rows), "ok", request_meta.get("clientId", ""), "shared" if payload.get("sharedInflight") else "live", {"methods": payload.get("methods") or [], "mode": mode})
                    except Exception:
                        pass
                    return self.json_response(payload)

                # A live extraction failure/zero caused by temporary blocking must
                # not erase history. Reuse the latest successful disk snapshot.
                saved_rows, saved_info = _load_persisted_indiamart_results_any_mode(query, preferred_mode=mode, free_only=free_only)
                if saved_rows:
                    fallback = dict(saved_info or {})
                    fallback.update({
                        "ok": True,
                        "searched": True,
                        "source": "IndiaMART",
                        "products": saved_rows[offset:offset + limit],
                        "count": len(saved_rows[offset:offset + limit]),
                        "query": query,
                        "searchMode": mode,
                        "freeScrapeApi": bool(free_only),
                        "liveSearchFailed": bool(payload.get("error")),
                        "liveError": payload.get("error") or payload.get("warning") or "Live search returned no rows",
                        "persistedFallback": True,
                    })
                    fallback["count"] = len(fallback["products"])
                    fallback["offset"] = offset
                    fallback["pageSize"] = limit
                    fallback["totalFound"] = len(saved_rows)
                    fallback["hasMore"] = offset + len(fallback["products"]) < len(saved_rows)
                    fallback["nextCursor"] = str(offset + len(fallback["products"])) if fallback["hasMore"] else ""
                    fallback["dataStatus"] = fallback.get("dataStatus") or "saved"
                    for row in fallback["products"]:
                        if isinstance(row, dict):
                            row.setdefault("dataStatus", fallback.get("dataStatus") or "saved")
                            row.setdefault("snapshotAgeHours", fallback.get("snapshotAgeHours"))
                            tier, tier_label, confidence = _model_match_tier(query, row)
                            row["match_tier"] = tier_label
                            row["match_confidence"] = confidence
                    try:
                        pm_intel.record_search(query, "indiamart", request_started, len(fallback["products"]), "saved", request_meta.get("clientId", ""), "saved", {"mode": mode})
                    except Exception:
                        pass
                    return self.json_response(fallback)

                # A temporary public-source block (commonly HTTP 429) is not a
                # server crash. Keep the API responsive with HTTP 200 so the UI
                # can report a temporary IndiaMART limitation without showing a
                # hard transport failure. Successful saved results are handled
                # above and remain protected from empty overwrites.
                if payload.get("error"):
                    live_error = _clean_text(payload.pop("error", ""))
                    payload["ok"] = True
                    payload["temporarilyUnavailable"] = True
                    payload["warning"] = live_error or payload.get("warning") or "IndiaMART live sources temporarily unavailable"
                    payload["products"] = []
                    payload["count"] = 0
                    return self.json_response(payload, 200)
                return self.json_response(payload)
            except Exception as exc:
                saved_rows, saved_info = _load_persisted_indiamart_results(query, mode=mode, free_only=free_only)
                if saved_rows:
                    fallback = dict(saved_info or {})
                    fallback.update({
                        "ok": True, "searched": True, "source": "IndiaMART",
                        "products": saved_rows[offset:offset + limit], "count": len(saved_rows[offset:offset + limit]),
                        "query": query, "searchMode": mode, "freeScrapeApi": bool(free_only),
                        "persistedFallback": True, "liveSearchFailed": True, "liveError": str(exc),
                    })
                    fallback["count"] = len(fallback["products"])
                    return self.json_response(fallback)
                return self.json_response({
                    "ok": True, "products": [], "count": 0, "searched": True,
                    "source": "IndiaMART", "temporarilyUnavailable": True,
                    "warning": str(exc),
                    "searchUrl": INDIAMART_SEARCH_URL.format(query=quote(query)),
                    "searchMode": mode, "freeScrapeApi": bool(free_only),
                }, 200)

        if parsed.path == "/api/indiamart-detail":
            params = parse_qs(parsed.query)
            product_url = params.get("url", [""])[0].strip()
            try:
                if _indiamart_link_is_productish(product_url):
                    record = _indiamart_detail(product_url, timeout=16)
                else:
                    # Some accepted IndiaMART rows are verified seller-owned
                    # storefronts generated by IndiaMART/InterMESH. Detail/image
                    # lookup must understand those URLs too.
                    final_url, page = _managed_site_request(product_url, timeout=12)
                    if not _looks_like_indiamart_managed_page(page):
                        raise RuntimeError("URL is not a verified IndiaMART managed storefront")
                    record = _managed_storefront_record(page, final_url)
                return self.json_response({"ok": True, "product": record, "exactImage": bool(record.get("image_link"))})
            except Exception as exc:
                return self.json_response({"ok": False, "error": str(exc), "product": {}}, 404)

        if parsed.path == "/api/price-products":
            params = parse_qs(parsed.query)
            query = params.get("q", [""])[0].strip()
            try:
                offset = max(0, int(params.get("offset", ["0"])[0]))
            except Exception:
                offset = 0
            try:
                # Strict browser-safe response limit. Every next page is requested
                # only by the existing LOAD MORE PRICES control.
                limit = max(25, min(150, int(params.get("limit", ["120"])[0])))
            except Exception:
                limit = 120
            scope = params.get("scope", [""])[0]
            with _price_lock:
                cache_generation = int(float(_price_cache.get("loaded_at") or 0))
            cache_key = "price|%s|%s|%s|%s|%s" % (cache_generation, query.casefold(), offset, limit, scope)
            started = time.time()
            meta = self._client_meta(query=query, increment_search=bool(query and offset == 0))
            cached = _central_cache_get(cache_key)
            if cached is not None:
                cached["sharedCache"] = "hit"
                try:
                    pm_intel.record_search(query, "price-sheet", started, len(cached.get("products") or []), "ok", meta.get("clientId", ""), "hit", {"offset": offset})
                except Exception:
                    pass
                return self.json_response(cached)
            try:
                page, state, total, actual_offset, actual_limit = search_price_products_page(
                    query, drive_results=[], offset=offset, limit=limit,
                    excel_names=scope == "excel_names"
                )
                payload = {
                    "ok": True, "products": page, "total": total, "offset": actual_offset,
                    "limit": actual_limit, "hasMore": actual_offset + len(page) < total,
                    "priceIndex": state, "sharedCache": "miss",
                }
                _central_cache_put(cache_key, payload)
                if query and actual_offset == 0:
                    try:
                        pm_intel.learn_rows(query, page, source="sheet")
                    except Exception:
                        pass
                try:
                    pm_intel.record_search(query, "price-sheet", started, len(page), "ok", meta.get("clientId", ""), "miss", {"total": total, "offset": actual_offset})
                except Exception:
                    pass
                return self.json_response(payload)
            except Exception as exc:
                try:
                    pm_intel.record_search(query, "price-sheet", started, 0, "error", meta.get("clientId", ""), "miss", {"error": str(exc)})
                except Exception:
                    pass
                return self.json_response({"ok": False, "error": str(exc), "products": [], "total": 0}, 500)

        # Cloud connection/status test.
        if parsed.path == "/api/status":
            result = cloud_json({
                "action": "status"
            })

            return self.json_response(result)

        if parsed.path == "/api/price-status":
            with _price_lock:
                return self.json_response({
                    "ok": bool(_price_cache["products"]),
                    "products": len(_price_cache["products"]),
                    "loadedAt": _price_cache["loaded_at"],
                    "loading": _price_cache["loading"],
                    "error": _price_cache["error"],
                    "sheets": list(_price_cache["sheets"]),
                    "source": PRICE_SHEET_URL,
                    "cachePath": _price_cache.get("cache_path", ""),
                })

        if parsed.path == "/api/image-proxy":
            remote_url = parse_qs(parsed.query).get("url", [""])[0].strip()
            try:
                data, mime = _fetch_remote_image(remote_url)
                return self.image_response(data, mime)
            except Exception:
                # Image failures are intentionally tiny and cacheable.  This
                # prevents dozens of duplicate rows from repeatedly requesting
                # the same dead/truncated CDN URL while still triggering the
                # browser's normal <img onerror> fallback.
                try:
                    self.send_response(404)
                    self.send_header("Content-Length", "0")
                    self.send_header("Cache-Control", "public, max-age=1200")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    return True
                except Exception as exc:
                    if self._is_client_disconnect(exc):
                        try:
                            self.close_connection = True
                        except Exception:
                            pass
                        return False
                    raise

        if parsed.path == "/api/find-image":
            # POST is preferred for image lookup; GET remains useful for quick browser tests.
            params = parse_qs(parsed.query)
            product = params.get("product", [""])[0]
            model = params.get("model", [""])[0]
            supplier = params.get("supplier", [""])[0]
            image = _live_image_singleflight(product, model, supplier, params.get("product_link", [""])[0], params.get("image_link", [""])[0], params.get("mode", ["standard"])[0])
            return self.json_response({"ok": True, "found": bool(image), "image_url": image or ""})

        if parsed.path == "/api/overall-categories":
            # Same Sheet/Drive data, but served from a warmed in-memory cache when available.
            try:
                return self.json_response(get_overall_category_response())
            except Exception as exc:
                return self.json_response({"ok": False, "error": str(exc), "categories": []}, 500)

        # Category list. This requires getDriveCategories()
        # in Code.gs. If unavailable, provide the two known roots.
        if parsed.path == "/api/categories":
            result = cloud_json({
                "action": "categories"
            })

            if result.get("ok"):
                return self.json_response(result)

            return self.json_response({
                "ok": True,
                "categories": [
                    {
                        "name": "Mini Catalog",
                        "type": "ROOT"
                    },
                    {
                        "name": "Catalog",
                        "type": "ROOT"
                    }
                ]
            })

        # Cloud index refresh.
        if parsed.path == "/api/refresh":
            result = cloud_json(
                post_action="refresh"
            )
            return self.json_response(result)

        # Serve the local UI.
        return super().do_GET()

    def do_HEAD(self):
        if not self.client_allowed():
            return
        parsed = urlparse(self.path)
        if quotation_hub.handle_head(self, parsed):
            return
        return super().do_HEAD()

    def do_POST(self):
        if not self.client_allowed():
            return
        parsed = urlparse(self.path)

        if parsed.path == "/api/client-register":
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                payload = json.loads(self.rfile.read(content_length).decode("utf-8")) if content_length else {}
                client_id = _clean_text(payload.get("clientId") or self.headers.get("X-PriceMaster-Client", ""))[:120]
                name = _clean_text(payload.get("name") or self.headers.get("X-PriceMaster-Client-Name", ""))[:80]
                meta = pm_intel.client_seen(client_id, name or "Office-PC", ip=self.client_address[0] if self.client_address else "", user_agent=self.headers.get("User-Agent", ""))
                return self.json_response({"ok": True, "client": meta, "server": socket.gethostname(), "build": APP_BUILD})
            except Exception as exc:
                return self.json_response({"ok": False, "error": str(exc)}, 400)

        if parsed.path.startswith("/api/admin/"):
            if not self._is_local_admin():
                return self.json_response({"ok": False, "error": "Main server PC only"}, 403)
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                payload = json.loads(self.rfile.read(content_length).decode("utf-8")) if content_length else {}
                if parsed.path == "/api/admin/backup":
                    return self.json_response(pm_intel.create_backup(BASE_DIR, reason="manual-admin"))
                if parsed.path == "/api/admin/restore":
                    with _indiamart_persist_lock:
                        with _price_lock:
                            return self.json_response(pm_intel.restore_backup(payload.get("name") or ""))
            except Exception as exc:
                return self.json_response({"ok": False, "error": str(exc)}, 400)

        # Integrated NUNES Quotation & Price Hub write/actions.
        if quotation_hub.handle_post(self, parsed):
            return

        if parsed.path in {"/api/supplier-contact-scan", "/api/supplier-contact-save", "/api/supplier-contact-log"}:
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 1024 * 1024:
                    return self.json_response({"ok": False, "error": "Invalid supplier contact request"}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict): raise ValueError("Invalid supplier contact payload")
                if parsed.path == "/api/supplier-contact-scan":
                    p = payload.get("product") or {}; query = _supplier_clean_query_v23(payload.get("query") or p.get("product_name") or ""); model = _clean_text(payload.get("model") or p.get("model") or ""); scope = "global" if str(payload.get("scope") or "india").lower()=="global" else "india"
                    url = _generic_http_url(p.get("product_link") or "", p.get("product_link") or "")
                    if not url: raise ValueError("Supplier page URL is missing")
                    rec = _supplier_contact_record_v23(query, url, p.get("supplier") or p.get("product_name") or "", p.get("search_snippet") or p.get("specs") or "", p.get("source_provider") or "Deep website scan", scope, model, True)
                    if not rec: raise ValueError("No additional public supplier contact details were found")
                    return self.json_response({"ok": True, "product": rec})
                if parsed.path == "/api/supplier-contact-save":
                    p = payload.get("product") or {}; item = dict(p); item["savedAt"] = time.time(); item["query"] = _clean_text(payload.get("query") or "")
                    count = _supplier_json_file_append(_SUPPLIER_SAVED_FILE, item, unique_key=lambda x: (_clean_text(x.get("supplier")).lower(), _clean_text(x.get("product_link")).lower()))
                    return self.json_response({"ok": True, "saved": True, "count": count})
                item = dict(payload); item["timestamp"] = time.time(); count = _supplier_json_file_append(_SUPPLIER_HISTORY_FILE, item, max_items=5000)
                return self.json_response({"ok": True, "logged": True, "count": count})
            except Exception as exc:
                return self.json_response({"ok": False, "error": str(exc)}, 400)

        if parsed.path == "/api/indiamart-save":
            # F14.5 explicit browser -> server persistence endpoint. The GET search
            # already auto-saves before responding; this POST provides a second,
            # explicit acknowledgement that the exact rows received/rendered by
            # the browser were durably stored.
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 32 * 1024 * 1024:
                    return self.json_response({"ok": False, "saved": False, "error": "Invalid IndiaMART save request size"}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid IndiaMART save payload")
                query = _clean_text(payload.get("query") or "")
                mode = _normalize_search_mode(payload.get("mode") or "standard")
                free_only = bool(payload.get("freeOnly", True))
                rows = payload.get("products") or []
                info = payload.get("info") or {}
                if not query:
                    raise ValueError("IndiaMART query is required")
                if not isinstance(rows, list):
                    raise ValueError("IndiaMART products must be a list")
                if not isinstance(info, dict):
                    info = {}
                result = _persist_indiamart_results(
                    query, rows, info, mode=mode, free_only=free_only, origin="browser-post"
                )
                if not result.get("saved"):
                    return self.json_response(result, 400)
                return self.json_response(result)
            except Exception as exc:
                return self.json_response({"ok": False, "saved": False, "error": str(exc)}, 400)

        if parsed.path == "/api/visual-search-image":
            # User-facing IMAGE SEARCH. Accepts a pasted/uploaded local image,
            # sends it directly to Google Lens, extracts merchant/product details,
            # and returns rows in the same schema used by the price table.
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 14 * 1024 * 1024:
                    return self.json_response({"ok": False, "products": [], "error": "Image search request is too large"}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid image search request")
                raw_b64 = str(payload.get("image_base64") or "").strip()
                if raw_b64.startswith("data:") and "," in raw_b64:
                    raw_b64 = raw_b64.split(",", 1)[1]
                if not raw_b64:
                    raise ValueError("No image was supplied")
                try:
                    image_data = base64.b64decode(raw_b64, validate=True)
                except Exception:
                    raise ValueError("The pasted image could not be decoded")
                if not image_data or len(image_data) > 8 * 1024 * 1024:
                    raise ValueError("Image is too large. Maximum is 8 MB")
                image_mime = _detect_image_mime(image_data, payload.get("image_mime", ""))
                if image_mime not in {"image/jpeg", "image/png", "image/webp", "image/gif"}:
                    raise ValueError("Unsupported image format. Use JPG, PNG, WEBP or GIF")
                query = _clean_text(payload.get("query") or "")
                rows, info = search_visual_matches_bytes(query, image_data, image_mime)
                result = dict(info or {})
                result["products"] = rows
                result["count"] = len(rows)
                return self.json_response(result)
            except Exception as exc:
                return self.json_response({
                    "ok": False, "searched": True, "products": [], "count": 0,
                    "source": "visual", "engine": "google_lens_upload", "error": str(exc)
                }, 400)

        if parsed.path == "/api/visual-search":
            # Backend-only Google Lens matching used automatically by FIND PRODUCTS.
            # It never blocks the normal Sheet/IndiaMART results.
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 256 * 1024:
                    return self.json_response({"ok": False, "products": [], "error": "Invalid visual search request"}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid visual search request")
                query = _clean_text(payload.get("query") or payload.get("product") or payload.get("model"))
                image_url = _normalize_image_link(payload.get("image_url") or payload.get("image_link") or "")
                # Exact Sheet/IndiaMART image is preferred. Only if the current row has
                # no public image do we reuse the existing verified image resolver.
                if not image_url:
                    image_url = _live_image_from_bing(
                        payload.get("product", ""), payload.get("model", ""), payload.get("supplier", ""),
                        payload.get("product_link", ""), payload.get("image_link", ""), payload.get("mode", "standard")
                    ) or ""
                if not query or not image_url:
                    return self.json_response({
                        "ok": True, "searched": False, "products": [], "count": 0,
                        "source": "visual", "reason": "No public product image was available as a Lens seed."
                    })
                rows, info = search_visual_matches(query, image_url)
                result = dict(info or {})
                result["products"] = rows
                result["count"] = len(rows)
                result["seedImage"] = image_url
                # Soft failure by design: the normal search remains successful even
                # when Google requests interactive browser verification.
                return self.json_response(result)
            except Exception as exc:
                return self.json_response({
                    "ok": False, "searched": True, "products": [], "count": 0,
                    "source": "visual", "error": str(exc)
                })

        if parsed.path == "/api/find-image":
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                payload = json.loads(self.rfile.read(content_length).decode("utf-8")) if content_length else {}
                image = _live_image_singleflight(payload.get("product", ""), payload.get("model", ""), payload.get("supplier", ""), payload.get("product_link", ""), payload.get("image_link", ""), payload.get("mode", "standard"))
                return self.json_response({"ok": True, "found": bool(image), "image_url": image or ""})
            except Exception as exc:
                return self.json_response({"ok": False, "found": False, "error": str(exc)})

        if parsed.path == "/api/quotation-pdf":
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 1024 * 1024:
                    return self.json_response({"ok": False, "error": "Quotation request is missing or too large."}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid quotation request.")
                products = payload.get("products") or []
                if not isinstance(products, list) or not products:
                    raise ValueError("Select at least one product before creating the quotation PDF.")
                pdf_data = build_quotation_pdf(payload)
                filename = "NUNES_Quotation_" + time.strftime("%Y%m%d_%H%M%S") + ".pdf"
                return self.pdf_response(pdf_data, filename)
            except Exception as exc:
                return self.json_response({"ok": False, "error": "Could not create quotation PDF: " + str(exc)}, 400)

        if parsed.path == "/api/send-gmail":
            content_length = int(self.headers.get("Content-Length", "0") or "0")
            if content_length <= 0 or content_length > 2 * 1024 * 1024:
                return self.json_response({
                    "ok": False,
                    "error": "Gmail request is missing or too large."
                }, 400)

            try:
                raw = self.rfile.read(content_length)
                payload = json.loads(raw.decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid Gmail request.")

                recipient = str(payload.get("recipient", "")).strip()
                files = payload.get("files") or []
                products = payload.get("products") or []
                locations = payload.get("locations") or []
                categories = payload.get("categories") or []

                if not recipient:
                    raise ValueError("Recipient email is required.")
                if not isinstance(files, list):
                    raise ValueError("Invalid Gmail file selection.")
                if not any((files, products if isinstance(products, list) else [], locations if isinstance(locations, list) else [], categories if isinstance(categories, list) else [])):
                    raise ValueError("Select a product, catalog, category, or location before sending Gmail.")
                if len(files) > 25:
                    raise ValueError("For one email, select a maximum of 25 files.")

                backend = gmail_backend_status()
                backend_build = str(backend.get("backendBuild", "") or "").strip()
                if backend_build != REQUIRED_GMAIL_BACKEND_BUILD:
                    return self.json_response({
                        "ok": False,
                        "error": (
                            "Gmail cloud backend is not V6.5 yet. "
                            "The local app is updated, but the ONLINE Apps Script deployment is still old. "
                            "Open the Apps Script project, replace Code.gs with the V6.5 Code.gs from this folder, "
                            "then Deploy > Manage deployments > Edit > New version > Deploy. "
                            "Current backend build: " + (backend_build or "older / unknown")
                        ),
                        "backendBuild": backend_build or "older / unknown"
                    }, 409)

                prepared_payload = prepare_gmail_payload(payload)
                result = cloud_json_payload(
                    "sendgmail",
                    prepared_payload
                )
                if isinstance(result, dict) and result.get("ok"):
                    result["categoryQrCount"] = int(prepared_payload.get("categoryQrCount") or 0)

                return self.json_response(
                    result,
                    200 if result.get("ok") else 400
                )

            except Exception as exc:
                return self.json_response({
                    "ok": False,
                    "error": "Could not send Gmail request: " + str(exc)
                }, 400)

        if parsed.path == "/api/refresh":
            result = cloud_json(
                post_action="refresh"
            )
            return self.json_response(result)

        if parsed.path == "/api/auto-paste-qr":
            params = parse_qs(parsed.query)
            location_id = params.get("location", [""])[0].strip().lower()
            channel = params.get("channel", [""])[0].strip().lower()

            if location_id not in QR_FILES:
                return self.json_response({
                    "ok": False,
                    "error": "Unknown location."
                }, 400)

            if channel not in ("whatsapp", "email"):
                return self.json_response({
                    "ok": False,
                    "error": "Unknown share channel."
                }, 400)

            if os.name != "nt":
                return self.json_response({
                    "ok": False,
                    "error": "Automatic QR paste is supported on Windows only."
                }, 400)

            schedule_auto_qr_paste(location_id, channel)
            return self.json_response({
                "ok": True,
                "scheduled": True,
                "location": location_id,
                "channel": channel,
                "delayMs": AUTO_PASTE_DELAY_MS.get(channel, 5500)
            })

        if parsed.path == "/api/auto-paste-category-qrs":
            try:
                content_length = int(self.headers.get("Content-Length", "0") or "0")
                if content_length <= 0 or content_length > 128 * 1024:
                    return self.json_response({"ok": False, "error": "Category QR request is missing or too large."}, 400)
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
                ids = payload.get("categoryIds") if isinstance(payload, dict) else []
                if not isinstance(ids, list):
                    raise ValueError("Invalid category selection.")
                clean_ids = []
                downloads = []
                seen = set()
                for value in ids[:60]:
                    cid = re.sub(r"[^a-z0-9-]+", "", str(value or "").lower())
                    row = WEBSITE_CATEGORY_BY_ID.get(cid)
                    if not row or cid in seen:
                        continue
                    seen.add(cid)
                    path = _website_category_qr_path(cid)
                    if not path:
                        continue
                    clean_ids.append(cid)
                    downloads.append("/" + str(row.get("qrFile") or "").replace("\\", "/"))
                if not clean_ids:
                    return self.json_response({"ok": True, "count": 0, "downloads": []})
                auto_paste = bool(payload.get("autoPaste")) and os.name == "nt"
                if auto_paste:
                    schedule_auto_category_qrs(clean_ids, "whatsapp")
                return self.json_response({
                    "ok": True,
                    "count": len(clean_ids),
                    "autoPaste": auto_paste,
                    "downloads": downloads,
                    "delayMs": AUTO_PASTE_DELAY_MS.get("whatsapp", 9000),
                })
            except Exception as exc:
                return self.json_response({"ok": False, "error": "Could not prepare category QR codes: " + str(exc)}, 400)

        if parsed.path == "/api/auto-paste-template":
            params = parse_qs(parsed.query)
            channel = params.get("channel", ["email"])[0].strip().lower()
            provider = params.get("provider", ["gmail"])[0].strip().lower()

            if channel != "email":
                return self.json_response({
                    "ok": False,
                    "error": "Full-template auto insertion is enabled for email."
                }, 400)

            if provider not in ("gmail", "outlook"):
                provider = "gmail"

            if os.name != "nt":
                return self.json_response({
                    "ok": False,
                    "error": "Automatic email template insertion is supported on Windows only."
                }, 400)

            content_length = int(self.headers.get("Content-Length", "0") or "0")
            if content_length <= 0 or content_length > 30 * 1024 * 1024:
                return self.json_response({
                    "ok": False,
                    "error": "Email template image payload is missing or too large."
                }, 400)

            try:
                raw = self.rfile.read(content_length)
                payload = json.loads(raw.decode("utf-8"))
                encoded = str(payload.get("imageBase64", "")).strip()
                if not encoded:
                    raise ValueError("Template image was empty.")

                image_bytes = base64.b64decode(encoded, validate=True)
                if len(image_bytes) < 100 or len(image_bytes) > 20 * 1024 * 1024:
                    raise ValueError("Template image size is invalid.")

                if not image_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
                    raise ValueError("Template image must be PNG format.")

                temp_name = "nunes_email_template_" + uuid.uuid4().hex + ".png"
                temp_path = os.path.join(tempfile.gettempdir(), temp_name)
                with open(temp_path, "wb") as handle:
                    handle.write(image_bytes)

                schedule_auto_template_paste(temp_path, channel, provider)

                return self.json_response({
                    "ok": True,
                    "scheduled": True,
                    "channel": channel,
                    "provider": provider,
                    "delayMs": AUTO_PASTE_DELAY_MS.get(channel, 7000)
                })

            except Exception as exc:
                return self.json_response({
                    "ok": False,
                    "error": "Could not prepare automatic email template insertion: " + str(exc)
                }, 400)

        self.send_error(404)


def main():
    os.chdir(BASE_DIR)

    local_url, hostname_url, lan_urls, tailscale_url = _server_access_urls()

    print()
    print("=" * 70)
    print(" NUNES PRICEMASTER - MAIN SERVER / BROWSER CLIENT MODE")
    print("=" * 70)
    print()
    print("Cloud service:")
    print(APPS_SCRIPT_URL)
    print()
    print("Google Drive roots:")
    print("  1. Mini Catalog")
    print("  2. Catalog")
    print()
    print(f"Main PC / localhost: {local_url}")
    if hostname_url:
        print(f"Same-WiFi easy name: {hostname_url}")
    for url in lan_urls[:3]:
        print(f"Same-WiFi client:    {url}")
    if tailscale_url:
        print(f"Different-WiFi client (Tailscale): {tailscale_url}")
    else:
        print("Different-WiFi client: install/sign in to Tailscale on server + clients, then restart PriceMaster.")
    print()
    print("Clients only need a browser; do not copy or run this ZIP on client PCs.")
    print("All searches, images, Excel/Drive access, IndiaMART fetches and cache work run on this main PC.")
    print("Keep this main server PC powered on, signed in, and PriceMaster running.")
    print("Current URLs are also written to CLIENT_LINKS.txt.")
    print()
    print("Press Ctrl+C to stop.")
    print("=" * 70)
    print()

    class PriceMasterHTTPServer(ThreadingHTTPServer):
        allow_reuse_address = True
        daemon_threads = True

        def handle_error(self, request, client_address):
            # Chrome/Edge cancel superseded fetch/image sockets aggressively while
            # the user types or starts a newer search.  WinError 10053/10054 is a
            # normal client disconnect, not a PriceMaster server failure.
            exc = sys.exc_info()[1]
            if isinstance(exc, (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
                return
            if isinstance(exc, OSError) and (getattr(exc, 'winerror', None) in (10053, 10054, 10058) or getattr(exc, 'errno', None) in (32, 54, 104)):
                return
            return super().handle_error(request, client_address)

    try:
        server = PriceMasterHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print(f"[ERROR] Could not start PriceMaster on port {PORT}: {exc}")
        print("Restart PriceMaster with START_ANY_OS.py (or your OS launcher); it will automatically select another free port.")
        return 2

    # Write access information only after the selected port has successfully bound.
    try:
        Path(SERVER_PORT_FILE).write_text(str(PORT) + "\n", encoding="utf-8")
    except Exception as exc:
        print("[SERVER] Could not write SERVER_PORT.txt:", exc)
    _write_client_links(local_url, hostname_url, lan_urls, tailscale_url)

    start_price_index_worker()
    # V16.0 More Categories is embedded locally; no Google Sheet preload is needed.
    quotation_hub.start_background_services()
    def _backup_worker():
        try:
            result = pm_intel.maybe_daily_backup(BASE_DIR)
            if result:
                print("[BACKUP] Shared PriceMaster data protected:", result.get("name") or "daily backup", flush=True)
        except Exception as exc:
            print("[BACKUP] Automatic backup skipped:", exc, flush=True)
    threading.Thread(target=_backup_worker, name="pricemaster-daily-backup", daemon=True).start()

    if str(os.environ.get("PRICEMASTER_OPEN_BROWSER", "1")).strip().lower() not in {"0", "false", "no", "off"}:
        threading.Timer(1.0, lambda: webbrowser.open(local_url)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nNUNES system stopped.")
    finally:
        server.server_close()
        try:
            marker = Path(SERVER_PORT_FILE)
            if marker.exists() and marker.read_text(encoding="utf-8").strip() == str(PORT):
                marker.unlink()
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    main()
