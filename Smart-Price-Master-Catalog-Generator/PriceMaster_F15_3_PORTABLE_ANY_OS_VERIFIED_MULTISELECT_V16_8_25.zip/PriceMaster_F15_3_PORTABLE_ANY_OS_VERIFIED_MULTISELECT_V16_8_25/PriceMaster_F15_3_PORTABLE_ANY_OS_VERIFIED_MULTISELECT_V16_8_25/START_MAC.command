#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 START_ANY_OS.py
elif command -v python >/dev/null 2>&1; then
  exec python START_ANY_OS.py
else
  echo "Python 3.9+ was not found. Install Python 3 from python.org, then run this file again."
  printf "Press Enter to close..."
  read _pm_dummy
fi
