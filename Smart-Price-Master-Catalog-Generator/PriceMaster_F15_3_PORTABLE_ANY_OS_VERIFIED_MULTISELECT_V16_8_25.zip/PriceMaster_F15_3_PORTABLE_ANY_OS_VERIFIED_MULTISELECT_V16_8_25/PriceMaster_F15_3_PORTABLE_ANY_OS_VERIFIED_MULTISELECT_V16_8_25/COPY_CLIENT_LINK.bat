@echo off
setlocal EnableExtensions
pushd "%~dp0" >nul 2>&1
if not exist "CLIENT_URL.txt" (
  echo PriceMaster client link is not available yet.
  echo Start PriceMaster first using START_PRICEMASTER.bat.
  echo.
  pause
  popd
  exit /b 1
)
set /p CLIENT_URL=<"CLIENT_URL.txt"
if not defined CLIENT_URL (
  echo CLIENT_URL.txt is empty. Restart PriceMaster.
  pause
  popd
  exit /b 1
)
<nul set /p =%CLIENT_URL%| clip
echo.
echo ============================================================
echo   PRICEMASTER CLIENT LINK COPIED
echo ============================================================
echo.
echo %CLIENT_URL%
echo.
echo Paste this link into Chrome or Edge on another office computer.
echo No ZIP, Python or installation is needed on that computer.
echo.
pause
popd
endlocal
