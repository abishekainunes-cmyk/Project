@echo off
setlocal EnableExtensions EnableDelayedExpansion
title PriceMaster - Marketing Price Desk / Main Server
color 0A

REM ============================================================
REM PRICEMASTER - RELIABLE MAIN SERVER STARTER
REM UI/workflow is unchanged. Client PCs use only a web browser.
REM Port behavior: prefer 8765; if occupied, automatically use
REM the next free port from 8766..8795 without killing any app.
REM ============================================================

pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
    echo.
    echo ============================================================
    echo   ERROR - PROJECT FOLDER NOT ACCESSIBLE
    echo ============================================================
    echo.
    echo Could not access the PriceMaster folder.
    echo Check the local/NAS/network connection and try again.
    echo.
    pause
    exit /b 1
)

set "ROOT=%CD%"
set "PORT_MIN=8765"
set "PORT_MAX=8795"
set "RUNNING_PORT="
set "PORT="
set "REQUIRED_BUILD=F15_3_PORTABLE_ANY_OS_VERIFIED_MULTISELECT_V16_8_25"

if not exist "!ROOT!\server.py" (
    echo [ERROR] server.py not found in !ROOT!
    goto :failed
)
if not exist "!ROOT!\index.html" (
    echo [ERROR] index.html not found in !ROOT!
    goto :failed
)

REM First look for an already-running verified PriceMaster instance.
for /f "usebackq delims=" %%Q in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$need='%REQUIRED_BUILD%'; $ports=%PORT_MIN%..%PORT_MAX%; foreach($p in $ports){ try { $w=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p+'/api/local-health') -TimeoutSec 1; $r=ConvertFrom-Json -InputObject $w.Content; if($r.ok -and $r.app -eq 'PriceMaster' -and $r.build -eq $need){ Write-Output $p; break } } catch {} }"`) do if not defined RUNNING_PORT set "RUNNING_PORT=%%Q"

if defined RUNNING_PORT (
    set "PORT=!RUNNING_PORT!"
    set "LOCAL_URL=http://127.0.0.1:!PORT!/index.html"
    > "!ROOT!\SERVER_PORT.txt" echo !PORT!
    echo.
    echo ============================================================
    echo   PRICEMASTER SERVER IS ALREADY RUNNING
    echo ============================================================
    echo.
    echo Port: !PORT!
    echo Main PC: !LOCAL_URL!
    if exist "!ROOT!\CLIENT_LINKS.txt" (
        echo.
        type "!ROOT!\CLIENT_LINKS.txt"
    )
    if exist "!ROOT!\CLIENT_URL.txt" (
        echo.
        echo Copy/share the single client link from CLIENT_URL.txt
    )
    if /I not "%PRICEMASTER_OPEN_BROWSER%"=="0" start "" "!LOCAL_URL!"
    goto :done
)

REM Find a free port without terminating the program that owns another port.
for /L %%Q in (%PORT_MIN%,1,%PORT_MAX%) do (
    if not defined PORT (
        set "PORT_IN_USE="
        for /f "tokens=5" %%P in ('netstat -ano -p tcp ^| findstr /C:":%%Q " ^| findstr "LISTENING"') do set "PORT_IN_USE=%%P"
        if not defined PORT_IN_USE set "PORT=%%Q"
    )
)

if not defined PORT (
    echo.
    echo ============================================================
    echo   ERROR - NO FREE SERVER PORT FOUND
    echo ============================================================
    echo.
    echo PriceMaster checked ports %PORT_MIN% through %PORT_MAX%.
    echo They are all currently in use.
    echo Close an unused program/server and try again.
    echo.
    goto :failed
)

set "LOCAL_URL=http://127.0.0.1:!PORT!/index.html"
set "HEALTH_URL=http://127.0.0.1:!PORT!/api/local-health"
set "FW_RULE=PriceMaster Main Server !PORT!"

if not "!PORT!"=="8765" (
    echo.
    echo [INFO] Port 8765 is already being used by another program.
    echo        PriceMaster will safely use port !PORT! instead.
    echo        No existing program will be stopped.
)

REM Prefer the one-time restricted range rule created by SETUP_SERVER_PC_ONCE.bat.
REM If setup was skipped, create only the selected-port rule as a safe fallback.
netsh advfirewall firewall show rule name="PriceMaster Main Server LAN 8765-8795" >nul 2>&1
if errorlevel 1 (
    netsh advfirewall firewall show rule name="!FW_RULE!" >nul 2>&1
    if errorlevel 1 (
        echo.
        echo [SETUP] One-time Windows Firewall permission is required for port !PORT!.
        echo         Approve the Administrator prompt if Windows asks.
        powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'netsh.exe' -Verb RunAs -Wait -ArgumentList @('advfirewall','firewall','add','rule','name=PriceMaster Main Server !PORT!','dir=in','action=allow','protocol=TCP','localport=!PORT!','remoteip=LocalSubnet,100.64.0.0/10','profile=any')" >nul 2>&1
    )
)

echo.
echo ============================================================
echo       PRICEMASTER - MAIN SERVER / BROWSER CLIENT MODE
echo ============================================================
echo.
echo This computer hosts PriceMaster.
echo Other computers do NOT need this ZIP or Python.
echo They only open the client URL shown by the server.
echo.
echo Selected server port: !PORT!
echo Main PC:
echo   !LOCAL_URL!
echo.
echo Keep this window and this PC running while clients use PriceMaster.
echo Main-PC admin dashboard: http://127.0.0.1:!PORT!/admin.html
echo.

set "PRICEMASTER_PORT=!PORT!"
set "PRICEMASTER_HOST=0.0.0.0"
REM Keep writable caches local even when the application itself is opened from a NAS/UNC share.
set "PRICEMASTER_CACHE_DIR=%LOCALAPPDATA%\NunesPriceMaster\cache"
if not exist "!PRICEMASTER_CACHE_DIR!" mkdir "!PRICEMASTER_CACHE_DIR!" >nul 2>&1

REM Prefer the requested/known 3.12 runtime, then fall back safely.
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 goto :run_py312
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 goto :run_py3
python -c "import sys" >nul 2>&1
if not errorlevel 1 goto :run_python

if exist "%LocalAppData%\Programs\Python\Python312\python.exe" goto :run_user312
if exist "%ProgramFiles%\Python312\python.exe" goto :run_machine312

echo.
echo ============================================================
echo   PYTHON NOT FOUND ON THE MAIN SERVER PC
echo ============================================================
echo.
echo Client PCs do NOT need Python.
echo Only this main server PC needs Python 3.12.
echo Run SETUP_SERVER_PC_ONCE.bat, then start PriceMaster again.
echo.
goto :failed

:run_py312
py -3.12 "!ROOT!\server.py"
goto :after_server

:run_py3
py -3 "!ROOT!\server.py"
goto :after_server

:run_python
python "!ROOT!\server.py"
goto :after_server

:run_user312
"%LocalAppData%\Programs\Python\Python312\python.exe" "!ROOT!\server.py"
goto :after_server

:run_machine312
"%ProgramFiles%\Python312\python.exe" "!ROOT!\server.py"
goto :after_server

:after_server
set "EXITCODE=!ERRORLEVEL!"
if not "!EXITCODE!"=="0" (
    echo.
    echo PriceMaster stopped with error code !EXITCODE!.
    goto :failed
)
goto :done

:failed
if /I not "%PRICEMASTER_OPEN_BROWSER%"=="0" pause
popd
endlocal
exit /b 1

:done
popd
endlocal
