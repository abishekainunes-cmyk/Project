\
import os
from pathlib import Path
ROOT = Path(__file__).resolve().parent
ENV = ROOT / "SEARCH_API_KEYS.env"

def read_env():
    values = {}
    if ENV.exists():
        for raw in ENV.read_text(encoding="utf-8-sig").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            values[k.strip()] = v.strip().strip('"').strip("'")
    return values

values = read_env()
print("============================================================")
print(" PRICEMASTER V16.5 - SEARCH API KEY CHECK")
print("============================================================")
for key, name in [
    ("SERPER_API_KEY", "Serper - Google web + images"),
    ("EXA_API_KEY", "Exa - semantic web discovery"),
    ("TAVILY_API_KEY", "Tavily - wider fallback/deep search"),
    ("FIRECRAWL_API_KEY", "Firecrawl - final deep web discovery"),
]:
    value = os.environ.get(key) or values.get(key, "")
    print(f"[{'OK' if value else '--'}] {name}: {'configured' if value else 'not configured'}")
print()
print("This check does NOT call the APIs and does NOT use credits.")
print("Missing keys are allowed; PriceMaster keeps its existing fallbacks.")
