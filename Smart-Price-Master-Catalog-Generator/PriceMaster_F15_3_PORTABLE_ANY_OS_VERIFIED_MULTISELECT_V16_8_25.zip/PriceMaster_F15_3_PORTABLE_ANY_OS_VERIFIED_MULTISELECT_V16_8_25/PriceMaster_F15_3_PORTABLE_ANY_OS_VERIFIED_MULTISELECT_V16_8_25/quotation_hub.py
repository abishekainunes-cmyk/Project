"""Integrated NUNES Quotation / Price file browser for PriceMaster.

Uses only Python's standard library so PriceMaster keeps the same one-click startup.
The file index is cached on disk, kept warm in memory, and refreshed in the
background. Internal folder names are never exposed to the UI.
"""
from __future__ import annotations

import html
import hashlib
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qs
from xml.etree import ElementTree as ET

APP_VERSION = "2.5-portable-any-os"
_DEFAULT_ROOT_PATHS = [
    r"\\DESKTOP-F8G3T2C\FinalApp\overall quotation",
    r"\\DESKTOP-F8G3T2C\FinalApp\Quotations",
]

def _quotation_root_paths():
    """Quotation roots can be customized on any OS without changing code."""
    raw = os.environ.get("PRICEMASTER_QUOTATION_ROOTS", "").strip()
    if raw:
        return [os.path.expanduser(x.strip()) for x in raw.split(os.pathsep) if x.strip()]
    cfg = Path(__file__).resolve().parent / "quotation_roots.txt"
    if cfg.is_file():
        try:
            rows = []
            for line in cfg.read_text(encoding="utf-8-sig").splitlines():
                value = line.strip()
                if value and not value.startswith("#"):
                    rows.append(os.path.expanduser(value))
            if rows:
                return rows
        except Exception:
            pass
    return list(_DEFAULT_ROOT_PATHS)

ROOT_PATHS = _quotation_root_paths()
SUPPORTED_EXTS = {".pdf", ".xlsx", ".xlsm", ".xls", ".docx", ".doc"}
EXCEL_EXTS = {".xlsx", ".xlsm", ".xls"}
WORD_EXTS = {".docx", ".doc"}
IGNORED_DIRS = {"__pycache__", ".git", ".venv", "venv", "$recycle.bin", "system volume information"}
QUOTATION_WORDS = ("quotation", "quote", "offer", "proposal", "proforma", "pi")
PRICE_WORDS = ("price", "rate", "cost", "costing", "calculator", "margin", "purchase")
REFRESH_SECONDS = 15
MAX_RESULTS = 500
MAX_PREVIEW_ROWS = 80
OFFICE_PREVIEW_TIMEOUT = 45

BASE_DIR = Path(__file__).resolve().parent

def _user_cache_root():
    override = os.environ.get("PRICEMASTER_CACHE_DIR", "").strip()
    if override:
        return Path(os.path.expanduser(override))
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA", "").strip()
        return (Path(local) if local else (Path.home() / "AppData" / "Local")) / "NunesPriceMaster" / "cache"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / "NunesPriceMaster" / "cache"
    xdg = os.environ.get("XDG_CACHE_HOME", "").strip()
    return (Path(os.path.expanduser(xdg)) if xdg else (Path.home() / ".cache")) / "NunesPriceMaster" / "cache"

CACHE_DIR = _user_cache_root() / "quotation_hub"
CACHE_FILE = CACHE_DIR / "quotation_file_index.json"
OFFICE_PREVIEW_DIR = CACHE_DIR / "office_previews"
ROOTS = [Path(p) for p in ROOT_PATHS]

_state_lock = threading.RLock()
_scan_lock = threading.Lock()
_started_lock = threading.Lock()
_started = False
_stop_event = threading.Event()
_office_lock_guard = threading.Lock()
_office_locks = {}
_state = {
    "items": [],
    "people": [],
    "online_roots": 0,
    "scanning": False,
    "last_scan_ts": 0.0,
    "last_scan_text": "Never",
    "scan_ms": 0,
    "error": "",
    "from_disk_cache": False,
}


def _classify(text: str) -> str:
    s = (text or "").lower()
    q = any(word in s for word in QUOTATION_WORDS)
    p = any(word in s for word in PRICE_WORDS)
    if q and p:
        return "Quotation + Price"
    if q:
        return "Quotation"
    if p:
        return "Price"
    return "Other"


def _format_name(ext: str) -> str:
    if ext == ".pdf":
        return "PDF"
    if ext in EXCEL_EXTS:
        return "Excel"
    if ext in WORD_EXTS:
        return "Word"
    return "File"


def _root_for_source(source):
    try:
        idx = int(source)
    except (TypeError, ValueError):
        raise ValueError("Invalid source")
    if idx < 0 or idx >= len(ROOTS):
        raise ValueError("Invalid source")
    return idx, ROOTS[idx]


def safe_path(source, rel: str) -> Path:
    _, root = _root_for_source(source)
    rel = str(rel or "").replace("/", os.sep).replace("\\", os.sep).lstrip("/\\")
    root_abs = os.path.abspath(os.path.normpath(str(root)))
    candidate = os.path.abspath(os.path.normpath(os.path.join(root_abs, rel)))
    try:
        if os.path.commonpath([os.path.normcase(root_abs), os.path.normcase(candidate)]) != os.path.normcase(root_abs):
            raise PermissionError("Path is outside quotation root")
    except ValueError as exc:
        raise PermissionError("Invalid path") from exc
    return Path(candidate)


def _load_disk_cache():
    try:
        if not CACHE_FILE.exists():
            return
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        if payload.get("roots") != ROOT_PATHS:
            return
        with _state_lock:
            _state.update({
                "items": payload.get("items") or [],
                "people": payload.get("people") or [],
                "online_roots": int(payload.get("online_roots", 0) or 0),
                "last_scan_ts": float(payload.get("last_scan_ts", 0) or 0),
                "last_scan_text": payload.get("last_scan_text", "Cached"),
                "scan_ms": int(payload.get("scan_ms", 0) or 0),
                "from_disk_cache": True,
            })
    except Exception:
        pass


def _save_disk_cache(snapshot):
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CACHE_FILE.with_suffix(".tmp")
        payload = {
            "roots": ROOT_PATHS,
            "items": snapshot["items"],
            "people": snapshot["people"],
            "online_roots": snapshot["online_roots"],
            "last_scan_ts": snapshot["last_scan_ts"],
            "last_scan_text": snapshot["last_scan_text"],
            "scan_ms": snapshot["scan_ms"],
        }
        tmp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, CACHE_FILE)
    except Exception:
        pass


def _scan_supported_files():
    started = time.perf_counter()
    items = []
    people = set()
    online_roots = 0
    root_errors = []

    for source_idx, root in enumerate(ROOTS):
        root_s = str(root)
        root_opened = False
        stack = [(root_s, "")]
        while stack:
            abs_dir, rel_dir = stack.pop()
            try:
                with os.scandir(abs_dir) as it:
                    if abs_dir == root_s:
                        root_opened = True
                    for entry in it:
                        name = entry.name
                        if not name or name.startswith(".") or name.startswith("~$"):
                            continue
                        try:
                            if entry.is_dir(follow_symlinks=False):
                                if name.lower() in IGNORED_DIRS:
                                    continue
                                child_rel = f"{rel_dir}/{name}" if rel_dir else name
                                stack.append((entry.path, child_rel))
                                people.add(child_rel.split("/", 1)[0])
                                continue
                            if not entry.is_file(follow_symlinks=False):
                                continue
                        except OSError:
                            continue

                        ext = os.path.splitext(name)[1].lower()
                        if ext not in SUPPORTED_EXTS:
                            continue
                        try:
                            st = entry.stat(follow_symlinks=False)
                        except OSError:
                            continue

                        rel = f"{rel_dir}/{name}" if rel_dir else name
                        person = rel_dir.split("/", 1)[0] if rel_dir else "Main"
                        file_type = _classify(rel)
                        # Keep hidden internal paths in the server index for accurate
                        # search/path resolution, but the browser receives only person.
                        items.append({
                            "name": name,
                            "rel": rel,
                            "source": source_idx,
                            "person": person,
                            "ext": ext,
                            "format": _format_name(ext),
                            "type": file_type,
                            "size": st.st_size,
                            "modified_ts": st.st_mtime,
                            "modified": datetime.fromtimestamp(st.st_mtime).strftime("%d-%m-%Y %I:%M %p"),
                            "previewable": ext in {".pdf", ".xlsx", ".xlsm", ".docx"},
                            "_search": (name + " " + rel_dir + " " + file_type + " " + _format_name(ext)).casefold(),
                        })
            except (OSError, PermissionError) as exc:
                if abs_dir == root_s:
                    root_errors.append(str(exc))
                    break
                continue
        if root_opened:
            online_roots += 1

    items.sort(key=lambda x: x["modified_ts"], reverse=True)
    elapsed_ms = int((time.perf_counter() - started) * 1000)
    now = time.time()
    return {
        "items": items,
        "people": sorted(people, key=str.lower),
        "online_roots": online_roots,
        "last_scan_ts": now,
        "last_scan_text": datetime.fromtimestamp(now).strftime("%d-%m-%Y %I:%M:%S %p"),
        "scan_ms": elapsed_ms,
        "error": " | ".join(root_errors[:2]),
    }


def scan_now():
    if not _scan_lock.acquire(blocking=False):
        return False
    with _state_lock:
        _state["scanning"] = True
        _state["error"] = ""
    try:
        snapshot = _scan_supported_files()
        # Search blobs are useful only in RAM; don't persist them to disk.
        disk_snapshot = dict(snapshot)
        disk_snapshot["items"] = [{k: v for k, v in x.items() if k != "_search"} for x in snapshot["items"]]
        with _state_lock:
            _state.update(snapshot)
            _state["from_disk_cache"] = False
        _save_disk_cache(disk_snapshot)
    except Exception as exc:
        with _state_lock:
            _state["error"] = str(exc)
    finally:
        with _state_lock:
            _state["scanning"] = False
        _scan_lock.release()
    return True


def trigger_scan():
    if _scan_lock.locked():
        return False
    threading.Thread(target=scan_now, name="pricemaster-quotation-rescan", daemon=True).start()
    return True


def _background_indexer():
    scan_now()
    while not _stop_event.wait(REFRESH_SECONDS):
        scan_now()


def start_background_services():
    global _started
    with _started_lock:
        if _started:
            return
        _started = True
        _load_disk_cache()
        # Add search blobs to cache-loaded rows once, without touching the network.
        with _state_lock:
            for x in _state["items"]:
                if "_search" not in x:
                    x["_search"] = (x.get("name", "") + " " + x.get("person", "") + " " + x.get("type", "") + " " + x.get("format", "")).casefold()
        threading.Thread(target=_background_indexer, name="pricemaster-quotation-indexer", daemon=True).start()


def _snapshot():
    with _state_lock:
        return {
            "items": list(_state["items"]),
            "people": list(_state["people"]),
            "online_roots": int(_state["online_roots"]),
            "scanning": bool(_state["scanning"]),
            "last_scan_text": _state["last_scan_text"],
            "scan_ms": int(_state["scan_ms"] or 0),
            "error": _state["error"],
            "from_disk_cache": bool(_state["from_disk_cache"]),
        }


def _json(handler, payload, status=200):
    return handler.json_response(payload, status)


def _escape_attr(value):
    return html.escape(str(value or ""), quote=True)


def _html_response(handler, body: str, status=200):
    data = body.encode("utf-8", errors="replace")
    handler.send_response(status)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.end_headers()
    handler.wfile.write(data)


def _preview_shell(title: str, inner: str) -> str:
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>html,body{{margin:0;background:#fff;color:#10233f;font-family:Segoe UI,Arial,sans-serif}}.wrap{{padding:18px 20px}}h1{{font-size:16px;margin:0 0 14px}}.note{{font-size:11px;color:#60738d;margin:0 0 14px}}table{{border-collapse:collapse;width:100%;font-size:11px}}td,th{{border:1px solid #dce6f2;padding:7px 8px;vertical-align:top;text-align:left}}tr:nth-child(even){{background:#f8fbff}}.doc p{{font-size:12px;line-height:1.55;margin:0 0 9px}}.empty{{min-height:300px;display:grid;place-items:center;text-align:center;color:#60738d}}.empty strong{{display:block;color:#10233f;font-size:18px;margin-bottom:7px}}</style></head><body><div class='wrap'><h1>{html.escape(title)}</h1>{inner}</div></body></html>"""


def _xlsx_preview(fp: Path) -> str:
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    shared = []
    with zipfile.ZipFile(fp, "r") as zf:
        if "xl/sharedStrings.xml" in zf.namelist():
            root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", ns):
                text_parts = [t.text or "" for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")]
                shared.append("".join(text_parts))
        sheet_name = "xl/worksheets/sheet1.xml"
        if sheet_name not in zf.namelist():
            candidates = sorted(n for n in zf.namelist() if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
            if not candidates:
                raise ValueError("No worksheet found")
            sheet_name = candidates[0]
        root = ET.fromstring(zf.read(sheet_name))
        rows = []
        for row in root.findall(".//m:sheetData/m:row", ns)[:MAX_PREVIEW_ROWS]:
            vals = []
            for c in row.findall("m:c", ns):
                ctype = c.attrib.get("t", "")
                v = c.find("m:v", ns)
                inline = c.find("m:is", ns)
                value = ""
                if inline is not None:
                    value = "".join(t.text or "" for t in inline.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"))
                elif v is not None and v.text is not None:
                    raw = v.text
                    if ctype == "s":
                        try:
                            value = shared[int(raw)]
                        except Exception:
                            value = raw
                    else:
                        value = raw
                vals.append(value)
            rows.append(vals)
    max_cols = min(max((len(r) for r in rows), default=0), 30)
    if not rows:
        return _preview_shell(fp.name, "<div class='empty'><div><strong>Excel file is empty</strong>No visible rows were found.</div></div>")
    table_rows = []
    for row in rows:
        cells = "".join(f"<td>{html.escape(str(v))}</td>" for v in row[:max_cols])
        table_rows.append("<tr>" + cells + "</tr>")
    return _preview_shell(fp.name, "<p class='note'>Fast preview of the first worksheet. Original file is unchanged.</p><table>" + "".join(table_rows) + "</table>")


def _docx_preview(fp: Path) -> str:
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with zipfile.ZipFile(fp, "r") as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    paras = []
    for p in root.findall(".//w:p", ns):
        text_parts = [t.text or "" for t in p.findall(".//w:t", ns)]
        txt = "".join(text_parts).strip()
        if txt:
            paras.append(txt)
        if len(paras) >= 180:
            break
    if not paras:
        return _preview_shell(fp.name, "<div class='empty'><div><strong>No readable text</strong>Open the file to view its full formatting.</div></div>")
    content = "<div class='doc'>" + "".join(f"<p>{html.escape(p)}</p>" for p in paras) + "</div>"
    return _preview_shell(fp.name, content)


def _unsupported_preview(fp: Path, label: str) -> str:
    return _preview_shell(fp.name, f"<div class='empty'><div><strong>{html.escape(label)} preview</strong>This older file format is listed and searchable. Double-click it or use Download to open it in its normal application.</div></div>")


def _office_lock(key: str):
    # Prevent the same Word/Excel file being converted twice when the user
    # single-clicks and then immediately double-clicks it.
    with _office_lock_guard:
        lock = _office_locks.get(key)
        if lock is None:
            lock = threading.Lock()
            _office_locks[key] = lock
        return lock


def _find_libreoffice():
    candidates = []
    if sys.platform == "darwin":
        candidates += [
            "/Applications/LibreOffice.app/Contents/MacOS/soffice",
            os.path.expanduser("~/Applications/LibreOffice.app/Contents/MacOS/soffice"),
        ]
    elif os.name == "nt":
        for base in (os.environ.get("PROGRAMFILES", ""), os.environ.get("PROGRAMFILES(X86)", "")):
            if base:
                candidates.append(os.path.join(base, "LibreOffice", "program", "soffice.exe"))
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            candidates.append(found)
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    return ""

def _libreoffice_preview_pdf(fp: Path):
    """Best-effort Office preview on macOS/Linux (and Windows fallback) via LibreOffice."""
    executable = _find_libreoffice()
    if not executable:
        return None, "LibreOffice is not installed; open the Office file natively instead."
    try:
        st = fp.stat()
        source_id = os.path.abspath(str(fp))
        mtime_ns = getattr(st, "st_mtime_ns", int(st.st_mtime * 1_000_000_000))
        signature = f"lo|{source_id}|{st.st_size}|{mtime_ns}"
        key = hashlib.sha1(signature.encode("utf-8", errors="surrogatepass")).hexdigest()
        OFFICE_PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
        out_pdf = OFFICE_PREVIEW_DIR / f"{key}.pdf"
        if out_pdf.exists() and out_pdf.stat().st_size > 100:
            return out_pdf, ""
        work = OFFICE_PREVIEW_DIR / (key + "_lo")
        work.mkdir(parents=True, exist_ok=True)
        staged = work / ("source" + fp.suffix.lower())
        shutil.copyfile(fp, staged)
        proc = subprocess.run(
            [executable, "--headless", "--convert-to", "pdf", "--outdir", str(work), str(staged)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=OFFICE_PREVIEW_TIMEOUT,
        )
        made = work / "source.pdf"
        if proc.returncode != 0 or not made.exists() or made.stat().st_size <= 100:
            detail = (proc.stderr or proc.stdout or "LibreOffice could not render this file").strip()
            return None, detail[-1200:]
        shutil.copyfile(made, out_pdf)
        return out_pdf, ""
    except Exception as exc:
        return None, str(exc)
    finally:
        try:
            if 'work' in locals():
                shutil.rmtree(work, ignore_errors=True)
        except Exception:
            pass

def _office_preview_pdf(fp: Path):
    """Render Word/Excel with Microsoft Office and cache the result as PDF.

    The original quotation is never modified. The source is copied to the local
    preview cache first, then the installed Word/Excel application exports it.
    The cache key includes path + size + modified time, so repeat previews are
    immediate and a changed source automatically gets a new preview.
    """
    if os.name != "nt":
        return _libreoffice_preview_pdf(fp)

    ext = fp.suffix.lower()
    if ext not in (EXCEL_EXTS | WORD_EXTS):
        return None, "Not an Office file"

    try:
        st = fp.stat()
    except OSError as exc:
        return None, str(exc)

    source_id = os.path.normcase(os.path.abspath(str(fp)))
    mtime_ns = getattr(st, "st_mtime_ns", int(st.st_mtime * 1_000_000_000))
    signature = f"{source_id}|{st.st_size}|{mtime_ns}"
    key = hashlib.sha1(signature.encode("utf-8", errors="surrogatepass")).hexdigest()
    OFFICE_PREVIEW_DIR.mkdir(parents=True, exist_ok=True)
    out_pdf = OFFICE_PREVIEW_DIR / f"{key}.pdf"
    if out_pdf.exists() and out_pdf.stat().st_size > 100:
        return out_pdf, ""

    with _office_lock(key):
        if out_pdf.exists() and out_pdf.stat().st_size > 100:
            return out_pdf, ""

        staged = OFFICE_PREVIEW_DIR / f"{key}{ext}"
        temp_pdf = OFFICE_PREVIEW_DIR / f"{key}.building.pdf"
        try:
            # Local staging makes Office rendering noticeably more reliable and
            # avoids repeated UNC reads while Excel/Word parses the document.
            shutil.copyfile(fp, staged)
            try:
                if temp_pdf.exists():
                    temp_pdf.unlink()
            except OSError:
                pass

            ps = r"""
$ErrorActionPreference = 'Stop'
$src = $env:PM_PREVIEW_SRC
$dst = $env:PM_PREVIEW_DST
$ext = [System.IO.Path]::GetExtension($src).ToLowerInvariant()
if ($ext -in @('.xlsx','.xlsm','.xls')) {
    $app = $null; $book = $null
    try {
        $app = New-Object -ComObject Excel.Application
        $app.Visible = $false
        $app.DisplayAlerts = $false
        $app.AskToUpdateLinks = $false
        $book = $app.Workbooks.Open($src, 0, $true)
        $book.ExportAsFixedFormat(0, $dst)
    } finally {
        if ($book -ne $null) {
            try { $book.Close($false) } catch {}
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($book)
        }
        if ($app -ne $null) {
            try { $app.Quit() } catch {}
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
        }
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    }
} elseif ($ext -in @('.docx','.doc')) {
    $app = $null; $doc = $null
    try {
        $app = New-Object -ComObject Word.Application
        $app.Visible = $false
        $app.DisplayAlerts = 0
        $doc = $app.Documents.Open($src, $false, $true, $false)
        $doc.ExportAsFixedFormat($dst, 17)
    } finally {
        if ($doc -ne $null) {
            try { $doc.Close($false) } catch {}
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($doc)
        }
        if ($app -ne $null) {
            try { $app.Quit() } catch {}
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
        }
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    }
} else {
    throw 'Unsupported Office format'
}
if (-not (Test-Path -LiteralPath $dst)) { throw 'Office did not create the preview PDF' }
"""
            env = os.environ.copy()
            env["PM_PREVIEW_SRC"] = str(staged)
            env["PM_PREVIEW_DST"] = str(temp_pdf)
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            proc = subprocess.run(
                ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-STA",
                 "-ExecutionPolicy", "Bypass", "-Command", ps],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=OFFICE_PREVIEW_TIMEOUT,
                env=env,
                creationflags=creationflags,
            )
            if proc.returncode != 0 or not temp_pdf.exists() or temp_pdf.stat().st_size <= 100:
                detail = (proc.stderr or proc.stdout or "Microsoft Office could not render this file").strip()
                raise RuntimeError(detail[-1200:])
            os.replace(temp_pdf, out_pdf)
            return out_pdf, ""
        except Exception as exc:
            try:
                (CACHE_DIR / "office_preview_last_error.txt").write_text(
                    str(exc), encoding="utf-8", errors="replace"
                )
            except Exception:
                pass
            return None, str(exc)
        finally:
            for candidate in (staged, temp_pdf):
                try:
                    if candidate.exists():
                        candidate.unlink()
                except OSError:
                    pass


def _send_file(handler, fp: Path, inline=True, display_name=None):
    size = fp.stat().st_size
    mime = mimetypes.guess_type(fp.name)[0] or "application/octet-stream"
    if fp.suffix.lower() == ".pdf":
        mime = "application/pdf"
    range_header = handler.headers.get("Range", "") if inline else ""
    start = 0
    end = size - 1
    status = 200
    if range_header:
        match = re.match(r"bytes=(\d*)-(\d*)", range_header.strip())
        if match:
            if match.group(1):
                start = min(int(match.group(1)), max(0, size - 1))
            if match.group(2):
                end = min(int(match.group(2)), size - 1)
            if end < start:
                end = start
            status = 206
    length = max(0, end - start + 1)
    safe_name = (display_name or fp.name).replace('"', "")
    handler.send_response(status)
    handler.send_header("Content-Type", mime)
    handler.send_header("Content-Length", str(length))
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Disposition", ("inline" if inline else "attachment") + f'; filename="{safe_name}"')
    if inline:
        handler.send_header("Cache-Control", "private, max-age=86400")
    else:
        handler.send_header("Cache-Control", "no-store")
    if status == 206:
        handler.send_header("Content-Range", f"bytes {start}-{end}/{size}")
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.end_headers()
    with open(fp, "rb") as f:
        f.seek(start)
        remaining = length
        while remaining > 0:
            chunk = f.read(min(256 * 1024, remaining))
            if not chunk:
                break
            try:
                handler.wfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError):
                break
            remaining -= len(chunk)


def _get_params(parsed):
    return parse_qs(parsed.query, keep_blank_values=True)


def handle_get(handler, parsed) -> bool:
    """Handle qhub GET endpoints. Returns True when the request was handled."""
    path = parsed.path
    if not path.startswith("/api/qhub/"):
        return False

    if path == "/api/qhub/status":
        s = _snapshot()
        items = s["items"]
        return _json(handler, {
            "ok": True,
            "version": APP_VERSION,
            "online": s["online_roots"] > 0,
            "onlineRoots": s["online_roots"],
            "rootCount": len(ROOTS),
            "scanning": s["scanning"],
            "files": len(items),
            "quotations": sum(1 for x in items if "Quotation" in x.get("type", "")),
            "prices": sum(1 for x in items if "Price" in x.get("type", "")),
            "pdfs": sum(1 for x in items if x.get("ext") == ".pdf"),
            "excels": sum(1 for x in items if x.get("ext") in EXCEL_EXTS),
            "words": sum(1 for x in items if x.get("ext") in WORD_EXTS),
            "people": s["people"],
            "lastScan": s["last_scan_text"],
            "scanMs": s["scan_ms"],
            "error": s["error"],
            "fromDiskCache": s["from_disk_cache"],
        }) is None or True

    if path == "/api/qhub/files":
        params = _get_params(parsed)
        if params.get("refresh", [""])[0] == "1":
            trigger_scan()
        q = params.get("q", [""])[0].strip().casefold()
        typ = params.get("type", ["all"])[0].strip().lower()
        person = params.get("person", ["all"])[0].strip()
        try:
            limit = min(max(int(params.get("limit", [str(MAX_RESULTS)])[0]), 1), 2000)
        except Exception:
            limit = MAX_RESULTS
        s = _snapshot()
        results = []
        for x in s["items"]:
            hay = x.get("_search") or (x.get("name", "") + " " + x.get("person", "") + " " + x.get("type", "") + " " + x.get("format", "")).casefold()
            if q and q not in hay:
                continue
            xtype = x.get("type", "")
            if typ == "quotation" and "Quotation" not in xtype:
                continue
            if typ == "price" and "Price" not in xtype:
                continue
            if typ == "other" and xtype != "Other":
                continue
            if person != "all" and x.get("person") != person:
                continue
            results.append({k: v for k, v in x.items() if k not in {"_search"}})
        return _json(handler, {
            "ok": True,
            "items": results[:limit],
            "total": len(results),
            "people": s["people"],
            "scanning": s["scanning"],
            "online": s["online_roots"] > 0,
            "scanMs": s["scan_ms"],
        }) is None or True

    if path in {"/api/qhub/preview", "/api/qhub/download"}:
        params = _get_params(parsed)
        try:
            fp = safe_path(params.get("source", ["0"])[0], params.get("path", [""])[0])
        except Exception as exc:
            _json(handler, {"ok": False, "error": str(exc)}, 400)
            return True
        if not fp.exists() or not fp.is_file() or fp.suffix.lower() not in SUPPORTED_EXTS:
            _json(handler, {"ok": False, "error": "File not found"}, 404)
            return True
        ext = fp.suffix.lower()
        if path == "/api/qhub/download":
            _send_file(handler, fp, inline=False)
            return True
        try:
            if ext == ".pdf":
                _send_file(handler, fp, inline=True)
            elif ext in EXCEL_EXTS or ext in WORD_EXTS:
                preview_pdf, office_error = _office_preview_pdf(fp)
                if preview_pdf is not None:
                    _send_file(handler, preview_pdf, inline=True, display_name=fp.stem + " - Preview.pdf")
                elif ext in {".xlsx", ".xlsm"}:
                    _html_response(handler, _xlsx_preview(fp))
                elif ext == ".docx":
                    _html_response(handler, _docx_preview(fp))
                elif ext == ".xls":
                    _html_response(handler, _unsupported_preview(fp, "Excel .xls"))
                else:
                    _html_response(handler, _unsupported_preview(fp, "Word .doc"))
        except Exception as exc:
            _html_response(handler, _preview_shell(fp.name, f"<div class='empty'><div><strong>Preview unavailable</strong>{html.escape(str(exc))}</div></div>"), 200)
        return True

    _json(handler, {"ok": False, "error": "Unknown quotation endpoint"}, 404)
    return True



def handle_head(handler, parsed) -> bool:
    path = parsed.path
    if path not in {"/api/qhub/preview", "/api/qhub/download"}:
        return False
    params = _get_params(parsed)
    try:
        fp = safe_path(params.get("source", ["0"])[0], params.get("path", [""])[0])
    except Exception:
        handler.send_response(400)
        handler.end_headers()
        return True
    if not fp.exists() or not fp.is_file() or fp.suffix.lower() not in SUPPORTED_EXTS:
        handler.send_response(404)
        handler.end_headers()
        return True
    ext = fp.suffix.lower()
    if path == "/api/qhub/preview" and ext not in {".pdf"}:
        # GET will use Word/Excel itself to make a high-fidelity cached PDF.
        # Do not start Office during HEAD: this keeps UI interactions fast.
        handler.send_response(200)
        handler.send_header("Content-Type", "application/pdf")
        handler.send_header("Cache-Control", "private, max-age=86400")
        handler.end_headers()
        return True
    size = fp.stat().st_size
    mime = mimetypes.guess_type(fp.name)[0] or "application/octet-stream"
    if ext == ".pdf":
        mime = "application/pdf"
    safe_name = fp.name.replace('"', "")
    handler.send_response(200)
    handler.send_header("Content-Type", mime)
    handler.send_header("Content-Length", str(size))
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Disposition", ("inline" if path.endswith("preview") else "attachment") + f'; filename="{safe_name}"')
    handler.end_headers()
    return True

def _read_json_body(handler, max_bytes=1024 * 1024):
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length <= 0 or length > max_bytes:
        return {}
    return json.loads(handler.rfile.read(length).decode("utf-8"))


def handle_post(handler, parsed) -> bool:
    path = parsed.path
    if not path.startswith("/api/qhub/"):
        return False

    if path == "/api/qhub/refresh":
        started = trigger_scan()
        _json(handler, {"ok": True, "started": started, "scanning": True})
        return True

    if path in {"/api/qhub/open-native", "/api/qhub/reveal"}:
        try:
            body = _read_json_body(handler)
            fp = safe_path(body.get("source", 0), body.get("path", ""))
            if not fp.exists() or fp.suffix.lower() not in SUPPORTED_EXTS:
                raise FileNotFoundError("File not found")
            if os.name == "nt":
                if path.endswith("open-native"):
                    os.startfile(str(fp))
                else:
                    subprocess.Popen(["explorer", "/select,", str(fp)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(fp)] if path.endswith("open-native") else ["open", "-R", str(fp)])
            else:
                subprocess.Popen(["xdg-open", str(fp if path.endswith("open-native") else fp.parent)])
            _json(handler, {"ok": True})
        except Exception as exc:
            _json(handler, {"ok": False, "error": str(exc)}, 400)
        return True

    _json(handler, {"ok": False, "error": "Unknown quotation endpoint"}, 404)
    return True
