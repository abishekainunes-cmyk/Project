Option Explicit
Dim fso, sh, folder, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = sh.ExpandEnvironmentStrings("%TEMP%")
cmd = "cmd.exe /d /c pushd " & Chr(34) & folder & Chr(34) & " && call START_PRICEMASTER.bat"
sh.Run cmd, 1, True
