Instant Data Scraper CSV integration

1. Start PriceMaster using START_PRICEMASTER.bat.
2. Click INSTANT DATA SCRAPER beside INDIAMART SEARCH.
3. Install the official extension using the link, if necessary.
4. Open IndiaMART search from the panel. Run the extension in Chrome.
5. Review the detected list, load more pages if needed, and export CSV.
6. Import that CSV in PriceMaster. Select the source columns for Product name,
   Company, Price, product URL, image URL and any optional details.
7. Check the preview, then click Show imported results.

The first 25 rows appear; SHOW MORE RESULTS adds 25 more available rows.
The existing same-company/same-price duplicate rule is applied.
Blank or unmapped fields are not invented. Non-IndiaMART product links are
excluded. Import only exports of IndiaMART product results in this panel.

Import is limited to 5 MB and 5,000 rows per file. The original CSV is retained
on your computer. Imported results are in the current tab only; re-import
after a reload or another search. Exports are not sent to a new cloud service.

This is an import bridge for the official extension, not a bundled copy of
the extension or a way to launch it automatically. It does not fix an upstream
HTTP 400 response or bypass access checks. HTTP 200 is a successful HTTP
response, but its content may still be an empty result or a verification page.
Use the extension only on pages that open normally in your browser.

Official extension:
https://chromewebstore.google.com/detail/instant-data-scraper/ofaokhiedipichpaobibbnahnkdoiiah
