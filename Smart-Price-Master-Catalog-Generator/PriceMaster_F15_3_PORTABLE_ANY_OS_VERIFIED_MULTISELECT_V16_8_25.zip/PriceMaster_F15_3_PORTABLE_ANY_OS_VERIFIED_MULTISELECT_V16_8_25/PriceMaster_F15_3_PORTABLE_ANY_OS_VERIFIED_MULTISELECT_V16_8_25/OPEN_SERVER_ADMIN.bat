@echo off
setlocal
pushd "%~dp0" >nul 2>&1
set "PORT=8765"
if exist "SERVER_PORT.txt" set /p PORT=<"SERVER_PORT.txt"
start "" "http://127.0.0.1:%PORT%/admin.html"
popd
endlocal
