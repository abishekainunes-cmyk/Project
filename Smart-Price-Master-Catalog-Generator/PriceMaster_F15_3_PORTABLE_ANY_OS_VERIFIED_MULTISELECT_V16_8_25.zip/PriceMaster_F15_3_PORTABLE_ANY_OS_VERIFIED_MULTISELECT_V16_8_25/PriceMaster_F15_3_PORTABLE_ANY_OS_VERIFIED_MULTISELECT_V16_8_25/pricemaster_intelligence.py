"""PriceMaster office intelligence / operations layer.

Built only from Python's standard library so the main server PC does not need
extra packages.  It keeps the existing PriceMaster workflow untouched while
adding shared client tracking, supplier/price history, diagnostics and backup.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import statistics
import threading
import time
import uuid
import zipfile
from pathlib import Path

_DB_LOCK = threading.RLock()
_RUNTIME_DIR = None
_DB_PATH = None
_BACKUP_DIR = None


def configure(runtime_dir):
    global _RUNTIME_DIR, _DB_PATH, _BACKUP_DIR
    _RUNTIME_DIR = Path(runtime_dir)
    _RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    _DB_PATH = _RUNTIME_DIR / "pricemaster_brain.sqlite3"
    _BACKUP_DIR = _RUNTIME_DIR / "backups"
    _BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    _ensure_db()
    return str(_DB_PATH)


def _connect():
    if _DB_PATH is None:
        raise RuntimeError("PriceMaster intelligence store is not configured")
    conn = sqlite3.connect(str(_DB_PATH), timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=15000")
    return conn


def _ensure_db():
    with _DB_LOCK:
        conn = _connect()
        try:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS clients (
                client_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL,
                ip TEXT,
                user_agent TEXT,
                search_count INTEGER NOT NULL DEFAULT 0,
                last_query TEXT DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_clients_last_seen ON clients(last_seen DESC);

            CREATE TABLE IF NOT EXISTS search_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT UNIQUE,
                client_id TEXT,
                query TEXT,
                source TEXT,
                started_at REAL,
                finished_at REAL,
                duration_ms INTEGER DEFAULT 0,
                result_count INTEGER DEFAULT 0,
                status TEXT,
                cache_status TEXT DEFAULT '',
                details_json TEXT DEFAULT '{}'
            );
            CREATE INDEX IF NOT EXISTS idx_search_events_started ON search_events(started_at DESC);

            CREATE TABLE IF NOT EXISTS suppliers (
                supplier_key TEXT PRIMARY KEY,
                display_name TEXT NOT NULL,
                city TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                email TEXT DEFAULT '',
                rating TEXT DEFAULT '',
                years TEXT DEFAULT '',
                found_count INTEGER NOT NULL DEFAULT 0,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL,
                last_price TEXT DEFAULT '',
                products_json TEXT DEFAULT '[]'
            );
            CREATE INDEX IF NOT EXISTS idx_suppliers_last_seen ON suppliers(last_seen DESC);

            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT UNIQUE,
                query TEXT DEFAULT '',
                product_name TEXT NOT NULL,
                model TEXT DEFAULT '',
                supplier_key TEXT DEFAULT '',
                supplier TEXT DEFAULT '',
                price_numeric REAL,
                currency TEXT DEFAULT '',
                price_text TEXT DEFAULT '',
                observed_at REAL NOT NULL,
                source TEXT DEFAULT '',
                data_status TEXT DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_price_history_product ON price_history(product_name, model, observed_at DESC);
            CREATE INDEX IF NOT EXISTS idx_price_history_supplier ON price_history(supplier_key, observed_at DESC);

            CREATE TABLE IF NOT EXISTS product_aliases (
                alias TEXT PRIMARY KEY,
                canonical TEXT NOT NULL,
                seen_count INTEGER NOT NULL DEFAULT 1,
                last_seen REAL NOT NULL
            );
            """)
            conn.commit()
        finally:
            conn.close()


def clean_text(value):
    return re.sub(r"\s+", " ", str(value or "").strip())


def normalize_supplier(value):
    text = clean_text(value).casefold().replace("&", " and ")
    text = re.sub(r"\b(?:pvt\.?|private)\s+(?:ltd\.?|limited)\b", "", text)
    text = re.sub(r"\b(?:ltd\.?|limited|llp|inc\.?|corp\.?|corporation)\b", "", text)
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def normalize_product(value):
    text = clean_text(value).casefold()
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def parse_price(value):
    raw = clean_text(value)
    if not raw:
        return None, ""
    currency = "INR"
    upper = raw.upper()
    if "$" in raw or "USD" in upper:
        currency = "USD"
    elif "EUR" in upper or "€" in raw:
        currency = "EUR"
    elif "GBP" in upper or "£" in raw:
        currency = "GBP"
    elif "AED" in upper:
        currency = "AED"
    nums = re.findall(r"-?\d+(?:,\d{2,3})*(?:\.\d+)?", raw)
    if not nums:
        return None, currency
    try:
        return float(nums[0].replace(",", "")), currency
    except Exception:
        return None, currency


def client_seen(client_id, name, ip="", user_agent="", query="", increment_search=False):
    now = time.time()
    client_id = clean_text(client_id)[:120] or ("client-" + uuid.uuid4().hex[:12])
    name = clean_text(name)[:80] or "Office-PC"
    with _DB_LOCK:
        conn = _connect()
        try:
            old = conn.execute("SELECT search_count, first_seen FROM clients WHERE client_id=?", (client_id,)).fetchone()
            count = int(old["search_count"] if old else 0) + (1 if increment_search else 0)
            first = float(old["first_seen"] if old else now)
            conn.execute("""
                INSERT INTO clients(client_id,name,first_seen,last_seen,ip,user_agent,search_count,last_query)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(client_id) DO UPDATE SET
                    name=excluded.name,last_seen=excluded.last_seen,ip=excluded.ip,
                    user_agent=excluded.user_agent,search_count=excluded.search_count,
                    last_query=CASE WHEN excluded.last_query<>'' THEN excluded.last_query ELSE clients.last_query END
            """, (client_id, name, first, now, clean_text(ip)[:100], clean_text(user_agent)[:500], count, clean_text(query)[:300]))
            conn.commit()
        finally:
            conn.close()
    return {"clientId": client_id, "name": name, "lastSeen": now}


def list_clients(active_seconds=180):
    now = time.time()
    with _DB_LOCK:
        conn = _connect()
        try:
            rows = conn.execute("SELECT * FROM clients ORDER BY last_seen DESC LIMIT 100").fetchall()
        finally:
            conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["active"] = now - float(d.get("last_seen") or 0) <= active_seconds
        out.append(d)
    return out


def record_search(query, source, started_at, result_count=0, status="ok", client_id="", cache_status="", details=None):
    finished = time.time()
    event_id = uuid.uuid4().hex
    with _DB_LOCK:
        conn = _connect()
        try:
            conn.execute("""
                INSERT INTO search_events(event_id,client_id,query,source,started_at,finished_at,duration_ms,result_count,status,cache_status,details_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """, (
                event_id, clean_text(client_id)[:120], clean_text(query)[:400], clean_text(source)[:80],
                float(started_at or finished), finished, int(max(0, (finished-float(started_at or finished))*1000)),
                int(result_count or 0), clean_text(status)[:60], clean_text(cache_status)[:60],
                json.dumps(details or {}, ensure_ascii=False, separators=(",", ":"))[:12000]
            ))
            conn.execute("DELETE FROM search_events WHERE id NOT IN (SELECT id FROM search_events ORDER BY id DESC LIMIT 1200)")
            conn.commit()
        finally:
            conn.close()
    return event_id


def search_inspector(limit=40):
    limit = max(1, min(200, int(limit or 40)))
    with _DB_LOCK:
        conn = _connect()
        try:
            rows = conn.execute("SELECT * FROM search_events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        finally:
            conn.close()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["details"] = json.loads(d.pop("details_json", "{}") or "{}")
        except Exception:
            d["details"] = {}
        out.append(d)
    return out


def _remember_alias(query, product_name, conn, now):
    alias = normalize_product(query)
    canonical = clean_text(product_name)
    if len(alias) < 2 or not canonical:
        return
    conn.execute("""
        INSERT INTO product_aliases(alias,canonical,seen_count,last_seen) VALUES(?,?,1,?)
        ON CONFLICT(alias) DO UPDATE SET canonical=excluded.canonical, seen_count=product_aliases.seen_count+1, last_seen=excluded.last_seen
    """, (alias, canonical[:300], now))


def learn_rows(query, rows, source=""):
    if not isinstance(rows, list) or not rows:
        return {"learned": 0, "suppliers": 0}
    now = time.time()
    learned = 0
    touched_suppliers = set()
    with _DB_LOCK:
        conn = _connect()
        try:
            for row in rows[:300]:
                if not isinstance(row, dict):
                    continue
                product = clean_text(row.get("product_name"))[:350]
                if not product:
                    continue
                model = clean_text(row.get("model"))[:180]
                supplier = clean_text(row.get("supplier"))[:300]
                skey = normalize_supplier(supplier)[:300]
                price_text = clean_text(row.get("purchase_price"))[:160]
                price_num, currency = parse_price(price_text)
                row_source = clean_text(row.get("source_type") or row.get("source_sheet") or source)[:100]
                data_status = clean_text(row.get("dataStatus") or row.get("data_status") or ("live" if row_source.casefold().startswith("indiamart") else "sheet"))[:60]
                observed = float(row.get("retrieved_at") or row.get("savedAt") or now)
                # Use a day bucket so repeated office searches do not create duplicate history rows.
                day = time.strftime("%Y-%m-%d", time.localtime(observed))
                fingerprint_raw = "|".join([normalize_product(product), normalize_product(model), skey, price_text.casefold(), day, row_source.casefold()])
                import hashlib
                fp = hashlib.sha256(fingerprint_raw.encode("utf-8", errors="ignore")).hexdigest()
                cur = conn.execute("""
                    INSERT OR IGNORE INTO price_history(fingerprint,query,product_name,model,supplier_key,supplier,price_numeric,currency,price_text,observed_at,source,data_status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                """, (fp, clean_text(query)[:300], product, model, skey, supplier, price_num, currency, price_text, observed, row_source, data_status))
                if cur.rowcount:
                    learned += 1
                _remember_alias(query, product, conn, now)

                if skey and supplier:
                    touched_suppliers.add(skey)
                    old = conn.execute("SELECT products_json,found_count,first_seen FROM suppliers WHERE supplier_key=?", (skey,)).fetchone()
                    products = []
                    if old:
                        try:
                            products = json.loads(old["products_json"] or "[]")
                        except Exception:
                            products = []
                    if product not in products:
                        products.append(product)
                    products = products[-80:]
                    found_count = int(old["found_count"] if old else 0) + 1
                    first_seen = float(old["first_seen"] if old else now)
                    conn.execute("""
                        INSERT INTO suppliers(supplier_key,display_name,city,phone,email,rating,years,found_count,first_seen,last_seen,last_price,products_json)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(supplier_key) DO UPDATE SET
                            display_name=excluded.display_name,
                            city=CASE WHEN excluded.city<>'' THEN excluded.city ELSE suppliers.city END,
                            phone=CASE WHEN excluded.phone<>'' THEN excluded.phone ELSE suppliers.phone END,
                            email=CASE WHEN excluded.email<>'' THEN excluded.email ELSE suppliers.email END,
                            rating=CASE WHEN excluded.rating<>'' THEN excluded.rating ELSE suppliers.rating END,
                            years=CASE WHEN excluded.years<>'' THEN excluded.years ELSE suppliers.years END,
                            found_count=excluded.found_count,last_seen=excluded.last_seen,
                            last_price=CASE WHEN excluded.last_price<>'' THEN excluded.last_price ELSE suppliers.last_price END,
                            products_json=excluded.products_json
                    """, (
                        skey, supplier, clean_text(row.get("supplier_location") or row.get("location"))[:180],
                        clean_text(row.get("contact") or row.get("phone"))[:180], clean_text(row.get("email"))[:200],
                        clean_text(row.get("supplier_rating") or row.get("rating"))[:60], clean_text(row.get("supplier_years") or row.get("business_age") or row.get("years"))[:60],
                        found_count, first_seen, now, price_text, json.dumps(products, ensure_ascii=False, separators=(",", ":"))
                    ))
            conn.commit()
        finally:
            conn.close()
    return {"learned": learned, "suppliers": len(touched_suppliers)}


def supplier_summary(limit=100):
    limit = max(1, min(500, int(limit or 100)))
    with _DB_LOCK:
        conn = _connect()
        try:
            rows = conn.execute("SELECT * FROM suppliers ORDER BY found_count DESC,last_seen DESC LIMIT ?", (limit,)).fetchall()
        finally:
            conn.close()
    out = []
    for r in rows:
        d = dict(r)
        try:
            d["products"] = json.loads(d.pop("products_json", "[]") or "[]")
        except Exception:
            d["products"] = []
        out.append(d)
    return out


def _query_terms(query):
    return [x for x in re.findall(r"[a-z0-9]+", clean_text(query).casefold()) if len(x) > 1]


def product_intelligence(query, max_rows=1000):
    q = clean_text(query)
    terms = _query_terms(q)
    if not terms:
        return {"ok": True, "query": q, "historyCount": 0, "suppliers": [], "prices": {}}
    with _DB_LOCK:
        conn = _connect()
        try:
            rows = conn.execute("SELECT * FROM price_history ORDER BY observed_at DESC LIMIT ?", (max_rows,)).fetchall()
        finally:
            conn.close()
    matched = []
    for r in rows:
        d = dict(r)
        hay = normalize_product((d.get("product_name") or "") + " " + (d.get("model") or ""))
        score = sum(1 for t in terms if t in hay)
        if score >= max(1, (len(terms)+1)//2):
            d["_score"] = score
            matched.append(d)
    if not matched:
        return {"ok": True, "query": q, "historyCount": 0, "suppliers": [], "prices": {}, "confidence": "LOW"}
    matched.sort(key=lambda x: (-x.get("_score", 0), -float(x.get("observed_at") or 0)))
    priced = [float(x["price_numeric"]) for x in matched if x.get("price_numeric") is not None and x.get("currency") == "INR" and float(x["price_numeric"]) >= 0]
    price_info = {}
    if priced:
        price_info = {
            "currency": "INR",
            "lowest": min(priced),
            "typical": statistics.median(priced),
            "highest": max(priced),
            "samples": len(priced),
        }
    supplier_counts = {}
    for d in matched:
        sk = d.get("supplier_key") or normalize_supplier(d.get("supplier"))
        if not sk:
            continue
        item = supplier_counts.setdefault(sk, {"name": d.get("supplier") or sk, "count": 0, "lastSeen": 0, "lastPrice": d.get("price_text") or ""})
        item["count"] += 1
        item["lastSeen"] = max(item["lastSeen"], float(d.get("observed_at") or 0))
        if d.get("price_text"):
            item["lastPrice"] = d.get("price_text")
    suppliers = sorted(supplier_counts.values(), key=lambda x: (-x["count"], -x["lastSeen"]))[:8]
    top = matched[0]
    confidence = "HIGH" if len(matched) >= 8 else ("MEDIUM" if len(matched) >= 3 else "LOW")
    return {
        "ok": True, "query": q, "historyCount": len(matched), "prices": price_info,
        "suppliers": suppliers, "recommendedSupplier": suppliers[0]["name"] if suppliers else "",
        "bestKnownProduct": top.get("product_name") or "", "bestKnownModel": top.get("model") or "",
        "confidence": confidence,
    }


def db_counts():
    with _DB_LOCK:
        conn = _connect()
        try:
            return {
                "clients": int(conn.execute("SELECT COUNT(*) FROM clients").fetchone()[0]),
                "searches": int(conn.execute("SELECT COUNT(*) FROM search_events").fetchone()[0]),
                "suppliers": int(conn.execute("SELECT COUNT(*) FROM suppliers").fetchone()[0]),
                "priceHistory": int(conn.execute("SELECT COUNT(*) FROM price_history").fetchone()[0]),
                "aliases": int(conn.execute("SELECT COUNT(*) FROM product_aliases").fetchone()[0]),
            }
        finally:
            conn.close()


def cache_size_bytes():
    total = 0
    try:
        for root, dirs, files in os.walk(_RUNTIME_DIR):
            dirs[:] = [d for d in dirs if d != "backups"]
            for name in files:
                try:
                    total += (Path(root) / name).stat().st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total


def list_backups(limit=20):
    if _BACKUP_DIR is None:
        return []
    rows = []
    for p in sorted(_BACKUP_DIR.glob("PriceMaster_Backup_*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)[:limit]:
        try:
            rows.append({"name": p.name, "size": p.stat().st_size, "createdAt": p.stat().st_mtime})
        except Exception:
            pass
    return rows


def create_backup(base_dir=None, reason="manual"):
    if _RUNTIME_DIR is None:
        raise RuntimeError("Runtime directory is not configured")
    stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}"
    path = _BACKUP_DIR / f"PriceMaster_Backup_{stamp}.zip"
    # A manual backup and the automatic pre-restore backup can be created almost
    # simultaneously. Never let one snapshot overwrite another.
    serial = 1
    while path.exists():
        path = _BACKUP_DIR / f"PriceMaster_Backup_{stamp}_{serial}.zip"
        serial += 1
    manifest = {"createdAt": time.time(), "reason": clean_text(reason), "version": 1}
    with _DB_LOCK:
        # Flush SQLite WAL pages before copying databases so each backup is a
        # self-contained point-in-time snapshot, even while the office server is live.
        for db_path in _RUNTIME_DIR.iterdir():
            if not db_path.is_file() or db_path.suffix.lower() not in {".sqlite3", ".db"}:
                continue
            try:
                conn = sqlite3.connect(str(db_path), timeout=5)
                conn.execute("PRAGMA wal_checkpoint(FULL)")
                conn.close()
            except Exception:
                try:
                    conn.close()
                except Exception:
                    pass
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in _RUNTIME_DIR.iterdir():
                if p.name == "backups" or not p.is_file():
                    continue
                if p.suffix.lower() in {".sqlite3", ".json", ".txt", ".env"} or p.name.endswith(".db"):
                    try:
                        zf.write(p, arcname="runtime/" + p.name)
                    except Exception:
                        pass
            if base_dir:
                base = Path(base_dir)
                for name in ("SEARCH_API_KEYS.env", "CLIENT_LINKS.txt", "CLIENT_URL.txt", "SERVER_PORT.txt"):
                    p = base / name
                    if p.is_file():
                        try:
                            zf.write(p, arcname="config/" + name)
                        except Exception:
                            pass
            zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    # Keep latest 14 backups.
    for old in list_backups(limit=200)[14:]:
        try:
            (_BACKUP_DIR / old["name"]).unlink()
        except Exception:
            pass
    return {"ok": True, "name": path.name, "path": str(path), "size": path.stat().st_size, "createdAt": path.stat().st_mtime}


def restore_backup(name):
    if _RUNTIME_DIR is None:
        raise RuntimeError("Runtime directory is not configured")
    safe = Path(clean_text(name)).name
    source = (_BACKUP_DIR / safe).resolve()
    if source.parent != _BACKUP_DIR.resolve() or not source.is_file() or not source.name.startswith("PriceMaster_Backup_"):
        raise ValueError("Backup file not found")
    # Make an automatic safety backup before restore.
    safety = create_backup(reason="pre-restore")
    restored = []
    with _DB_LOCK:
        with zipfile.ZipFile(source, "r") as zf:
            for info in zf.infolist():
                if not info.filename.startswith("runtime/") or info.is_dir():
                    continue
                filename = Path(info.filename).name
                if filename != info.filename.split("/")[-1]:
                    continue
                if not (filename.endswith(".sqlite3") or filename.endswith(".json") or filename.endswith(".txt") or filename.endswith(".db")):
                    continue
                target = _RUNTIME_DIR / filename
                tmp = target.with_suffix(target.suffix + ".restoretmp")
                with zf.open(info, "r") as src, open(tmp, "wb") as dst:
                    dst.write(src.read())
                # A restored SQLite main file must never be paired with WAL/SHM
                # sidecars from the newer database it is replacing.
                if target.suffix.lower() in {".sqlite3", ".db"}:
                    for sidecar in (Path(str(target) + "-wal"), Path(str(target) + "-shm")):
                        try:
                            sidecar.unlink()
                        except FileNotFoundError:
                            pass
                        except Exception:
                            pass
                os.replace(tmp, target)
                restored.append(filename)
    _ensure_db()
    return {"ok": True, "restored": restored, "safetyBackup": safety.get("name"), "from": source.name}


def maybe_daily_backup(base_dir=None):
    existing = list_backups(limit=1)
    if existing and time.time() - float(existing[0].get("createdAt") or 0) < 20 * 60 * 60:
        return existing[0]
    return create_backup(base_dir=base_dir, reason="automatic-daily")
