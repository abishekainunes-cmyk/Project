from __future__ import annotations
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

EXPECTED = "V6.5_GMAIL_AUTH_2026-08-31"
PATTERN = re.compile(r"https://script\.google\.com/macros/s/[^\"'\\s]+/exec")


def main() -> int:
    root = Path(__file__).resolve().parent
    if len(sys.argv) >= 2:
        url = sys.argv[1].strip()
    else:
        url = input("Paste NEW Web App /exec URL: ").strip()

    if not re.fullmatch(r"https://script\.google\.com/macros/s/[^/]+/exec", url):
        print("ERROR: That does not look like a Google Apps Script Web App /exec URL.")
        return 2

    for name in ("server.py", "index.html"):
        path = root / name
        if not path.exists():
            print(f"ERROR: Missing file: {name}")
            return 2
        text = path.read_text(encoding="utf-8")
        backup = path.with_suffix(path.suffix + ".before_url_fix.bak")
        if not backup.exists():
            backup.write_text(text, encoding="utf-8")
        new_text, count = PATTERN.subn(url, text)
        if count:
            path.write_text(new_text, encoding="utf-8")
            print(f"UPDATED: {name} ({count} URL occurrence(s))")
        else:
            print(f"NOTE: {name}: no replaceable Apps Script URL was found.")

    check_url = f"{url}?action=status&_ts={int(time.time() * 1000)}"
    print(f"Testing: {check_url}")
    try:
        req = urllib.request.Request(
            check_url,
            headers={"User-Agent": "NUNES-V6.5-Backend-Check/1.0"},
        )
        with urllib.request.urlopen(req, timeout=60) as response:
            raw = response.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
    except Exception as exc:
        print(f"ERROR: Could not verify Apps Script deployment: {exc}")
        return 4

    build = str(data.get("backendBuild", "") or "")
    print(f"Backend build: {build or '(missing)'}")
    if build == EXPECTED:
        print("SUCCESS: Correct V6.5 deployment is connected.")
        return 0

    print("ERROR: This URL is reachable, but it is not serving the required V6.5 backend.")
    print("Expected:", EXPECTED)
    print("Received:", build or "(missing)")
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
