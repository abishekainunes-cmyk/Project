@echo off
setlocal
set "AUTO=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PriceMaster_Server_AutoStart.cmd"
if exist "%AUTO%" del /q "%AUTO%"
echo.
if exist "%AUTO%" (
  echo Could not remove PriceMaster auto-start.
) else (
  echo PriceMaster auto-start removed.
)
echo.
pause
endlocal
