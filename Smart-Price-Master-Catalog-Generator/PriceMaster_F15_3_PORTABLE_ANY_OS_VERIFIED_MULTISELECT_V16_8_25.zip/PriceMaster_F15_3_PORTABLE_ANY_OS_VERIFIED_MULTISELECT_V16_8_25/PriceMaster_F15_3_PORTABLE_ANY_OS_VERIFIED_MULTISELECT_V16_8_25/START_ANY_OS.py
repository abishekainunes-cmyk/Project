#!/usr/bin/env python3
"""PriceMaster cross-platform launcher (Windows / macOS / Linux).

No pip packages are required. Python 3.9+ is required on the computer that hosts
PriceMaster; client computers only need a modern web browser.
"""
from __future__ import annotations

import json
import os
import platform
import socket
import sys
import urllib.request
import webbrowser
from pathlib import Path

APP_BUILD = "F15_3_PORTABLE_ANY_OS_VERIFIED_MULTISELECT_V16_8_25"
PORT_MIN = 8765
PORT_MAX = 8795
ROOT = Path(__file__).resolve().parent


def _check_python() -> None:
    if sys.version_info < (3, 9):
        print("\nPriceMaster requires Python 3.9 or newer on the server computer.")
        print("Current Python:", sys.version.split()[0])
        raise SystemExit(2)


def _health(port: int):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/local-health", timeout=0.55) as response:
            data = json.loads(response.read().decode("utf-8", errors="replace"))
        if data.get("ok") and data.get("app") == "PriceMaster":
            return data
    except Exception:
        pass
    return None


def _port_is_free(port: int) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def _persistent_cache_dir() -> Path:
    explicit = os.environ.get("PRICEMASTER_CACHE_DIR", "").strip()
    if explicit:
        return Path(os.path.expanduser(explicit))
    system = platform.system().lower()
    if system == "windows":
        base = os.environ.get("LOCALAPPDATA")
        return (Path(base) if base else Path.home() / "AppData" / "Local") / "NunesPriceMaster" / "cache"
    if system == "darwin":
        return Path.home() / "Library" / "Caches" / "NunesPriceMaster" / "cache"
    base = os.environ.get("XDG_CACHE_HOME")
    return (Path(os.path.expanduser(base)) if base else Path.home() / ".cache") / "NunesPriceMaster" / "cache"


def main() -> int:
    _check_python()
    os.chdir(ROOT)
    if not (ROOT / "server.py").is_file() or not (ROOT / "index.html").is_file():
        print("PriceMaster files are incomplete. Keep START_ANY_OS.py beside server.py and index.html.")
        return 2

    # Reuse an already-running copy first.
    for port in range(PORT_MIN, PORT_MAX + 1):
        info = _health(port)
        if info and info.get("build") == APP_BUILD:
            url = f"http://127.0.0.1:{port}/index.html"
            print(f"PriceMaster is already running on port {port}.")
            try:
                webbrowser.open(url)
            except Exception:
                pass
            return 0

    selected = None
    for port in range(PORT_MIN, PORT_MAX + 1):
        if _port_is_free(port):
            selected = port
            break
    if selected is None:
        print(f"No free PriceMaster port was found from {PORT_MIN} to {PORT_MAX}.")
        return 2

    cache = _persistent_cache_dir()
    try:
        cache.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        print("Could not create the PriceMaster cache directory:", exc)
        return 2

    os.environ["PRICEMASTER_PORT"] = str(selected)
    os.environ.setdefault("PRICEMASTER_HOST", "0.0.0.0")
    os.environ["PRICEMASTER_CACHE_DIR"] = str(cache)
    os.environ.setdefault("PRICEMASTER_OPEN_BROWSER", "1")

    print("=" * 70)
    print(" PriceMaster Portable - Windows / macOS / Linux")
    print("=" * 70)
    print("Operating system:", platform.platform())
    print("Python:", sys.version.split()[0])
    print("Selected port:", selected)
    print("Data/cache:", cache)
    print("Starting PriceMaster...\n")

    try:
        import server
        return int(server.main() or 0)
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print("\nPriceMaster could not start:", exc)
        print("Keep this folder extracted to a normal writable folder and try again.")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
