PRICEMASTER V16.8.7 - RELIABLE MAIN SERVER / BROWSER CLIENT SETUP
=================================================================

WHAT WAS CHANGED
----------------
Only the Windows/server startup and access reliability layer was changed.
The existing PriceMaster UI, search workflow, Excel/Drive logic, IndiaMART logic,
margins, sharing, catalogs, quotation functions and existing data were not redesigned.

RECOMMENDED SETUP
-----------------
Use ONE computer as the main PriceMaster server.
Do NOT run this ZIP on every client computer.

MAIN SERVER PC - ONE TIME
-------------------------
1. Extract this ZIP to a stable folder on your main PC.
2. Double-click SETUP_SERVER_PC_ONCE.bat.
3. Double-click START_PRICEMASTER.bat.
4. The browser opens on the main PC.
5. Open CLIENT_LINKS.txt to see current client URLs.

SAME WI-FI / SAME OFFICE NETWORK CLIENTS
----------------------------------------
On the other computers, open Chrome or Edge and enter one of the SAME WI-FI / LAN
addresses shown in CLIENT_LINKS.txt, for example:

  http://192.168.1.50:8765/index.html

If 8765 is already occupied, PriceMaster automatically uses 8766, 8767, etc.
Always use the exact current address shown in CLIENT_LINKS.txt.

The client computer does NOT need Python, Node.js, the ZIP, or any setup.

DIFFERENT WI-FI / DIFFERENT INTERNET CLIENTS
--------------------------------------------
For safe access without exposing PriceMaster publicly:
1. Install/sign in to Tailscale on the main server PC.
2. Install/sign in to Tailscale on each client PC using the same Tailnet/account.
3. Restart START_PRICEMASTER.bat.
4. Use the Tailscale address written in CLIENT_LINKS.txt, for example:

  http://100.x.x.x:8765/index.html

The port may be different if 8765 was already occupied; use CLIENT_LINKS.txt.

Do NOT router-forward the PriceMaster port to the public internet. PriceMaster does not have a
public-internet login/authentication layer.

MAKE THE URL WORK AUTOMATICALLY WHEN THE SERVER PC IS ON
---------------------------------------------------------
After confirming START_PRICEMASTER.bat works, run:

  INSTALL_SERVER_AUTO_START.bat

PriceMaster then starts automatically after that Windows user signs in. The PC must be
powered on, connected to the network, and signed in. Use REMOVE_SERVER_AUTO_START.bat
to remove this later.

USEFUL FILES
------------
START_PRICEMASTER.bat          Start/open the server safely.
SERVER_STATUS.bat              Check if the server is running and show client links.
STOP_SERVER.bat                Stop only the verified PriceMaster server.
CLIENT_LINKS.txt                Generated at each start with current URLs.
SETUP_SERVER_PC_ONCE.bat       One-time Python/firewall setup on the server PC.
INSTALL_SERVER_AUTO_START.bat  Start PriceMaster after Windows sign-in.
REMOVE_SERVER_AUTO_START.bat   Remove auto-start.

IMPORTANT
---------
- localhost / 127.0.0.1 works only on the main server PC.
- If the main PC IP changes, reopen CLIENT_LINKS.txt and use the current address.
- The quotation shared folders still depend on the main server PC having access to the
  same existing shared/NAS paths. Client PCs do not need direct access to those paths.

PORT CONFLICT HANDLING
----------------------
PriceMaster never kills an unrelated program just because it uses port 8765.
If 8765 is busy, START_PRICEMASTER.bat automatically selects the next free port
from 8766 through 8795, creates the matching restricted Windows Firewall rule,
and rewrites CLIENT_LINKS.txt. SERVER_STATUS.bat and STOP_SERVER.bat automatically
follow the selected port.
