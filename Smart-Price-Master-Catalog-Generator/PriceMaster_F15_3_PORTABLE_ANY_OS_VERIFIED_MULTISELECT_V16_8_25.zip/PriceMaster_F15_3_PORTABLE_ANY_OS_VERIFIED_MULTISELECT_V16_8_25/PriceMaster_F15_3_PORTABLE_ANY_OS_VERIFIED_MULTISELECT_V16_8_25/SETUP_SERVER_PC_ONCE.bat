@echo off
setlocal EnableExtensions
title PriceMaster - One-Time Server PC Setup
pushd "%~dp0" >nul 2>&1

echo.
echo ============================================================
echo   PRICEMASTER - ONE-TIME MAIN SERVER PC SETUP
echo ============================================================
echo.
echo This setup is ONLY for the main/server PC.
echo Client PCs need only Chrome/Edge and the server URL.
echo.

py -3.12 -c "import sys; print(sys.version)" >nul 2>&1 && goto :python_ok
python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1 && goto :python_ok

where winget >nul 2>&1
if errorlevel 1 goto :no_winget

echo Python 3.12 was not found. Installing Python 3.12 for this PC/user...
winget install --id Python.Python.3.12 -e --scope user --silent --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
    echo.
    echo Automatic Python installation did not complete.
    goto :no_winget
)

echo.
echo Python installation completed. A Windows sign-out/restart may be needed once.

goto :firewall

:python_ok
echo [OK] Compatible Python is already installed.

:firewall
netsh advfirewall firewall show rule name="PriceMaster Main Server LAN 8765-8795" >nul 2>&1
if not errorlevel 1 goto :firewall_ok

echo.
echo Adding the restricted PriceMaster LAN/Tailscale firewall rule for ports 8765-8795.
echo Approve the Administrator prompt if Windows asks.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'netsh.exe' -Verb RunAs -Wait -ArgumentList @('advfirewall','firewall','add','rule','name=PriceMaster Main Server LAN 8765-8795','dir=in','action=allow','protocol=TCP','localport=8765-8795','remoteip=LocalSubnet,100.64.0.0/10','profile=any')"

:firewall_ok
echo.
echo [OK] Server PC setup is ready.
echo.
echo Next: double-click START_PRICEMASTER.bat
echo Optional: run INSTALL_SERVER_AUTO_START.bat so PriceMaster starts when you sign in.
echo.
pause
popd
endlocal
exit /b 0

:no_winget
echo.
echo Python 3.12 is required only on this main server PC.
echo Install Python 3.12, enable Add Python to PATH, then rerun this file.
echo Client PCs do not require Python.
echo.
pause
popd
endlocal
exit /b 1
