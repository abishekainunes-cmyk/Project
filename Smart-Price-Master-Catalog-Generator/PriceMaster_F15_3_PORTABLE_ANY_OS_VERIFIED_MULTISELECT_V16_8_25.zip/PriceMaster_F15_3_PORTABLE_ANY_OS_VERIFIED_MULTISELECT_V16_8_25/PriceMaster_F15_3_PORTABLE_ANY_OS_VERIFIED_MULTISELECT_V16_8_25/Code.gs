/*******************************************************
 * NUNES CLOUD PRODUCT SEARCH
 * Google Apps Script Backend
 *
 * Version: 1.0
 *
 * This backend:
 *  - Connects to Google Drive
 *  - Recursively indexes the selected root folder
 *  - Creates/updates a Google Sheets cloud index
 *  - Performs smart metadata search
 *  - Returns PDF preview and Drive links
 *******************************************************/


/* =====================================================
   1. CONFIGURATION
   ===================================================== */

/*
 * IMPORTANT:
 * Replace the value below with the ID of your main
 * Google Drive folder.
 *
 * Example Drive URL:
 * https://drive.google.com/drive/folders/ABC123...
 *
 * Copy only:
 * ABC123...
 */
/*
 * TWO GOOGLE DRIVE ROOT FOLDERS
 */
const DRIVE_ROOTS = [
  { name: 'Mini Catalog', id: '1C4Bh6hfXC731IXcDMHPSk4szFSaKLkpo' },
  { name: 'Overall Categories Catalog', id: '1uILUsmav_9nKmt7Zk1nAyIyltgL3gJXY' },
  { name: 'Detailed Catalog', id: '1zqiE59vCUXmSZec0149KdKj0vuJPBdiP' }
];

const MAX_SEARCH_RESULTS = 1000;
const INDEX_SHEET_NAME = 'NUNES_CLOUD_INDEX';

const NUNES_BACKEND_BUILD = 'V6.5_GMAIL_AUTH_2026-08-31';


/* =====================================================
   2. WEB APP
   ===================================================== */

function doGet(e) {

  const params =
    e &&
    e.parameter
      ? e.parameter
      : {};

  const action =
    params.action
      ? String(params.action)
          .toLowerCase()
          .trim()
      : '';

  /*
   * Local HTML/BAT client support.
   *
   * The local client cannot use google.script.run,
   * so it calls this Web App using JSONP.
   */
  const callback =
    params.callback
      ? String(params.callback).trim()
      : '';

  let result;

  try {

    if (action === 'search') {

      const query =
        params.q || '';

      result =
        searchDrive(query);

    } else if (
      action === 'status'
    ) {

      result =
        getIndexStatus();
      if (result && typeof result === 'object') {
        result.backendBuild = NUNES_BACKEND_BUILD;
        result.directGmail = true;
      }

    } else if (
      action === 'categories'
    ) {

      result =
        getDriveCategories();

    } else if (
      action === 'refresh'
    ) {

      /*
       * Refresh is intentionally available through GET
       * for the local BAT/HTML client.
       */
      result =
        refreshIndex();

    } else {

      /*
       * Normal Apps Script browser access.
       */
      return HtmlService
        .createTemplateFromFile('index')
        .evaluate()
        .setTitle(
          'Nunes Drive Product Search'
        )
        .setXFrameOptionsMode(
          HtmlService.XFrameOptionsMode.ALLOWALL
        );
    }

  } catch (error) {

    result = {
      ok: false,
      error:
        error &&
        error.message
          ? error.message
          : String(error)
    };

  }

  /*
   * JSONP response for local HTML.
   */
  if (callback) {

    /*
     * Allow only a JavaScript identifier / dotted identifier.
     * This prevents arbitrary code from being inserted
     * into the callback position.
     */
    if (
      !/^[A-Za-z_$][A-Za-z0-9_$]*(\.[A-Za-z_$][A-Za-z0-9_$]*)*$/
        .test(callback)
    ) {

      return ContentService
        .createTextOutput(
          'Invalid callback.'
        )
        .setMimeType(
          ContentService.MimeType.TEXT
        );

    }

    return ContentService
      .createTextOutput(
        callback +
        '(' +
        JSON.stringify(result) +
        ');'
      )
      .setMimeType(
        ContentService.MimeType.JAVASCRIPT
      );

  }

  return jsonOutput_(
    result
  );
}


/*
 * POST API.
 */
function doPost(e) {

  /*
   * V6.1: read the POST action from BOTH the query/form parameter
   * and the JSON payload. This avoids "Unknown POST action" when
   * a proxy/redirect drops the query-string action.
   */
  let payload = {};
  let action = '';

  try {
    if (e && e.parameter && e.parameter.payload) {
      payload = JSON.parse(String(e.parameter.payload));
    } else if (e && e.postData && e.postData.contents) {
      const contents = String(e.postData.contents || '').trim();
      if (contents && contents.charAt(0) === '{') {
        payload = JSON.parse(contents);
      }
    }
  } catch (parseError) {
    return jsonOutput_({
      ok: false,
      error: 'Invalid POST payload: ' +
        (parseError && parseError.message ? parseError.message : String(parseError)),
      backendBuild: NUNES_BACKEND_BUILD
    });
  }

  if (e && e.parameter && e.parameter.action) {
    action = String(e.parameter.action).toLowerCase().trim();
  }

  if (!action && payload && payload.action) {
    action = String(payload.action).toLowerCase().trim();
  }

  if (!action && payload && payload._action) {
    action = String(payload._action).toLowerCase().trim();
  }

  /*
   * V6.5 route guard: a Gmail payload is unambiguous. If Google strips
   * the action field but the POST still contains recipient + files, treat
   * it as sendgmail instead of returning Unknown POST action.
   */
  if ((!action || action === 'unknown') &&
      payload &&
      payload.recipient &&
      Array.isArray(payload.files) &&
      payload.files.length) {
    action = 'sendgmail';
  }

  if (action === 'refresh') {
    const refreshed = refreshIndex();
    refreshed.backendBuild = NUNES_BACKEND_BUILD;
    return jsonOutput_(refreshed);
  }

  if (action === 'sendgmail') {
    try {
      const result = sendGmailPackage_(payload || {});
      result.backendBuild = NUNES_BACKEND_BUILD;
      return jsonOutput_(result);
    } catch (error) {
      return jsonOutput_({
        ok: false,
        error:
          'Gmail send failed: ' +
          (error && error.message ? error.message : String(error)),
        backendBuild: NUNES_BACKEND_BUILD
      });
    }
  }

  return jsonOutput_({
    ok: false,
    error: 'Unknown POST action.',
    receivedAction: action || '(empty)',
    backendBuild: NUNES_BACKEND_BUILD
  });
}


/*
 * JSON response helper.
 */
function jsonOutput_(data) {

  return ContentService
    .createTextOutput(
      JSON.stringify(data)
    )
    .setMimeType(
      ContentService.MimeType.JSON
    );
}

/* =====================================================
   3. CONFIG VALIDATION
   ===================================================== */

function getConfig_() {

  if (!Array.isArray(DRIVE_ROOTS) ||
      DRIVE_ROOTS.length === 0) {
    throw new Error(
      'No Google Drive root folders are configured.'
    );
  }

  DRIVE_ROOTS.forEach(function(root) {
    if (!root.id) {
      throw new Error(
        'A Google Drive root folder ID is missing.'
      );
    }
  });

  return {
    roots: DRIVE_ROOTS,
    maxResults: MAX_SEARCH_RESULTS
  };
}

/* =====================================================
   4. CLOUD INDEX SPREADSHEET
   ===================================================== */

function getIndexSpreadsheet_() {

  const props =
    PropertiesService.getScriptProperties();

  let spreadsheetId =
    props.getProperty(
      'NUNES_INDEX_SPREADSHEET_ID'
    );

  if (spreadsheetId) {

    try {
      return SpreadsheetApp.openById(
        spreadsheetId
      );
    } catch (error) {
      props.deleteProperty(
        'NUNES_INDEX_SPREADSHEET_ID'
      );
    }
  }

  const ss =
    SpreadsheetApp.create(
      'NUNES CLOUD PRODUCT INDEX'
    );

  props.setProperty(
    'NUNES_INDEX_SPREADSHEET_ID',
    ss.getId()
  );

  const sheet =
    ss.getSheets()[0];

  sheet.setName(
    INDEX_SHEET_NAME
  );

  setupIndexSheet_(sheet);

  return ss;
}


/* =====================================================
   5. INDEX SHEET
   ===================================================== */

function setupIndexSheet_(sheet) {

  const headers = [
  'File ID',
  'Drive Source',
  'Name',
  'Product',
  'Category',
  'Folder',
  'Type',
  'Modified',
  'Size',
  'Web View Link',
  'Preview Link',
  'Is PDF',
  'Root Name',
  'Drive Folder',
  'Matched In',
  'Search Text'
];

  sheet.clear();

  sheet
    .getRange(
      1,
      1,
      1,
      headers.length
    )
    .setValues([headers]);

  sheet
    .getRange(
      1,
      1,
      1,
      headers.length
    )
    .setFontWeight('bold');

  sheet.setFrozenRows(1);
}


/* =====================================================
   6. GET INDEX SHEET
   ===================================================== */

function getIndexSheet_() {

  const ss =
    getIndexSpreadsheet_();

  let sheet =
    ss.getSheetByName(
      INDEX_SHEET_NAME
    );

  if (!sheet) {

    sheet =
      ss.insertSheet(
        INDEX_SHEET_NAME
      );

    setupIndexSheet_(sheet);
  }

  return sheet;
}


/* =====================================================
   7. REFRESH CLOUD INDEX
   ===================================================== */

function refreshIndex() {

  const lock =
    LockService.getScriptLock();

  if (!lock.tryLock(10000)) {

    return {
      ok: false,
      error:
        'Another index refresh is already running.'
    };
  }

  try {

    const config =
      getConfig_();

    const rows = [];

    /*
     * Scan BOTH Drive roots recursively.
     */
    config.roots.forEach(
      function(rootConfig) {

        const root =
          DriveApp.getFolderById(
            rootConfig.id
          );

        scanFolder_(
          root,
          '',
          rows,
          rootConfig.name
        );

      }
    );

    const sheet =
      getIndexSheet_();

    sheet.clearContents();

    setupIndexSheet_(
      sheet
    );

    if (rows.length > 0) {

      sheet
        .getRange(
          2,
          1,
          rows.length,
          rows[0].length
        )
        .setValues(rows);

    }

    const props =
      PropertiesService
        .getScriptProperties();

    props.setProperty(
      'NUNES_INDEX_LAST_REFRESH',
      new Date().toISOString()
    );

    props.setProperty(
      'NUNES_INDEX_FILE_COUNT',
      String(rows.length)
    );

    return {

      ok: true,

      files:
        rows.length,

      refreshedAt:
        new Date().toISOString(),

      message:
        'NUNES cloud index refreshed successfully.'
    };

  } catch (error) {

    return {

      ok: false,

      error:
        error && error.message
          ? error.message
          : String(error)

    };

  } finally {

    try {
      lock.releaseLock();
    } catch (e) {}

  }
}


/* =====================================================
   8. RECURSIVE DRIVE SCANNER
   ===================================================== */

function scanFolder_(
  folder,
  relativeFolder,
  rows,
  driveSource
) {

  const currentName =
    folder.getName();

  const folderPath =
    relativeFolder
      ? relativeFolder +
        ' / ' +
        currentName
      : currentName;


  /*
   * Determine category.
   */
  let category =
    driveSource;


  if (relativeFolder) {

    const parts =
      folderPath
        .split(' / ')
        .filter(Boolean);

    if (parts.length >= 2) {

      category =
        parts[1];

    }

  }


  /*
   * Product folder.
   */
  const product =
    currentName;


  /*
   * -------- FILES --------
   */

  const files =
    folder.getFiles();

  while (files.hasNext()) {

    const file =
      files.next();

    try {

      const fileName =
        file.getName();

      const mimeType =
        file.getMimeType();

      const fileType =
        getFileType_(
          fileName,
          mimeType
        );

      const modified =
        file.getLastUpdated();

      const size =
        getFileSize_(
          file
        );

      const fileId =
        file.getId();


      const webViewLink =
        'https://drive.google.com/file/d/' +
        encodeURIComponent(fileId) +
        '/view';


      const isPdf =
        fileType === 'PDF';


      const previewLink =
        isPdf

          ? 'https://drive.google.com/file/d/' +
            encodeURIComponent(
              fileId
            ) +
            '/preview'

          : webViewLink;


      /*
       * Searchable text.
       */
      const searchText =
        normalizeSearchText_(
          [
            fileName,
            product,
            category,
            folderPath,
            driveSource
          ].join(' ')
        );


      rows.push([
        fileId,
        driveSource,
        fileName,
        product,
        category,
        folderPath,
        fileType,
        formatDate_(modified),
        size,
        webViewLink,
        previewLink,
        isPdf,
        driveSource,
        folderPath,
        '',
        searchText
      ]);


    } catch (error) {

      console.log(
        'Skipped file: ' +
        error
      );

    }

  }


  /*
   * -------- SUBFOLDERS --------
   */

  const folders =
    folder.getFolders();

  while (folders.hasNext()) {

    const child =
      folders.next();


    scanFolder_(
      child,

      folderPath,

      rows,

      driveSource
    );

  }

}


/* =====================================================
   9. FILE TYPE
   ===================================================== */

function getFileType_(
  fileName,
  mimeType
) {

  const name =
    String(fileName || '');

  const dot =
    name.lastIndexOf('.');

  if (dot >= 0) {

    const ext =
      name
        .substring(dot + 1)
        .trim()
        .toUpperCase();

    if (ext) {
      return ext;
    }
  }

  const map = {

    'application/pdf':
      'PDF',

    'image/jpeg':
      'JPG',

    'image/png':
      'PNG',

    'image/webp':
      'WEBP',

    'image/gif':
      'GIF',

    'text/plain':
      'TXT',

    'text/csv':
      'CSV',

    'application/vnd.google-apps.document':
      'GOOGLE DOC',

    'application/vnd.google-apps.spreadsheet':
      'GOOGLE SHEET',

    'application/vnd.google-apps.presentation':
      'GOOGLE SLIDES'

  };

  return (
    map[mimeType] ||
    'FILE'
  );
}


/* =====================================================
   10. FILE SIZE
   ===================================================== */

function getFileSize_(file) {

  try {

    const bytes =
      file.getSize();

    if (!bytes) {
      return '';
    }

    if (bytes < 1024) {
      return bytes + ' B';
    }

    if (
      bytes <
      1024 * 1024
    ) {
      return (
        bytes / 1024
      ).toFixed(1) +
      ' KB';
    }

    if (
      bytes <
      1024 * 1024 * 1024
    ) {
      return (
        bytes /
        (1024 * 1024)
      ).toFixed(1) +
      ' MB';
    }

    return (
      bytes /
      (1024 * 1024 * 1024)
    ).toFixed(2) +
    ' GB';

  } catch (error) {

    return '';
  }
}


/* =====================================================
   11. DATE FORMAT
   ===================================================== */

function formatDate_(date) {

  if (!date) {
    return '';
  }

  return Utilities.formatDate(
    date,
    Session.getScriptTimeZone() ||
      'Asia/Kolkata',
    'dd-MMM-yyyy HH:mm'
  );
}



/* =====================================================
   11B. DIRECT GMAIL PRODUCT PACK
   ===================================================== */

const NUNES_GMAIL_MAX_ATTACHMENT_BYTES = 18 * 1024 * 1024;
// Must match GMAIL_AUTH_SECRET in the local server.py.
const NUNES_GMAIL_AUTH_SECRET = '7b73fbc923306eba2e6a80415976d1b9d9825fdee4f60fa669cf4cede797dce0';
const NUNES_GMAIL_AUTH_MAX_AGE_SECONDS = 300;


function gmailEscapeHtml_(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}


function gmailNormalizeRecipients_(value) {
  return String(value || '')
    .split(/[;,]/)
    .map(function(part) { return part.trim(); })
    .filter(Boolean);
}


function gmailValidateRecipients_(recipients) {
  if (!recipients.length) return false;

  return recipients.every(function(address) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address);
  });
}


function gmailIndexedFileIds_() {
  const sheet = getIndexSheet_();
  const lastRow = sheet.getLastRow();
  const ids = {};

  if (lastRow < 2) return ids;

  sheet
    .getRange(2, 1, lastRow - 1, 1)
    .getValues()
    .forEach(function(row) {
      const id = String(row[0] || '').trim();
      if (id) ids[id] = true;
    });

  return ids;
}


function gmailDecodeAsset_(asset, name) {
  if (!asset || !asset.base64) return null;

  try {
    const bytes = Utilities.base64Decode(String(asset.base64));
    return Utilities.newBlob(
      bytes,
      String(asset.mimeType || 'application/octet-stream'),
      name
    );
  } catch (error) {
    return null;
  }
}


function gmailAttachmentBlob_(file) {
  const mime = String(file.getMimeType() || '');
  const name = String(file.getName() || 'Product File');

  if (mime.indexOf('application/vnd.google-apps.') === 0) {
    return file.getAs(MimeType.PDF).setName(name + '.pdf');
  }

  return file.getBlob().setName(name);
}


function gmailDriveThumbnailBlob_(file, index) {
  try {
    const mime = String(file.getMimeType() || '');

    if (mime.indexOf('image/') === 0) {
      return file.getBlob().setName('preview_' + index + '.png');
    }

    const token = ScriptApp.getOAuthToken();
    const metadataUrl =
      'https://www.googleapis.com/drive/v3/files/' +
      encodeURIComponent(file.getId()) +
      '?fields=thumbnailLink,mimeType,name&supportsAllDrives=true';

    const metadataResponse = UrlFetchApp.fetch(metadataUrl, {
      method: 'get',
      headers: {
        Authorization: 'Bearer ' + token
      },
      muteHttpExceptions: true
    });

    if (metadataResponse.getResponseCode() !== 200) {
      return null;
    }

    const metadata = JSON.parse(metadataResponse.getContentText() || '{}');
    let thumbnailLink = String(metadata.thumbnailLink || '').trim();
    if (!thumbnailLink) return null;

    thumbnailLink = thumbnailLink
      .replace(/=s\d+(-c)?$/, '=s1200')
      .replace(/=w\d+-h\d+(-p-k-nu)?$/, '=w1200');

    const imageResponse = UrlFetchApp.fetch(thumbnailLink, {
      method: 'get',
      headers: {
        Authorization: 'Bearer ' + token
      },
      followRedirects: true,
      muteHttpExceptions: true
    });

    if (imageResponse.getResponseCode() < 200 || imageResponse.getResponseCode() >= 300) {
      return null;
    }

    const blob = imageResponse.getBlob();
    if (String(blob.getContentType() || '').indexOf('image/') !== 0) {
      return null;
    }

    return blob.setName('preview_' + index + '.png');

  } catch (error) {
    return null;
  }
}


function gmailFileLink_(fileId) {
  return 'https://drive.google.com/file/d/' + encodeURIComponent(fileId) + '/view';
}


function gmailBuildHtml_(preparedFiles, locations, inlineMap, products) {
  const fileRows = preparedFiles.map(function(item, index) {
    const cid = item.previewCid;
    const fileName = String(item.name || 'Product File');
    const productName = String(item.product || '').trim() || fileName.replace(/\.[^.]+$/, '');
    const displayFileName = fileName;
    const category = String(item.category || '').trim();
    const source = String(item.driveSource || '').trim();
    const type = String(item.type || 'PDF').trim() || 'PDF';

    const previewHtml = cid
      ? '<img src="cid:' + gmailEscapeHtml_(cid) + '" alt="' + gmailEscapeHtml_(productName) + ' preview" width="620" style="display:block;width:100%;max-width:620px;height:auto;max-height:430px;object-fit:contain;margin:0 auto;background:#ffffff;border:0;">'
      : '<div style="padding:74px 18px;font-family:Arial,sans-serif;color:#52647d;font-size:16px;font-weight:800;text-align:center;">' + gmailEscapeHtml_(type) + ' PRODUCT PREVIEW</div>';

    function badge_(label) {
      if (!label) return '';
      return '<span style="display:inline-block;margin:0 6px 6px 0;padding:5px 9px;border-radius:999px;background:#eef4ff;border:1px solid #d6e4ff;font-family:Arial,sans-serif;font-size:10px;line-height:1;color:#2857a4;font-weight:700;">' + gmailEscapeHtml_(label) + '</span>';
    }

    return '' +
      '<tr><td style="padding:0 0 18px 0;">' +
        '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:separate;border-spacing:0;background:#ffffff;border:1px solid #d8e3f0;border-radius:16px;overflow:hidden;">' +
          '<tr><td style="padding:14px 15px 11px 15px;background:#f8fbff;border-bottom:1px solid #e5edf7;">' +
            '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">' +
              '<tr>' +
                '<td valign="top" style="padding:0 12px 0 0;">' +
                  '<div style="font-family:Arial,sans-serif;font-size:10px;font-weight:800;letter-spacing:.12em;color:#2563eb;margin-bottom:7px;">PRODUCT ' + ('0' + (index + 1)).slice(-2) + '</div>' +
                  '<div style="font-family:Arial,Helvetica,sans-serif;font-size:24px;line-height:1.18;font-weight:900;color:#17243b;letter-spacing:-.01em;word-break:break-word;">' + gmailEscapeHtml_(displayFileName) + '</div>' +
                  '<div style="margin-top:10px;">' + badge_(type) + badge_(source) + badge_(category) + '</div>' +
                '</td>' +
                '<td width="54" align="right" valign="top">' +
                  '<div style="display:inline-block;min-width:38px;padding:8px 7px;border-radius:10px;background:#14213d;color:#ffffff;font-family:Arial,sans-serif;font-size:11px;line-height:1;text-align:center;font-weight:800;">' + gmailEscapeHtml_(type) + '</div>' +
                '</td>' +
              '</tr>' +
            '</table>' +
          '</td></tr>' +
          '<tr><td style="padding:12px 15px 15px 15px;">' +
            '<div style="border:1px solid #dce6f2;border-radius:12px;background:#f7faff;text-align:center;overflow:hidden;min-height:220px;">' + previewHtml + '</div>' +
            '<div style="padding:13px 2px 0 2px;font-family:Arial,sans-serif;font-size:11px;line-height:1.45;color:#75849a;">' +
              '<span style="font-weight:700;color:#52647d;">File:</span> ' + gmailEscapeHtml_(fileName) +
            '</div>' +
            '<table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin-top:14px;border-collapse:separate;">' +
              '<tr><td bgcolor="#2563eb" style="border-radius:9px;">' +
                '<a href="' + gmailEscapeHtml_(item.link) + '" style="display:inline-block;padding:11px 17px;font-family:Arial,sans-serif;font-size:12px;line-height:1;font-weight:800;color:#ffffff;text-decoration:none;letter-spacing:.02em;">VIEW PRODUCT DOCUMENT</a>' +
              '</td></tr>' +
            '</table>' +
          '</td></tr>' +
        '</table>' +
      '</td></tr>';
  }).join('');

  const productDetailsHtml = (products || []).map(function(product, index) {
    const name = String((product && product.name) || 'Unnamed product');
    const model = String((product && product.model) || '').trim();
    const price = String((product && product.price) || '').trim();
    const priceProfile = String((product && product.priceProfile) || '').trim().toUpperCase();
    const supplier = String((product && product.supplier) || '').trim();
    return '<div style="padding:10px 12px;margin:0 0 8px 0;border:1px solid #e1e9f3;border-radius:10px;background:#f8fbff;font-family:Arial,sans-serif;">' +
      '<div style="font-size:12px;font-weight:800;color:#17304e;">' + (index + 1) + '. ' + gmailEscapeHtml_(name) + '</div>' +
      (model ? '<div style="font-size:10px;color:#60738d;margin-top:4px;">Model: ' + gmailEscapeHtml_(model) + '</div>' : '') +
      (price ? '<div style="font-size:10px;color:#60738d;margin-top:3px;">Price' + (priceProfile ? ' (' + gmailEscapeHtml_(priceProfile) + ')' : '') + ': ' + gmailEscapeHtml_(price) + '</div>' : '') +
      (supplier ? '<div style="font-size:10px;color:#60738d;margin-top:3px;">Supplier: ' + gmailEscapeHtml_(supplier) + '</div>' : '') +
    '</div>';
  }).join('');

  const qrHtml = (locations || []).map(function(location) {
    const cid = 'qr_' + String(location.id || '');
    const hasQr = !!inlineMap[cid];
    const qrImage = hasQr
      ? '<img src="cid:' + gmailEscapeHtml_(cid) + '" alt="' + gmailEscapeHtml_(location.label) + ' QR" width="96" height="96" style="display:block;width:96px;height:96px;object-fit:contain;margin:0 auto;border:0;">'
      : '<div style="width:96px;height:96px;display:table-cell;vertical-align:middle;background:#ffffff;color:#334155;font-family:Arial,sans-serif;font-size:10px;font-weight:700;">QR</div>';

    return '' +
      '<div style="display:inline-block;vertical-align:top;width:112px;margin:0 8px 10px 0;text-align:center;">' +
        '<div style="background:#ffffff;border-radius:9px;padding:6px;">' + qrImage + '</div>' +
        '<div style="font-family:Arial,sans-serif;color:#ffffff;font-size:10px;font-weight:700;line-height:1.25;margin-top:6px;">' + gmailEscapeHtml_(location.label) + '</div>' +
        '<div style="font-family:Arial,sans-serif;font-size:9px;line-height:1.25;margin-top:4px;word-break:break-all;"><a href="' + gmailEscapeHtml_(location.url || '') + '" style="color:#9ec0ff;text-decoration:none;">Open location</a></div>' +
      '</div>';
  }).join('');

  const selectedNames = (locations || []).map(function(location) {
    return String(location.label || '');
  }).filter(Boolean).join(', ');

  const companyImage = inlineMap.company
    ? '<img src="cid:company" alt="Nunes Instruments" width="240" style="display:block;width:100%;max-width:240px;height:auto;border-radius:7px;margin:0 0 13px 0;border:0;">'
    : '';

  const detailCount = (products || []).length;
  const productCountText = preparedFiles.length
    ? preparedFiles.length + ' selected product document' + (preparedFiles.length === 1 ? '' : 's') + ' with large previews for quick identification.'
    : (detailCount ? detailCount + ' selected product detail' + (detailCount === 1 ? '' : 's') + '.' : 'Selected category / location information.');

  return '<!doctype html>' +
    '<html><body style="margin:0;padding:0;background:#f2f5fa;">' +
    '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;background:#f2f5fa;">' +
      '<tr><td align="center" style="padding:18px 8px;">' +
        '<table role="presentation" width="700" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:700px;border-collapse:separate;border-spacing:0;background:#ffffff;border:1px solid #dbe4ef;border-radius:18px;overflow:hidden;">' +
          '<tr><td style="padding:26px 28px;background:#14213d;border-bottom:5px solid #2563eb;">' +
            '<div style="font-family:Arial,sans-serif;color:#ffffff;font-size:30px;font-weight:800;letter-spacing:.02em;line-height:1.1;">NUNES INSTRUMENT</div>' +
            '<div style="font-family:Arial,sans-serif;color:#d9e4fa;font-size:12px;line-height:1.5;margin-top:7px;">Selected product documents · visual previews · direct Drive access · location details</div>' +
          '</td></tr>' +
          '<tr><td style="padding:20px 18px 4px 18px;">' +
            '<div style="font-family:Arial,sans-serif;color:#2563eb;font-size:11px;font-weight:800;letter-spacing:.08em;margin-bottom:5px;">SELECTED PRODUCTS</div>' +
            '<div style="font-family:Arial,sans-serif;color:#66758f;font-size:12px;line-height:1.5;margin-bottom:15px;">' + gmailEscapeHtml_(productCountText) + '</div>' +
            productDetailsHtml +
            '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">' + fileRows + '</table>' +
          '</td></tr>' +
          '<tr><td style="padding:22px 24px;background:#14213d;">' +
            '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="border-collapse:collapse;">' +
              '<tr>' +
                '<td width="43%" valign="top" style="padding:0 18px 0 0;border-right:1px solid #34435f;">' +
                  '<div style="font-family:Arial,sans-serif;color:#9ec0ff;font-size:10px;font-weight:800;letter-spacing:.06em;margin-bottom:10px;">LOCATION QR</div>' +
                  (qrHtml || '<span style="font-family:Arial,sans-serif;color:#d9e4fa;font-size:11px;">No location selected</span>') +
                '</td>' +
                '<td width="57%" valign="top" style="padding:0 0 0 20px;">' +
                  companyImage +
                  '<div style="font-family:Arial,sans-serif;color:#ffffff;font-size:21px;font-weight:800;line-height:1.2;">Nunes Instruments</div>' +
                  '<div style="font-family:Arial,sans-serif;color:#dbe6f7;font-size:11px;line-height:1.65;margin-top:8px;">' +
                    '789/1109, Avinashi Road, Opposite to Passport Office,<br>' +
                    'Coimbatore - 641018, Tamil Nadu, India<br>' +
                    'Phone: +91-422-2200068, 2387577<br>' +
                    'Mobile: +91 93452 26022<br>' +
                    'Email: info@nunesinstruments.com<br>' +
                    'Website: www.nunesinstruments.com' +
                  '</div>' +
                  (selectedNames ? '<div style="font-family:Arial,sans-serif;color:#9ec0ff;font-size:10px;font-weight:700;line-height:1.4;margin-top:8px;">Selected: ' + gmailEscapeHtml_(selectedNames) + '</div>' : '') +
                '</td>' +
              '</tr>' +
            '</table>' +
          '</td></tr>' +
        '</table>' +
      '</td></tr>' +
    '</table>' +
    '</body></html>';
}

function gmailBuildPlainText_(preparedFiles, locations, products) {
  const lines = [
    'Dear Sir/Madam,',
    '',
    'Please find the requested Nunes Instrument product file(s) attached and linked below.',
    ''
  ];

  (products || []).forEach(function(product, index) {
    lines.push((index + 1) + '. ' + String((product && product.name) || 'Unnamed product'));
    if (product && product.model) lines.push('Model: ' + String(product.model));
    if (product && product.price) {
      const profile = String(product.priceProfile || '').trim().toUpperCase();
      lines.push('Price' + (profile ? ' (' + profile + ')' : '') + ': ' + String(product.price));
    }
    if (product && product.supplier) lines.push('Supplier: ' + String(product.supplier));
    lines.push('');
  });

  preparedFiles.forEach(function(item, index) {
    lines.push((index + 1) + '. ' + item.name);
    lines.push(item.link);
    lines.push('');
  });

  if (locations && locations.length) {
    lines.push('LOCATIONS');
    locations.forEach(function(location) {
      lines.push(String(location.label || '') + ': ' + String(location.url || ''));
    });
    lines.push('');
  }

  lines.push('Regards,');
  lines.push('Nunes Instruments');

  return lines.join('\n');
}


function gmailAuthHex_(bytes) {
  return bytes.map(function(value) {
    const n = value < 0 ? value + 256 : value;
    return ('0' + n.toString(16)).slice(-2);
  }).join('');
}


function gmailAuthMessage_(payload, timestamp) {
  const recipient = String(payload.recipient || '').trim().toLowerCase();
  const files = Array.isArray(payload.files) ? payload.files : [];
  const ids = files.map(function(item) {
    return String((item && item.fileId) || '').trim();
  }).filter(Boolean).sort();
  return String(timestamp) + '\n' + recipient + '\n' + ids.join(',');
}


function gmailVerifyAuth_(payload) {
  const timestampText = String((payload && payload._authTs) || '').trim();
  const supplied = String((payload && payload._authSig) || '').trim().toLowerCase();
  const timestamp = Number(timestampText);
  if (!timestampText || !supplied || !isFinite(timestamp)) return false;
  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - timestamp) > NUNES_GMAIL_AUTH_MAX_AGE_SECONDS) return false;

  const message = gmailAuthMessage_(payload || {}, timestampText);
  const expected = gmailAuthHex_(Utilities.computeHmacSha256Signature(
    message,
    NUNES_GMAIL_AUTH_SECRET,
    Utilities.Charset.UTF_8
  ));

  if (expected.length !== supplied.length) return false;
  let mismatch = 0;
  for (let i = 0; i < expected.length; i++) {
    mismatch |= expected.charCodeAt(i) ^ supplied.charCodeAt(i);
  }
  return mismatch === 0;
}


function sendGmailPackage_(payload) {
  payload = payload || {};

  if (!gmailVerifyAuth_(payload)) {
    return {
      ok: false,
      error: 'Unauthorized Gmail request.'
    };
  }

  const recipients = gmailNormalizeRecipients_(payload.recipient);
  if (!gmailValidateRecipients_(recipients)) {
    return {
      ok: false,
      error: 'Enter a valid recipient email address.'
    };
  }

  const selections = Array.isArray(payload.files) ? payload.files : [];
  const locations = Array.isArray(payload.locations) ? payload.locations : [];
  const products = Array.isArray(payload.products) ? payload.products : [];
  if (!selections.length && !locations.length && !products.length) {
    return {
      ok: false,
      error: 'Select a product, catalog, category, or location before sending.'
    };
  }

  if (selections.length > 25) {
    return {
      ok: false,
      error: 'Select a maximum of 25 files in one Gmail.'
    };
  }

  const allowedIds = gmailIndexedFileIds_();
  const preparedFiles = [];
  const attachments = [];
  const inlineImages = {};
  let attachmentBytes = 0;
  let previewCount = 0;

  selections.forEach(function(selection, index) {
    const fileId = String(selection.fileId || '').trim();
    if (!fileId || !allowedIds[fileId]) {
      throw new Error('A selected file is not present in the current Nunes cloud index. Refresh the index and try again.');
    }

    const file = DriveApp.getFileById(fileId);
    const attachment = gmailAttachmentBlob_(file);
    attachmentBytes += attachment.getBytes().length;

    if (attachmentBytes > NUNES_GMAIL_MAX_ATTACHMENT_BYTES) {
      throw new Error(
        'Selected attachments are too large for one reliable Gmail send. ' +
        'Keep the selected files below about 18 MB total, then send again.'
      );
    }

    attachments.push(attachment);

    const previewCid = 'preview_' + (index + 1);
    const previewBlob = gmailDriveThumbnailBlob_(file, index + 1);
    if (previewBlob) {
      inlineImages[previewCid] = previewBlob;
      previewCount += 1;
    }

    preparedFiles.push({
      fileId: fileId,
      name: file.getName(),
      product: String(selection.product || ''),
      category: String(selection.category || ''),
      folder: String(selection.folder || ''),
      type: String(selection.type || file.getMimeType() || 'PDF'),
      driveSource: String(selection.driveSource || ''),
      link: gmailFileLink_(fileId),
      previewCid: previewBlob ? previewCid : ''
    });
  });

  const assets = payload.assets || {};

  locations.forEach(function(location) {
    const id = String(location.id || '');
    const asset = assets[id];
    const blob = gmailDecodeAsset_(asset, id + '_qr.png');
    if (blob) {
      inlineImages['qr_' + id] = blob;
    }
  });

  const companyBlob = gmailDecodeAsset_(assets.company, 'nunes_company.jpg');
  if (companyBlob) {
    inlineImages.company = companyBlob;
  }

  const subject = String(payload.subject || '').trim() ||
    (preparedFiles.length === 1
      ? 'Nunes Instrument - Product File'
      : 'Nunes Instrument - Product Files');

  const plainBody = gmailBuildPlainText_(preparedFiles, locations, products);
  const htmlBody = gmailBuildHtml_(preparedFiles, locations, inlineImages, products);

  GmailApp.sendEmail(
    recipients.join(','),
    subject,
    plainBody,
    {
      htmlBody: htmlBody,
      attachments: attachments,
      inlineImages: inlineImages,
      name: 'Nunes Instrument'
    }
  );

  return {
    ok: true,
    recipient: recipients.join(', '),
    attachedCount: attachments.length,
    previewCount: previewCount,
    locationCount: locations.length,
    subject: subject
  };
}


/* =====================================================
   12. SEARCH NORMALIZATION
   ===================================================== */

function normalizeSearchText_(value) {

  let text =
    String(value || '')
      .toLowerCase();

  text =
    text.replace(
      /[_\-\/\\.,()\[\]{}]+/g,
      ' '
    );

  text =
    text
      .replace(/\s+/g, ' ')
      .trim();

  return text;
}


/* =====================================================
   13. COMPACT SEARCH
   ===================================================== */

function compactSearchText_(value) {

  return String(value || '')
    .toLowerCase()
    .replace(
      /[^a-z0-9]+/g,
      ''
    );
}


/* =====================================================
   14. TOKENIZE
   ===================================================== */

function tokenize_(query) {

  const normalized =
    normalizeSearchText_(
      query
    );

  if (!normalized) {
    return [];
  }

  const parts =
    normalized.split(/\s+/);

  const output = [];
  const seen = {};

  parts.forEach(
    function(token) {

      if (
        token &&
        !seen[token]
      ) {

        seen[token] = true;

        output.push(token);
      }
    }
  );

  return output.slice(
    0,
    12
  );
}


/* =====================================================
   15. TOKEN MATCH
   ===================================================== */

function tokenMatches_(
  token,
  words,
  normalized,
  compact
) {

  token =
    String(token || '')
      .toLowerCase()
      .trim();

  if (!token) {
    return true;
  }

  if (
    normalized.indexOf(token) >= 0
  ) {
    return true;
  }

  for (
    let i = 0;
    i < words.length;
    i++
  ) {

    if (
      words[i].indexOf(token) === 0
    ) {
      return true;
    }
  }

  const compactToken =
    compactSearchText_(
      token
    );

  if (
    compactToken &&
    compact.indexOf(
      compactToken
    ) >= 0
  ) {
    return true;
  }

  return false;
}


/* =====================================================
   16. SMART SEARCH SCORE
   ===================================================== */

function scoreRow_(
  row,
  query
) {

  const rawQuery =
    String(query || '')
      .trim();

  if (!rawQuery) {
    return 1;
  }

  const nameRaw =
    row.name || '';

  const productRaw =
    row.product || '';

  const categoryRaw =
    row.category || '';

  const folderRaw =
    row.folder || '';

  const name =
    normalizeSearchText_(
      nameRaw
    );

  const product =
    normalizeSearchText_(
      productRaw
    );

  const category =
    normalizeSearchText_(
      categoryRaw
    );

  const folder =
    normalizeSearchText_(
      folderRaw
    );

  const combined =
    [
      name,
      product,
      category,
      folder
    ].join(' ');

  const words =
    combined.split(/\s+/);

  const compact =
    compactSearchText_(
      [
        nameRaw,
        productRaw,
        categoryRaw,
        folderRaw
      ].join(' ')
    );

  const tokens =
    tokenize_(rawQuery);

  if (!tokens.length) {
    return 1;
  }

  /*
   * ALL search tokens must match.
   */
  for (
    let i = 0;
    i < tokens.length;
    i++
  ) {

    if (
      !tokenMatches_(
        tokens[i],
        words,
        combined,
        compact
      )
    ) {
      return 0;
    }
  }

  let score = 0;

  const qNorm =
    normalizeSearchText_(
      rawQuery
    );

  const qCompact =
    compactSearchText_(
      rawQuery
    );

  const nameCompact =
    compactSearchText_(
      nameRaw
    );

  const productCompact =
    compactSearchText_(
      productRaw
    );

  const folderCompact =
    compactSearchText_(
      folderRaw
    );


  /* Exact / partial name */

  if (qNorm === name) {

    score += 400;

  } else if (
    qNorm &&
    name.indexOf(qNorm) >= 0
  ) {

    score += 230;
  }


  /* Exact / partial product */

  if (qNorm === product) {

    score += 320;

  } else if (
    qNorm &&
    product.indexOf(qNorm) >= 0
  ) {

    score += 185;
  }


  /* Category */

  if (qNorm === category) {

    score += 260;

  } else if (
    qNorm &&
    category.indexOf(qNorm) >= 0
  ) {

    score += 135;
  }


  /* Folder */

  if (
    qNorm &&
    folder.indexOf(qNorm) >= 0
  ) {

    score += 120;
  }


  /* Compact matching */

  if (qCompact) {

    if (
      qCompact === nameCompact
    ) {

      score += 330;

    } else if (
      nameCompact.indexOf(
        qCompact
      ) >= 0
    ) {

      score += 180;
    }

    if (
      qCompact === productCompact
    ) {

      score += 270;

    } else if (
      productCompact.indexOf(
        qCompact
      ) >= 0
    ) {

      score += 145;
    }

    if (
      folderCompact.indexOf(
        qCompact
      ) >= 0
    ) {

      score += 90;
    }
  }


  /* Token ranking */

  tokens.forEach(
    function(token) {

      const t =
        token.toLowerCase();

      if (
        name.indexOf(t) >= 0
      ) {

        score += 60;

      } else if (
        name
          .split(/\s+/)
          .some(
            function(word) {
              return (
                word.indexOf(t) === 0
              );
            }
          )
      ) {

        score += 45;
      }

      if (
        product.indexOf(t) >= 0
      ) {

        score += 55;

      } else if (
        product
          .split(/\s+/)
          .some(
            function(word) {
              return (
                word.indexOf(t) === 0
              );
            }
          )
      ) {

        score += 40;
      }

      if (
        category.indexOf(t) >= 0
      ) {
        score += 35;
      }

      if (
        folder.indexOf(t) >= 0
      ) {
        score += 25;
      }

      /*
       * Model-number priority.
       */
      if (/\d/.test(t)) {

        const compactToken =
          compactSearchText_(t);

        if (
          name.indexOf(t) >= 0 ||
          nameCompact.indexOf(
            compactToken
          ) >= 0
        ) {
          score += 160;
        }

        if (
          product.indexOf(t) >= 0 ||
          productCompact.indexOf(
            compactToken
          ) >= 0
        ) {
          score += 80;
        }

        if (
          folder.indexOf(t) >= 0 ||
          folderCompact.indexOf(
            compactToken
          ) >= 0
        ) {
          score += 50;
        }
      }
    }
  );


  const folderWords =
    folder
      ? folder.split(/\s+/).length
      : 0;

  score += Math.max(
    0,
    20 -
    Math.min(
      20,
      folderWords
    )
  );

  return score;
}


/* =====================================================
   17. SEARCH DRIVE
   ===================================================== */

function searchDrive(query) {

  try {

    const q =
      String(query || '')
        .trim();

    if (q.length < 2) {

      return {
        ok: false,
        error:
          'Type at least 2 characters.'
      };
    }

    const sheet =
      getIndexSheet_();

    let lastRow =
      sheet.getLastRow();

    /*
     * First search automatically builds
     * the index if none exists.
     */
    if (lastRow < 2) {

      const refresh =
        refreshIndex();

      if (!refresh.ok) {
        return refresh;
      }

      lastRow =
        sheet.getLastRow();
    }

    if (lastRow < 2) {

      return {
        ok: true,
        results: [],
        indexedFiles: 0,
        totalMatches: 0
      };
    }

    const values =
      sheet
        .getRange(
          2,
          1,
          lastRow - 1,
          16
        )
        .getValues();

    const results = [];

    values.forEach(
      function(row) {

        const item = {

          fileId:
            String(row[0] || ''),

          driveSource:
            String(row[1] || ''),

          name:
            String(row[2] || ''),

          product:
            String(row[3] || ''),

          category:
            String(row[4] || ''),

          folder:
            String(row[5] || ''),

          type:
            String(row[6] || ''),

          modified:
            String(row[7] || ''),

          size:
            String(row[8] || ''),

          webViewLink:
            String(row[9] || ''),

          previewLink:
            String(row[10] || ''),

          isPdf:
            row[11] === true ||
            String(row[11]).toLowerCase() === 'true',

          rootName: String(row[12] || row[1] || ''),
          driveFolder: String(row[13] || row[5] || ''),
          matchedIn: String(row[14] || '')
        };


        const score =
          scoreRow_(
            item,
            q
          );

        if (score <= 0) {
          return;
        }

        item.matchedIn =
          getMatchedIn_(
            item,
            q
          );

        item.score =
          score;

        results.push(item);
      }
    );


    results.sort(
      function(a, b) {

        if (
          b.score !==
          a.score
        ) {

          return (
            b.score -
            a.score
          );
        }

        return String(
          a.name
        ).localeCompare(
          String(b.name)
        );
      }
    );


    const limited =
      results.slice(
        0,
        MAX_SEARCH_RESULTS
      );


    limited.forEach(
      function(item) {
        delete item.score;
      }
    );


    return {

      ok: true,

      results:
        limited,

      indexedFiles:
        values.length,

      totalMatches:
        results.length
    };

  } catch (error) {

    return {

      ok: false,

      error:
        error && error.message
          ? error.message
          : String(error)
    };
  }
}


/* =====================================================
   18. MATCH LOCATION
   ===================================================== */

function getMatchedIn_(
  item,
  query
) {

  const q =
    normalizeSearchText_(
      query
    );

  const compactQ =
    compactSearchText_(
      query
    );

  const name =
    normalizeSearchText_(
      item.name
    );

  const product =
    normalizeSearchText_(
      item.product
    );

  const category =
    normalizeSearchText_(
      item.category
    );

  const folder =
    normalizeSearchText_(
      item.folder
    );


  if (
    q &&
    name.indexOf(q) >= 0
  ) {
    return 'File name';
  }

  if (
    q &&
    product.indexOf(q) >= 0
  ) {
    return 'Product';
  }

  if (
    q &&
    category.indexOf(q) >= 0
  ) {
    return 'Category';
  }

  if (
    q &&
    folder.indexOf(q) >= 0
  ) {
    return 'Folder';
  }


  if (
    compactQ &&
    compactSearchText_(
      item.name
    ).indexOf(compactQ) >= 0
  ) {
    return 'File name';
  }

  if (
    compactQ &&
    compactSearchText_(
      item.product
    ).indexOf(compactQ) >= 0
  ) {
    return 'Product';
  }

  return 'Drive content';
}


/* =====================================================
   19. CLOUD STATUS
   ===================================================== */

function getIndexStatus() {

  try {

    const props =
      PropertiesService
        .getScriptProperties();

    const sheet =
      getIndexSheet_();

    const count =
      Math.max(
        0,
        sheet.getLastRow() - 1
      );

    return {

      ok: true,

      connected: true,

      roots: DRIVE_ROOTS,

      indexedFiles:
        count,

      lastRefresh:
        props.getProperty(
          'NUNES_INDEX_LAST_REFRESH'
        ) || '',

      spreadsheetId:
        props.getProperty(
          'NUNES_INDEX_SPREADSHEET_ID'
        ) || ''
    };

  } catch (error) {

    return {

      ok: false,

      connected: false,

      error:
        error.message
    };
  }
}


/* =====================================================
   20. TEST GOOGLE DRIVE
   ===================================================== */


function getDriveCategories() {

  try {

    const config =
      getConfig_();

    const categories = [];

    config.roots.forEach(
      function(rootConfig) {

        const root =
          DriveApp.getFolderById(
            rootConfig.id
          );

        categories.push({
          name: root.getName(),
          type: 'ROOT',
          rootName: rootConfig.name,
          path: root.getName()
        });

        collectFolderCategories_(root, categories, rootConfig.name, root.getName());
      }
    );

    const seen = {};

    const unique =
      categories.filter(function(item) {
        const key = String(item.rootName || '') + '|' + String(item.path || item.name || '');
        if (seen[key]) return false;
        seen[key] = true;
        return true;
      });

    unique.sort(
      function(a, b) {
        return a.name.localeCompare(
          b.name
        );
      }
    );

    return {
      ok: true,
      categories: unique
    };

  } catch (error) {

    return {
      ok: false,
      error:
        error && error.message
          ? error.message
          : String(error)
    };
  }
}


function collectFolderCategories_(folder, categories, rootName, parentPath) {

  const folders =
    folder.getFolders();

  while (folders.hasNext()) {

    const child =
      folders.next();

    const path = parentPath ? parentPath + ' / ' + child.getName() : child.getName();
    categories.push({
      name: child.getName(),
      type: 'FOLDER',
      rootName: rootName,
      path: path
    });

    collectFolderCategories_(child, categories, rootName, path);
  }
}


function testDriveConnection() {

  try {

    const config =
      getConfig_();

    const folders =
      config.roots.map(
        function(rootConfig) {

          const folder =
            DriveApp.getFolderById(
              rootConfig.id
            );

          return {
            name: rootConfig.name,
            id: folder.getId(),
            folderName: folder.getName()
          };
        }
      );

    return {

      ok: true,

      folders: folders,

      message:
        'Google Drive connection successful for all configured folders.'
    };

  } catch (error) {

    return {

      ok: false,

      error:
        error && error.message
          ? error.message
          : String(error)
    };
  }
}

/* =====================================================
   21. OPTIONAL HTML INCLUDE
   ===================================================== */

function include(filename) {

  return HtmlService
    .createHtmlOutputFromFile(
      filename
    )
    .getContent();
}
function checkIndex() {

  const result = getIndexStatus();

  throw new Error(
    'INDEX STATUS: ' +
    JSON.stringify(result)
  );
}
function CHECK_DRIVE() {

  var mini =
    DriveApp.getFolderById(
      '1C4Bh6hfXC731IXcDMHPSk4szFSaKLkpo'
    );

  var catalog =
    DriveApp.getFolderById(
      '1WsK2eDMwlfE60Lyf0zSYpzvyvKLD5rgn'
    );

  var miniCount =
    countFilesRecursive_(mini);

  var catalogCount =
    countFilesRecursive_(catalog);

  throw new Error(
    'MINI CATALOG TOTAL = ' +
    miniCount +
    ' | CATALOG TOTAL = ' +
    catalogCount
  );
}


function countFilesRecursive_(folder) {

  var count = 0;

  var files =
    folder.getFiles();

  while (files.hasNext()) {

    files.next();

    count++;
  }

  var folders =
    folder.getFolders();

  while (folders.hasNext()) {

    var subFolder =
      folders.next();

    count +=
      countFilesRecursive_(
        subFolder
      );
  }

  return count;
}
