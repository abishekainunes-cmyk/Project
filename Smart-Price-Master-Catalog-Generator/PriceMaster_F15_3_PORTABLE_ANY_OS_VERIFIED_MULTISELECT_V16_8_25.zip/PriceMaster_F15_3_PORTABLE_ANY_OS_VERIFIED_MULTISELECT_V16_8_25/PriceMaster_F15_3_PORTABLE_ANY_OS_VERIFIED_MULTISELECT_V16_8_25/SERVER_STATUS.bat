@echo off
setlocal EnableExtensions EnableDelayedExpansion
pushd "%~dp0" >nul 2>&1
set "PORT_MIN=8765"
set "PORT_MAX=8795"
set "FOUND_PORT="

if exist "SERVER_PORT.txt" (
    set /p SAVED_PORT=<"SERVER_PORT.txt"
    if defined SAVED_PORT (
        for /f "usebackq delims=" %%Q in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $p=[int]'!SAVED_PORT!'; $w=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p+'/api/local-health') -TimeoutSec 2; $r=ConvertFrom-Json -InputObject $w.Content; if($r.ok -and $r.app -eq 'PriceMaster'){Write-Output $p} } catch {}"`) do set "FOUND_PORT=%%Q"
    )
)

if not defined FOUND_PORT (
    for /f "usebackq delims=" %%Q in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($p in %PORT_MIN%..%PORT_MAX%){ try { $w=Invoke-WebRequest -UseBasicParsing -Uri ('http://127.0.0.1:'+$p+'/api/local-health') -TimeoutSec 1; $r=ConvertFrom-Json -InputObject $w.Content; if($r.ok -and $r.app -eq 'PriceMaster'){Write-Output $p; break} } catch {} }"`) do set "FOUND_PORT=%%Q"
)

echo.
echo ============================================================
echo   PRICEMASTER SERVER STATUS
echo ============================================================
echo.
if not defined FOUND_PORT (
    echo [STOPPED] PriceMaster is not responding on ports %PORT_MIN%-%PORT_MAX%.
    echo Run START_PRICEMASTER.bat on this main server PC.
) else (
    > "SERVER_PORT.txt" echo !FOUND_PORT!
    echo [RUNNING] PriceMaster main server is active.
    echo Port: !FOUND_PORT!
    echo Main PC: http://127.0.0.1:!FOUND_PORT!/index.html
    echo Admin dashboard: http://127.0.0.1:!FOUND_PORT!/admin.html
    echo.
    if exist "CLIENT_LINKS.txt" type "CLIENT_LINKS.txt"
)
echo.
pause
popd
endlocal
